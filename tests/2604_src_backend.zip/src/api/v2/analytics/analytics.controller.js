// src/api/v2/analytics/analytics.controller.js
const Order = require('../../../models/order.model');
const Run = require('../../../models/run.model');
const DailySummary = require('../../../models/dailySummary.model');
const HttpError = require('../../../utils/HttpError');
const { logger } = require('../../../config/logger.config');
const mongoose = require('mongoose');

/**
 * ALIGNMENT GOAL (critical):
 * Dashboard + Analytics MUST match Management Accounts (financials.controller.js)
 *
 * Ledger sources:
 *  - Orders        => DELIVERY ledger
 *  - DailySummary  => POS ledger (daily summaries)
 *
 * Date rules (critical after data migration):
 *  - Orders: use orderDate (fallback createdAt ONLY when orderDate missing)
 *  - DailySummary: use date (NOT createdAt)
 *
 * Revenue recognition rule (matches financials.controller.js):
 *  - Recognize DELIVERY revenue only when status=Delivered AND paymentStatus is paid/completed/success
 *  - POS DailySummary revenue is recognized when status=approved (business date)
 */

// -------------------- Tiny helpers --------------------

const _safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const _asObjectId = (v) =>
  mongoose.Types.ObjectId.isValid(String(v)) ? new mongoose.Types.ObjectId(String(v)) : null;

/**
 * branchId == serviceZoneId (tolerant matcher)
 * Support mixed schemas across collections:
 *  - branchId stored as ObjectId or string
 *  - OR serviceZoneId/zoneId/plantId stored as ObjectId or string
 */
const buildBranchOrZoneMatch = (branchIdOrZoneId) => {
  if (!branchIdOrZoneId) return {};

  const s = String(branchIdOrZoneId);
  const oid = _asObjectId(s);

  const ors = [{ branchId: s }, { serviceZoneId: s }, { zoneId: s }, { plantId: s }];
  if (oid) {
    ors.push({ branchId: oid }, { serviceZoneId: oid }, { zoneId: oid }, { plantId: oid });
  }

  return { $or: ors };
};

/**
 * Period helper (same semantics as financials.controller.js)
 * ✅ inclusive end-of-day
 */
const getDateRange = (period = 'monthly', customStart, customEnd) => {
  const now = new Date();
  let start = new Date(now.getFullYear(), 0, 1);
  let end = new Date();

  if (period === 'monthly') {
    start = new Date(now.getFullYear(), now.getMonth(), 1);
  } else if (period === 'quarterly') {
    const quarter = Math.floor(now.getMonth() / 3);
    start = new Date(now.getFullYear(), quarter * 3, 1);
  } else if (period === 'yearly') {
    start = new Date(now.getFullYear(), 0, 1);
  } else if (period === 'custom' && customStart && customEnd) {
    start = new Date(customStart);
    end = new Date(customEnd);
  }

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    start = new Date(now.getFullYear(), 0, 1);
    end = new Date();
  }

  // ✅ inclusive end-of-day
  end.setHours(23, 59, 59, 999);

  return { start, end };
};

const _isPaidExpr = () => ({
  $in: [
    { $toLower: { $ifNull: ['$paymentStatus', ''] } },
    ['completed', 'paid', 'success', 'successful'],
  ],
});

const _normalizeOrderPaymentMethodExpr = () => ({
  $cond: {
    if: { $eq: ['$paymentMethod', 'card'] },
    then: 'POS',
    else: '$paymentMethod',
  },
});

/**
 * DELIVERY orders match:
 * - status must be Delivered
 * - revenue recognized only when paid
 * - enforce channel=DELIVERY if present
 * - filter by business date (orderDate fallback createdAt ONLY when orderDate missing)
 */
const _ordersMatch = (start, end, branchMatch) => {
  return {
    ...branchMatch,

    // Enforce delivery channel if present; tolerate missing channel
    $and: [{ $or: [{ channel: { $exists: false } }, { channel: 'DELIVERY' }] }],

    // Date: orderDate first; fallback to createdAt ONLY if orderDate missing
    $or: [
      { orderDate: { $gte: start, $lte: end } },
      { orderDate: { $exists: false }, createdAt: { $gte: start, $lte: end } },
    ],

    // Delivered + Paid (case-insensitive)
    $expr: {
      $and: [
        { $eq: [{ $toLower: { $ifNull: ['$status', ''] } }, 'delivered'] },
        _isPaidExpr(),
      ],
    },
  };
};

/**
 * Optional: Delivered but UNPAID (for reconciliation / receivables dashboards)
 * (Not counted as revenue.)
 */
const _ordersDeliveredUnpaidMatch = (start, end, branchMatch) => {
  return {
    ...branchMatch,
    $and: [{ $or: [{ channel: { $exists: false } }, { channel: 'DELIVERY' }] }],
    $or: [
      { orderDate: { $gte: start, $lte: end } },
      { orderDate: { $exists: false }, createdAt: { $gte: start, $lte: end } },
    ],
    $expr: {
      $and: [
        { $eq: [{ $toLower: { $ifNull: ['$status', ''] } }, 'delivered'] },
        { $not: [_isPaidExpr()] },
      ],
    },
  };
};

/**
 * Base shape for Orders (DELIVERY ledger)
 * Use orderDate first (migration-safe), fallback createdAt.
 */
const _ordersBaseProject = () => ({
  $project: {
    _id: 0,
    id: { $toString: '$_id' },
    businessDate: { $ifNull: ['$orderDate', '$createdAt'] },
    grandTotal: { $ifNull: ['$grandTotal', '$totalAmount'] },
    items: { $ifNull: ['$items', []] },
    paymentMethod: _normalizeOrderPaymentMethodExpr(),
    branchId: { $ifNull: ['$branchId', null] },
    source: { $literal: 'order_delivery' },
  },
});

const _ordersAddFields = () => ({
  $addFields: {
    grandTotal: { $ifNull: ['$grandTotal', 0] },
    totalKgSold: {
      $cond: [{ $isArray: '$items' }, { $sum: '$items.quantity' }, 0],
    },
  },
});

/**
 * POS DailySummary match (POS ledger)
 * Use business date field: date (NOT createdAt)
 */
const _dailySummaryMatch = (start, end, branchMatch) => ({
  ...branchMatch,
  status: 'approved',
  date: { $gte: start, $lte: end },
});

const _dailySummaryProjectAsSale = () => ({
  $project: {
    _id: 0,
    id: '$dailySummaryId',
    businessDate: '$date',
    grandTotal: { $ifNull: ['$sales.totalRevenue', 0] },
    items: [
      {
        productName: 'LPG Gas',
        quantity: { $ifNull: ['$sales.totalKgSold', 0] },
        unitPrice: { $ifNull: ['$pricePerKg', 0] },
      },
    ],
    paymentMethod: { $literal: 'DailyLog' },
    branchId: '$branchId',
    source: { $literal: 'daily_log' },
  },
});

const _dailySummaryAddFields = () => ({
  $addFields: {
    grandTotal: { $ifNull: ['$grandTotal', 0] },
    totalKgSold: {
      $cond: [{ $isArray: '$items' }, { $sum: '$items.quantity' }, 0],
    },
    paymentMethod: { $literal: 'DailyLog' },
  },
});

const _aggregateOrders = async ({ start, end, branchMatch }, extraPipeline = []) => {
  const pipeline = [
    { $match: _ordersMatch(start, end, branchMatch) },
    _ordersBaseProject(),
    _ordersAddFields(),
    ...extraPipeline,
  ];
  return Order.aggregate(pipeline);
};

const _aggregateOrdersDeliveredUnpaid = async ({ start, end, branchMatch }, extraPipeline = []) => {
  const pipeline = [
    { $match: _ordersDeliveredUnpaidMatch(start, end, branchMatch) },
    _ordersBaseProject(),
    _ordersAddFields(),
    ...extraPipeline,
  ];
  return Order.aggregate(pipeline);
};

const _aggregateDailySummaries = async ({ start, end, branchMatch }, extraPipeline = []) => {
  const pipeline = [
    { $match: _dailySummaryMatch(start, end, branchMatch) },
    _dailySummaryProjectAsSale(),
    _dailySummaryAddFields(),
    ...extraPipeline,
  ];
  return DailySummary.aggregate(pipeline);
};

// Merge helpers
const _yearMonthKey = (y, m) => `${y}-${String(m).padStart(2, '0')}`;

const _mergeByKey = (rowsA, rowsB, keyFn) => {
  const map = new Map();

  for (const r of rowsA || []) {
    const k = keyFn(r);
    map.set(k, { ...r });
  }
  for (const r of rowsB || []) {
    const k = keyFn(r);
    if (!map.has(k)) {
      map.set(k, { ...r });
    } else {
      const prev = map.get(k);
      map.set(k, {
        ...prev,
        totalRevenue: _safeNum(prev.totalRevenue) + _safeNum(r.totalRevenue),
        totalKgSold: _safeNum(prev.totalKgSold) + _safeNum(r.totalKgSold),
        count: _safeNum(prev.count) + _safeNum(r.count),
      });
    }
  }

  return Array.from(map.values());
};

// -------------------- Controllers --------------------

/**
 * GET /api/v2/analytics/dashboard-kpis
 * Query:
 *  - period=monthly|quarterly|yearly|custom
 *  - startDate, endDate (when custom)
 *  - branchId OR serviceZoneId
 */
const getDashboardKpis = async (req, res, next) => {
  try {
    const { period = 'monthly', startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const { start, end } = getDateRange(period, startDate, endDate);
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    // DELIVERY (Orders) - recognized only when paid + Delivered
    const ordersAgg = await _aggregateOrders(
      { start, end, branchMatch },
      [
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: '$grandTotal' },
            totalKgSold: { $sum: '$totalKgSold' },
            count: { $sum: 1 },
          },
        },
      ]
    );

    // Delivered but unpaid (A/R) — not revenue, but useful for matching management accounts
    const receivableAgg = await _aggregateOrdersDeliveredUnpaid(
      { start, end, branchMatch },
      [
        {
          $group: {
            _id: null,
            receivables: { $sum: '$grandTotal' },
            count: { $sum: 1 },
          },
        },
      ]
    );

    // POS (DailySummary) - approved summaries in date range
    const posAgg = await _aggregateDailySummaries(
      { start, end, branchMatch },
      [
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: '$grandTotal' },
            totalKgSold: { $sum: '$totalKgSold' },
            count: { $sum: 1 },
          },
        },
      ]
    );

    const delivery = ordersAgg[0] || { totalRevenue: 0, totalKgSold: 0, count: 0 };
    const pos = posAgg[0] || { totalRevenue: 0, totalKgSold: 0, count: 0 };
    const ar = receivableAgg[0] || { receivables: 0, count: 0 };

    const totalRevenue = _safeNum(delivery.totalRevenue) + _safeNum(pos.totalRevenue);
    const totalKgSold = _safeNum(delivery.totalKgSold) + _safeNum(pos.totalKgSold);

    const activeDeliveries = await Run.countDocuments({ overallStatus: { $in: ['Assigned', 'In Progress'] } });
    const currentBulkStock = 8500; // placeholder (wire to stock model later)

    return res.status(200).json({
      totalRevenue,
      totalKgSold,
      currentBulkStock,
      activeDeliveries,
      period: { start, end },
      branch: { branchId: branchKey },
      breakdown: {
        deliveryRecognizedRevenue: _safeNum(delivery.totalRevenue),
        posRevenue: _safeNum(pos.totalRevenue),
      },
      receivables: {
        unpaidDelivered: _safeNum(ar.receivables),
        count: _safeNum(ar.count),
        note: 'Delivered but unpaid; NOT included in revenue (matches management accounts).',
      },
    });
  } catch (error) {
    logger.error('Error fetching dashboard KPIs:', error);
    return next(new HttpError(500, 'Failed to fetch dashboard data.'));
  }
};

/**
 * GET /api/v2/analytics/sales-report
 * Query:
 *  - period=monthly|quarterly|yearly|custom
 *  - startDate, endDate (when custom)
 *  - branchId OR serviceZoneId
 *
 * Returns backend format: [{ _id:{year,month}, totalRevenue, totalKgSold, count }]
 * (same shape your frontend SalesReport mapping expects)
 */
const getSalesReport = async (req, res, next) => {
  try {
    const { period = 'monthly', startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const { start, end } = getDateRange(period, startDate, endDate);
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const groupByMonth = [
      {
        $group: {
          _id: { year: { $year: '$businessDate' }, month: { $month: '$businessDate' } },
          totalRevenue: { $sum: '$grandTotal' },
          totalKgSold: { $sum: '$totalKgSold' },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ];

    const [ordersMonthly, posMonthly] = await Promise.all([
      _aggregateOrders({ start, end, branchMatch }, groupByMonth),
      _aggregateDailySummaries({ start, end, branchMatch }, groupByMonth),
    ]);

    const merged = _mergeByKey(ordersMonthly, posMonthly, (r) => _yearMonthKey(r?._id?.year, r?._id?.month));
    merged.sort((a, b) => (a._id.year !== b._id.year ? a._id.year - b._id.year : a._id.month - b._id.month));

    return res.status(200).json(merged);
  } catch (error) {
    logger.error('Error fetching sales report:', error);
    return next(new HttpError(500, 'Failed to fetch sales report data.'));
  }
};

/**
 * GET /api/v2/analytics/sales-by-payment-method
 * Query supports same filters as above (optional)
 *
 * Note:
 * - Orders paymentMethod is normalized (card => POS)
 * - DailySummary is grouped under "DailyLog"
 */
const getSalesByPaymentMethod = async (req, res, next) => {
  try {
    const { period = 'monthly', startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const { start, end } = getDateRange(period, startDate, endDate);
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const groupByMethod = [
      {
        $group: {
          _id: '$paymentMethod',
          totalRevenue: { $sum: '$grandTotal' },
          totalKgSold: { $sum: '$totalKgSold' },
          count: { $sum: 1 },
        },
      },
    ];

    const [ordersByMethod, posByMethod] = await Promise.all([
      _aggregateOrders({ start, end, branchMatch }, groupByMethod),
      _aggregateDailySummaries({ start, end, branchMatch }, groupByMethod),
    ]);

    const merged = _mergeByKey(ordersByMethod, posByMethod, (r) => String(r._id || 'Unknown'));
    merged.sort((a, b) => _safeNum(b.totalRevenue) - _safeNum(a.totalRevenue));

    return res.status(200).json(merged);
  } catch (error) {
    logger.error('Error fetching sales by payment method:', error);
    return next(new HttpError(500, 'Failed to fetch sales by payment method.'));
  }
};

/**
 * GET /api/v2/analytics/sales-by-branch
 * Query supports same filters as above (optional)
 */
const getSalesByBranch = async (req, res, next) => {
  try {
    const { period = 'monthly', startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const { start, end } = getDateRange(period, startDate, endDate);
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const groupByBranch = [
      {
        $group: {
          _id: '$branchId',
          totalRevenue: { $sum: '$grandTotal' },
          totalKgSold: { $sum: '$totalKgSold' },
          count: { $sum: 1 },
        },
      },
    ];

    const [ordersByBranch, posByBranch] = await Promise.all([
      _aggregateOrders({ start, end, branchMatch }, groupByBranch),
      _aggregateDailySummaries({ start, end, branchMatch }, groupByBranch),
    ]);

    const merged = _mergeByKey(ordersByBranch, posByBranch, (r) => String(r._id || 'Unknown'));

    // Resolve plant names best-effort
    let plants = [];
    try {
      plants = await mongoose.connection.collection('plants').find({}).toArray();
    } catch (e) {
      plants = [];
    }

    const plantMap = new Map();
    for (const p of plants) {
      if (!p) continue;
      if (p.id != null) plantMap.set(String(p.id), p.name);
      if (p._id != null) plantMap.set(String(p._id), p.name);
    }

    const shaped = merged.map((r) => ({
      branchId: r._id,
      branchName: plantMap.get(String(r._id)) || null,
      totalRevenue: _safeNum(r.totalRevenue),
      totalKgSold: _safeNum(r.totalKgSold),
      count: _safeNum(r.count),
    }));

    shaped.sort((a, b) => _safeNum(b.totalRevenue) - _safeNum(a.totalRevenue));
    return res.status(200).json(shaped);
  } catch (error) {
    logger.error('Error fetching sales by branch:', error);
    return next(new HttpError(500, 'Failed to fetch sales by branch.'));
  }
};

/**
 * GET /api/v2/analytics/top-selling-products
 * Query supports same filters as above (optional)
 */
const getTopSellingProducts = async (req, res, next) => {
  try {
    const { period = 'monthly', startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const { start, end } = getDateRange(period, startDate, endDate);
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const ordersTop = await _aggregateOrders(
      { start, end, branchMatch },
      [
        { $unwind: { path: '$items', preserveNullAndEmptyArrays: false } },
        {
          $group: {
            _id: '$items.productName',
            totalQuantitySold: { $sum: '$items.quantity' },
            totalRevenue: { $sum: { $multiply: ['$items.quantity', '$items.unitPrice'] } },
          },
        },
      ]
    );

    const posTop = await _aggregateDailySummaries(
      { start, end, branchMatch },
      [
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.productName',
            totalQuantitySold: { $sum: '$items.quantity' },
            totalRevenue: { $sum: { $multiply: ['$items.quantity', '$items.unitPrice'] } },
          },
        },
      ]
    );

    // Merge on product name, but keep BOTH quantity and revenue fields
    const merged = (() => {
      const map = new Map();

      const addRow = (r) => {
        const k = String(r._id || 'Unknown');
        const prev = map.get(k) || { _id: k, totalQuantitySold: 0, totalRevenue: 0 };
        map.set(k, {
          _id: k,
          totalQuantitySold: _safeNum(prev.totalQuantitySold) + _safeNum(r.totalQuantitySold),
          totalRevenue: _safeNum(prev.totalRevenue) + _safeNum(r.totalRevenue),
        });
      };

      (ordersTop || []).forEach((r) =>
        addRow({
          _id: r._id || 'Unknown',
          totalQuantitySold: _safeNum(r.totalQuantitySold),
          totalRevenue: _safeNum(r.totalRevenue),
        })
      );

      (posTop || []).forEach((r) =>
        addRow({
          _id: r._id || 'LPG Gas',
          totalQuantitySold: _safeNum(r.totalQuantitySold),
          totalRevenue: _safeNum(r.totalRevenue),
        })
      );

      return Array.from(map.values());
    })();

    merged.sort((a, b) => _safeNum(b.totalQuantitySold) - _safeNum(a.totalQuantitySold));
    return res.status(200).json(merged.slice(0, 10));
  } catch (error) {
    logger.error('Error fetching top selling products:', error);
    return next(new HttpError(500, 'Failed to fetch top selling products.'));
  }
};

module.exports = {
  getDashboardKpis,
  getSalesReport,
  getSalesByPaymentMethod,
  getSalesByBranch,
  getTopSellingProducts,
};
