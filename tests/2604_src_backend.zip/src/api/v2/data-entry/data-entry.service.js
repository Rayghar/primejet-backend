// src/api/v2/data-entry/data-entry.service.js

const DailySummary = require('../../../models/dailySummary.model');
const SaleTransaction = require('../../../models/saleTransaction.model');
const ExpenseTransaction = require('../../../models/expenseTransaction.model');
const Plant = require('../../../models/plant.model');
const { v4: uuidv4 } = require('uuid');
const HttpError = require('../../../utils/HttpError');
const mongoose = require('mongoose');

// -------------------- Helpers --------------------

const startOfDay = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d;
};

const endOfDay = (date) => {
  const d = new Date(date);
  d.setHours(23, 59, 59, 999);
  return d;
};

/**
 * Safely fetch a model that may already be registered, without hard-crashing on require.
 * You likely already have these models in your codebase; we try:
 *  - mongoose.models.<Name>
 *  - mongoose.model('<Name>') if registered
 *  - require() fallback if you use a conventional path (optional)
 */
const getModel = (name, requirePath = null) => {
  if (mongoose.models && mongoose.models[name]) return mongoose.models[name];
  try {
    return mongoose.model(name);
  } catch (_) {
    // ignore
  }
  if (requirePath) {
    try {
      // eslint-disable-next-line global-require, import/no-dynamic-require
      return require(requirePath);
    } catch (_) {
      // ignore
    }
  }
  return null;
};

const StockIn = getModel('StockIn', '../../../models/stockIn.model');
const InventoryMovement = getModel('InventoryMovement', '../../../models/inventoryMovement.model');
const WalletTransaction = getModel('WalletTransaction', '../../../models/walletTransaction.model');

/**
 * Atomic FIFO inventory deduction.
 *
 * Requirements implemented (CRITICAL ISSUE #3):
 * - Inventory must be enforced at sale-time, not derived only in analytics.
 * - Deduct from StockIn.remainingKg using atomic updates, within the same session.
 * - Reject sale if insufficient stock.
 * - Log stock-out movement(s).
 *
 * Assumptions (common patterns):
 * StockIn schema includes: branchId, remainingKg, date/createdAt, and _id.
 * InventoryMovement schema includes: branchId, type, kg, refType, refId, date, meta.
 *
 * If your field names differ, tell me and I’ll align surgically.
 */
const deductInventoryKgFIFO = async ({
  branchId,
  kgToDeduct,
  refType,
  refId,
  date,
  session,
  createdBy,
}) => {
  if (!StockIn) {
    throw new HttpError(
      500,
      'Inventory enforcement is enabled but StockIn model is not registered. Please add/register StockIn model.'
    );
  }

  const kg = Number(kgToDeduct || 0);
  if (!(kg > 0)) return; // nothing to deduct

  let remaining = kg;

  // We do FIFO: oldest batches first
  // We avoid pre-calculating inventory; we deduct atomically per batch.
  // Find candidate batches (remainingKg > 0)
  const batches = await StockIn.find({
    branchId,
    remainingKg: { $gt: 0 },
  })
    .sort({ date: 1, createdAt: 1, _id: 1 })
    .session(session);

  if (!batches || batches.length === 0) {
    throw new HttpError(400, 'Insufficient inventory: no available stock batches.');
  }

  const movementsToInsert = [];

  for (const batch of batches) {
    if (remaining <= 0) break;

    const batchRemaining = Number(batch.remainingKg || 0);
    if (batchRemaining <= 0) continue;

    const take = Math.min(batchRemaining, remaining);

    /**
     * Atomic enforcement:
     * Update only if remainingKg is still >= take at the moment of update.
     * This protects against concurrent sales racing each other.
     */
    const updated = await StockIn.findOneAndUpdate(
      {
        _id: batch._id,
        remainingKg: { $gte: take },
      },
      {
        $inc: { remainingKg: -take },
      },
      {
        new: true,
        session,
      }
    );

    if (!updated) {
      // Another transaction likely consumed this batch; continue to next batch
      continue;
    }

    remaining -= take;

    // Log movement for traceability
    if (InventoryMovement) {
      movementsToInsert.push({
        branchId,
        type: 'STOCK_OUT',
        kg: take,
        stockInId: batch._id,
        refType, // e.g. 'SaleTransaction'
        refId,
        date: date || new Date(),
        createdBy: createdBy || null,
        meta: {
          method: 'FIFO',
        },
      });
    }
  }

  if (remaining > 0) {
    // If we couldn't satisfy full kg, rollback transaction by throwing
    throw new HttpError(400, `Insufficient inventory: short by ${remaining.toFixed(3)}kg.`);
  }

  if (InventoryMovement && movementsToInsert.length > 0) {
    await InventoryMovement.insertMany(movementsToInsert, { session });
  }
};

/**
 * Wallet transaction ledger.
 *
 * Requirements implemented:
 * - Every sale/expense should write an immutable ledger entry.
 * - Write must be in same Mongo transaction as Sale/Expense + Summary update.
 *
 * Assumptions (typical):
 * WalletTransaction includes: branchId, direction('CREDIT'|'DEBIT'), amount, currency,
 * referenceType, referenceId, date, createdBy, narration/meta.
 */
const writeWalletLedger = async ({
  branchId,
  direction,
  amount,
  referenceType,
  referenceId,
  date,
  createdBy,
  narration,
  meta,
  session,
}) => {
  if (!WalletTransaction) {
    throw new HttpError(
      500,
      'Wallet ledger is enabled but WalletTransaction model is not registered. Please add/register WalletTransaction model.'
    );
  }

  const amt = Number(amount || 0);
  if (!(amt > 0)) return;

  const tx = new WalletTransaction({
    branchId,
    direction, // 'CREDIT' or 'DEBIT'
    amount: amt,
    currency: 'NGN',
    referenceType,
    referenceId,
    date: date || new Date(),
    createdBy: createdBy || null,
    narration: narration || null,
    meta: meta || {},
  });

  await tx.save({ session });
  return tx;
};

// -------------------- Main Service Functions --------------------

const createOrGetDailySummary = async (branchId, cashierName, pricePerKg, userId) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  let dailySummary = await DailySummary.findOne({
    branchId,
    date: { $gte: startOfDay(today) },
    status: { $in: ['in_progress', 'pending_approval'] },
  });

  if (dailySummary) {
    console.debug('[DEBUG] Service: Found existing daily summary:', dailySummary._id);
    dailySummary.cashierName = cashierName;
    dailySummary.pricePerKg = pricePerKg;
    await dailySummary.save();
  } else {
    console.debug('[DEBUG] Service: No active summary found. Creating new daily summary.');
    dailySummary = new DailySummary({
      summaryId: uuidv4(),
      date: new Date(),
      branchId,
      cashierName,
      pricePerKg,
      status: 'in_progress',
      openingMeters: { meterA: 0, meterB: 0 },
      closingMeters: { meterA: 0, meterB: 0 },
      sales: {
        totalRevenue: 0,
        totalKgSold: 0,
        posAmount: 0,
        cashAmount: 0,
        transferAmount: 0,
        items: [],
      },
      expenses: { total: 0, items: [] },
      reconciliation: { calculatedRevenue: 0, discrepancy: 0 },
      managerApproval: {},
      createdBy: userId || null,
    });
    await dailySummary.save();
  }
  return dailySummary;
};

const updateSummaryMeters = async (summaryId, metersData) => {
  const summary = await DailySummary.findById(summaryId);
  if (!summary) throw new HttpError(404, 'Daily summary not found.');

  summary.openingMeters = metersData.openingMeters;
  summary.closingMeters = metersData.closingMeters;
  summary.pricePerKg = metersData.pricePerKg;

  const meterA_kg = (summary.closingMeters.meterA || 0) - (summary.openingMeters.meterA || 0);
  const meterB_kg = (summary.closingMeters.meterB || 0) - (summary.openingMeters.meterB || 0);
  const totalMetersKg = meterA_kg + meterB_kg;

  summary.reconciliation.calculatedRevenue = totalMetersKg * summary.pricePerKg;
  summary.reconciliation.discrepancy = summary.sales.totalRevenue - summary.reconciliation.calculatedRevenue;

  await summary.save();
  return summary;
};

/**
 * CRITICAL ISSUE #2 + #3 + Wallet ledger:
 * - Create sale + update summary + deduct inventory + wallet ledger inside ONE Mongo transaction.
 * - If any part fails, nothing is committed.
 */
const createSaleEntry = async (saleData) => {
  const session = await mongoose.startSession();

  try {
    let createdSale;

    await session.withTransaction(async () => {
      const summary = await DailySummary.findById(saleData.dailySummaryId).session(session);
      if (!summary) throw new HttpError(404, 'Daily summary not found.');

      // Optional guard: don’t allow posting to finalized/approved summaries
      if (!['in_progress', 'pending_approval'].includes(summary.status)) {
        throw new HttpError(400, 'Cannot add entries to this summary status.');
      }

      // 1) Create sale transaction
      const newSale = new SaleTransaction({
        ...saleData,
        branchId: saleData.branchId || summary.branchId,
        date: saleData.date || new Date(),
      });

      await newSale.save({ session });

      // 2) Enforce inventory deduction AT SALE TIME (atomic, FIFO)
      await deductInventoryKgFIFO({
        branchId: newSale.branchId || summary.branchId,
        kgToDeduct: newSale.kgSold,
        refType: 'SaleTransaction',
        refId: newSale._id,
        date: newSale.date || new Date(),
        session,
        createdBy: saleData.userId || saleData.createdBy || null,
      });

      // 3) Update summary aggregates
      summary.sales.totalRevenue = (summary.sales.totalRevenue || 0) + Number(newSale.amount || 0);
      summary.sales.totalKgSold = (summary.sales.totalKgSold || 0) + Number(newSale.kgSold || 0);

      const txType = String(newSale.transactionType || '').toUpperCase();
      if (txType === 'POS') {
        summary.sales.posAmount = (summary.sales.posAmount || 0) + Number(newSale.amount || 0);
      } else if (txType === 'CASH') {
        summary.sales.cashAmount = (summary.sales.cashAmount || 0) + Number(newSale.amount || 0);
      } else if (txType === 'TRANSFER') {
        summary.sales.transferAmount = (summary.sales.transferAmount || 0) + Number(newSale.amount || 0);
      }

      summary.sales.items.push(newSale._id);

      // 4) Wallet ledger entry (CREDIT)
      await writeWalletLedger({
        branchId: newSale.branchId || summary.branchId,
        direction: 'CREDIT',
        amount: Number(newSale.amount || 0),
        referenceType: 'SaleTransaction',
        referenceId: newSale._id,
        date: newSale.date || new Date(),
        createdBy: saleData.userId || saleData.createdBy || null,
        narration: `Sale entry (${newSale.transactionType || 'UNKNOWN'})`,
        meta: {
          dailySummaryId: summary._id,
          kgSold: Number(newSale.kgSold || 0),
        },
        session,
      });

      // 5) Recompute reconciliation fields (optional but helpful)
      const meterA_kg = (summary.closingMeters?.meterA || 0) - (summary.openingMeters?.meterA || 0);
      const meterB_kg = (summary.closingMeters?.meterB || 0) - (summary.openingMeters?.meterB || 0);
      const totalMetersKg = meterA_kg + meterB_kg;
      summary.reconciliation.calculatedRevenue = totalMetersKg * (summary.pricePerKg || 0);
      summary.reconciliation.discrepancy = (summary.sales.totalRevenue || 0) - (summary.reconciliation.calculatedRevenue || 0);

      await summary.save({ session });

      createdSale = newSale;
    });

    return createdSale;
  } catch (err) {
    throw err;
  } finally {
    session.endSession();
  }
};

/**
 * CRITICAL ISSUE #2 + Wallet ledger:
 * - Create expense + update summary + wallet ledger inside ONE Mongo transaction.
 */
const createExpenseEntry = async (expenseData) => {
  const session = await mongoose.startSession();

  try {
    let createdExpense;

    await session.withTransaction(async () => {
      const summary = await DailySummary.findById(expenseData.dailySummaryId).session(session);
      if (!summary) throw new HttpError(404, 'Daily summary not found.');

      if (!['in_progress', 'pending_approval'].includes(summary.status)) {
        throw new HttpError(400, 'Cannot add entries to this summary status.');
      }

      const newExpense = new ExpenseTransaction({
        ...expenseData,
        branchId: expenseData.branchId || summary.branchId,
        date: expenseData.date || new Date(),
      });

      await newExpense.save({ session });

      summary.expenses.total = (summary.expenses.total || 0) + Number(newExpense.amount || 0);
      summary.expenses.items.push(newExpense._id);

      // Wallet ledger entry (DEBIT)
      await writeWalletLedger({
        branchId: newExpense.branchId || summary.branchId,
        direction: 'DEBIT',
        amount: Number(newExpense.amount || 0),
        referenceType: 'ExpenseTransaction',
        referenceId: newExpense._id,
        date: newExpense.date || new Date(),
        createdBy: expenseData.userId || expenseData.createdBy || null,
        narration: `Expense entry${newExpense.description ? `: ${newExpense.description}` : ''}`,
        meta: {
          dailySummaryId: summary._id,
          category: newExpense.category || null,
        },
        session,
      });

      // Optional: update reconciliation discrepancy
      const meterA_kg = (summary.closingMeters?.meterA || 0) - (summary.openingMeters?.meterA || 0);
      const meterB_kg = (summary.closingMeters?.meterB || 0) - (summary.openingMeters?.meterB || 0);
      const totalMetersKg = meterA_kg + meterB_kg;
      summary.reconciliation.calculatedRevenue = totalMetersKg * (summary.pricePerKg || 0);
      summary.reconciliation.discrepancy = (summary.sales.totalRevenue || 0) - (summary.reconciliation.calculatedRevenue || 0);

      await summary.save({ session });

      createdExpense = newExpense;
    });

    return createdExpense;
  } catch (err) {
    throw err;
  } finally {
    session.endSession();
  }
};

const getDailyEntries = async (summaryId) => {
  const summary = await DailySummary.findById(summaryId).populate('sales.items').populate('expenses.items').lean();

  if (!summary) throw new HttpError(404, 'Daily summary not found.');

  const sales = (summary.sales?.items || []).map((s) => ({ ...s, type: 'sale' }));
  const expenses = (summary.expenses?.items || []).map((e) => ({ ...e, type: 'expense' }));

  return [...sales, ...expenses].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
};

/**
 * Transaction wrap finalize as well (Issue #2 pattern).
 * Even though it’s a single write, it keeps discipline consistent (and safe for future additions).
 */
const finalizeDailySummary = async (summaryId) => {
  const session = await mongoose.startSession();

  try {
    let updated;

    await session.withTransaction(async () => {
      const summary = await DailySummary.findById(summaryId).session(session);
      if (!summary) throw new HttpError(404, 'Daily summary not found.');

      if (summary.status !== 'in_progress') {
        throw new HttpError(400, 'Summary cannot be finalized.');
      }

      summary.status = 'pending_approval';
      await summary.save({ session });

      updated = summary;
    });

    return updated;
  } finally {
    session.endSession();
  }
};

const getDailySummaryReport = async (summaryId) => {
  const summary = await DailySummary.findById(summaryId)
    .populate('branchId', 'name')
    .populate('sales.items')
    .populate('expenses.items')
    .lean();

  if (!summary) throw new HttpError(404, 'Daily summary not found.');

  return summary;
};

const getPendingSummaries = async () => {
  return await DailySummary.find({ status: 'pending_approval' }).populate('branchId', 'name').sort({ date: -1 }).lean();
};

const updateDailySummaryStatus = async (summaryId, newStatus, rejectionReason, approverId) => {
  const session = await mongoose.startSession();

  try {
    let updated;

    await session.withTransaction(async () => {
      const summary = await DailySummary.findById(summaryId).session(session);
      if (!summary) throw new HttpError(404, 'Daily summary not found.');

      if (summary.status !== 'pending_approval') {
        throw new HttpError(400, 'Only pending summaries can be updated.');
      }

      summary.status = newStatus;
      summary.managerApproval = {
        isApproved: newStatus === 'approved',
        approvedBy: approverId,
        approvalDate: new Date(),
        rejectionReason: newStatus === 'rejected' ? rejectionReason : null,
      };

      await summary.save({ session });
      updated = summary;
    });

    return updated;
  } finally {
    session.endSession();
  }
};

const getTransactionHistory = async (filters = {}) => {
  const { startDate, endDate, branchId } = filters;
  const query = {};

  if (startDate) query.date = { $gte: startOfDay(startDate) };
  if (endDate) {
    if (!query.date) query.date = {};
    query.date.$lte = endOfDay(endDate);
  }
  if (branchId) query.branchId = branchId;

  const sales = await SaleTransaction.find(query).lean();
  const expenses = await ExpenseTransaction.find(query).lean();

  const history = [
    ...sales.map((s) => ({ ...s, type: 'Sale' })),
    ...expenses.map((e) => ({ ...e, type: 'Expense' })),
  ];

  history.sort((a, b) => {
    const dateA = new Date(a.date || a.createdAt);
    const dateB = new Date(b.date || b.createdAt);
    return dateB - dateA;
  });

  return history;
};

/**
 * Bulk migrations: wrap in transaction to avoid partial inserts
 * (Issue #2 mentions bulk migrations too)
 */
const bulkAddDailySummaries = async (summaries) => {
  if (!Array.isArray(summaries) || summaries.length === 0) {
    throw new HttpError(400, 'Invalid or empty array of summaries provided.');
  }
  console.debug(`[DEBUG] Service: Starting bulk migration for ${summaries.length} daily summaries.`);

  const validatedSummaries = summaries.map((summary) => {
    if (!summary.summaryId) {
      summary.summaryId = summary.dailySummaryId || uuidv4();
      delete summary.dailySummaryId;
    }
    if (!summary.status) {
      summary.status = 'approved';
    }
    return summary;
  });

  const session = await mongoose.startSession();
  try {
    let result = [];

    await session.withTransaction(async () => {
      result = await DailySummary.insertMany(validatedSummaries, { session, ordered: true });
    });

    console.debug(`[DEBUG] Service: Successfully migrated ${result.length} daily summaries.`);
    return result;
  } finally {
    session.endSession();
  }
};

const bulkAddExpenseTransactions = async (expenses) => {
  if (!Array.isArray(expenses) || expenses.length === 0) {
    throw new HttpError(400, 'Invalid or empty array of expenses provided.');
  }
  console.debug(`[DEBUG] Service: Starting bulk migration for ${expenses.length} expense transactions.`);

  // Validation + mapping happens before the transaction to keep the session work minimal.
  const validatedExpenses = await Promise.all(
    expenses.map(async (expense) => {
      if (!expense.date) {
        throw new HttpError(400, `Missing 'date' field for expense: ${expense.description}`);
      }

      if (expense.dailySummaryId) {
        const summary = await DailySummary.findOne({ summaryId: expense.dailySummaryId });
        if (!summary) {
          throw new HttpError(404, `Daily summary with UUID ${expense.dailySummaryId} not found.`);
        }
        expense.dailySummaryId = summary._id;
      }

      return expense;
    })
  );

  const session = await mongoose.startSession();
  try {
    let result = [];

    await session.withTransaction(async () => {
      result = await ExpenseTransaction.insertMany(validatedExpenses, { session, ordered: true });
    });

    console.debug(`[DEBUG] Service: Successfully migrated ${result.length} expense transactions.`);
    return result;
  } finally {
    session.endSession();
  }
};

module.exports = {
  createOrGetDailySummary,
  updateSummaryMeters,
  getDailyEntries,
  finalizeDailySummary,
  getDailySummaryReport,
  getPendingSummaries,
  updateDailySummaryStatus,
  getTransactionHistory,
  bulkAddDailySummaries,
  bulkAddExpenseTransactions,
  createSaleEntry,
  createExpenseEntry,
};
