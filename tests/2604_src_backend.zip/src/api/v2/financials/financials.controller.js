// src/api/v2/financials/financials.controller.js

const { Parser } = require('json2csv');
const Order = require('../../../models/order.model');
const DailySummary = require('../../../models/dailySummary.model');
const ExpenseTransaction = require('../../../models/expenseTransaction.model');
const Asset = require('../../../models/asset.model');
const Loan = require('../../../models/loan.model');
const StockIn = require('../../../models/stockIn.model');
const { logger } = require('../../../config/logger.config');
const HttpError = require('../../../utils/HttpError');
const mongoose = require('mongoose');

// ✅ NEW (GL support): optional models (only if you added them)
let ChartOfAccount = null;
let GeneralLedgerEntry = null;
try {
  ChartOfAccount = require('../../../models/chartOfAccount.model');
  GeneralLedgerEntry = require('../../../models/generalLedgerEntry.model');
} catch (e) {
  ChartOfAccount = null;
  GeneralLedgerEntry = null;
}

// Optional (recommended): wallet ledger model (only if it exists)
const WalletTransaction =
  mongoose.models?.WalletTransaction ||
  (() => {
    try {
      return mongoose.model('WalletTransaction');
    } catch (e) {
      return null;
    }
  })();

// -------------------------
// Tiny helpers
// -------------------------
const _safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const _asObjectId = (v) =>
  mongoose.Types.ObjectId.isValid(String(v)) ? new mongoose.Types.ObjectId(String(v)) : null;

const _endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

/**
 * IMPORTANT:
 * "branchId equals service zone id"
 *
 * Your DB can be mixed:
 *  - Some collections store branchId as ObjectId, some as string.
 *  - Some versions store serviceZoneId/zoneId/plantId.
 *
 * So we filter in a tolerant way:
 *  - match branchId as string OR ObjectId
 *  - OR match serviceZoneId/zoneId/plantId as string OR ObjectId
 */
const buildBranchOrZoneMatch = (branchIdOrZoneId) => {
  if (!branchIdOrZoneId) return {};

  const s = String(branchIdOrZoneId);
  const oid = _asObjectId(s);

  const ors = [{ branchId: s }, { serviceZoneId: s }, { zoneId: s }, { plantId: s }];

  if (oid) {
    ors.push({ branchId: oid });
    ors.push({ serviceZoneId: oid });
    ors.push({ zoneId: oid });
    ors.push({ plantId: oid });
  }

  return { $or: ors };
};

/**
 * Helper: Calculate Date Range
 * - Ensures end is inclusive (end-of-day)
 */
const getDateRange = (period = 'monthly', customStart, customEnd) => {
  const now = new Date();
  let start = new Date(now.getFullYear(), 0, 1);
  let end = new Date();

  if (period === 'monthly') {
    start = new Date(now.getFullYear(), now.getMonth(), 1);
  } else if (period === 'quarterly') {
    const quarter = Math.floor(now.getMonth() / 3);
    start = new Date(now.getFullYear(), quarter * 3, 1);
  } else if (period === 'yearly') {
    start = new Date(now.getFullYear(), 0, 1);
  } else if (period === 'custom' && customStart && customEnd) {
    start = new Date(customStart);
    end = new Date(customEnd);
  }

  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    start = new Date(now.getFullYear(), 0, 1);
    end = new Date();
  }

  // ✅ inclusive end-of-day to avoid missing same-day records
  end.setHours(23, 59, 59, 999);

  return { start, end };
};

/**
 * Revenue recognition rule (Delivery Orders):
 * - Recognize revenue ONLY when paymentStatus indicates PAID
 * - Delivered but unpaid becomes receivable (NOT revenue)
 */
const _isPaid = (paymentStatus) => {
  const ps = String(paymentStatus || '').toLowerCase().trim();
  return ps === 'completed' || ps === 'paid' || ps === 'success' || ps === 'successful';
};

/**
 * Keep deliveries-only intent:
 * - exclude cancelled
 * - optionally enforce channel if it exists
 */
const _ordersDeliveryGuard = () => ({
  status: { $ne: 'Canceled by Customer' },
  $or: [{ channel: { $exists: false } }, { channel: 'DELIVERY' }],
});

/**
 * Helper: Sum delivery orders
 * - recognizedRevenue: paid deliveries only
 * - invoicedRevenue: all delivered in period (paid+unpaid)
 * - unpaidDelivered: delivered but unpaid (for reconciliation/receivables)
 * - kgSold: quantity sum (if you store kg as quantity)
 */
const calcDeliverySales = (orders = []) => {
  let recognizedRevenue = 0;
  let invoicedRevenue = 0;
  let unpaidDelivered = 0;
  let kgSold = 0;

  for (const o of orders) {
    const amt = _safeNum(o.grandTotal, 0);
    invoicedRevenue += amt;

    if (_isPaid(o.paymentStatus)) recognizedRevenue += amt;
    else unpaidDelivered += amt;

    const items = Array.isArray(o.items) ? o.items : [];
    const itemKg = items.reduce((s, it) => s + _safeNum(it.quantity, 0), 0);
    if (itemKg > 0) kgSold += itemKg;
  }

  return { recognizedRevenue, invoicedRevenue, unpaidDelivered, kgSold };
};

/**
 * Helper: Sum POS revenue + kg from DailySummary (POS = DailySummary)
 *
 * ✅ CRITICAL: POS is filtered ONLY by business date field (DailySummary.date)
 *    We do NOT use createdAt for date filtering (per your instruction).
 */
const calcPosSales = (summaries = []) => {
  let revenue = 0;
  let kgSold = 0;

  for (const s of summaries) {
    revenue += _safeNum(s?.sales?.totalRevenue, 0);
    kgSold += _safeNum(s?.sales?.totalKgSold, 0);
  }

  return { revenue, kgSold };
};

/**
 * Helper: Inventory valuation from StockIn remainingKg * costPerKg (real-time)
 */
const calcInventoryValuation = (stockIns = []) => {
  let totalRemainingKg = 0;
  let totalValue = 0;

  for (const b of stockIns) {
    const rem = _safeNum(b.remainingKg, 0);
    const cpk = _safeNum(b.costPerKg, 0);
    totalRemainingKg += rem;
    totalValue += rem * cpk;
  }

  return { totalRemainingKg, totalValue };
};

/**
 * Helper: Weighted average cost per kg from StockIn batches up to end date
 */
const calcWeightedAvgCostPerKg = (stockIns = []) => {
  let totalKg = 0;
  let totalCost = 0;

  for (const b of stockIns) {
    const qty = _safeNum(b.quantityKg, 0);
    const cpk = _safeNum(b.costPerKg, 0);
    if (qty > 0 && cpk > 0) {
      totalKg += qty;
      totalCost += qty * cpk;
    }
  }

  const avg = totalKg > 0 ? totalCost / totalKg : 0;
  return { avgCostPerKg: avg, totalKgPurchased: totalKg, totalPurchaseCost: totalCost };
};

/**
 * Helper: Supplier payables (ONLY if you track payment info in StockIn)
 * We will not invent liabilities.
 */
const calcPayablesFromStockIns = (stockIns = []) => {
  let payables = 0;

  for (const s of stockIns) {
    const qty = _safeNum(s.quantityKg, 0);
    const cpk = _safeNum(s.costPerKg, 0);
    const totalCost = qty * cpk;

    const amountPaid = _safeNum(s.amountPaid ?? s.paidAmount, 0);
    const isPaid = typeof s.isPaid === 'boolean' ? s.isPaid : null;
    const paymentStatus = s.paymentStatus ? String(s.paymentStatus).toLowerCase() : null;

    const explicitlyPaid =
      isPaid === true ||
      paymentStatus === 'paid' ||
      paymentStatus === 'settled' ||
      paymentStatus === 'completed' ||
      paymentStatus === 'success' ||
      paymentStatus === 'successful';

    if (explicitlyPaid) continue;

    const hasPaymentSignals = 'amountPaid' in s || 'paidAmount' in s || 'isPaid' in s || 'paymentStatus' in s;
    if (!hasPaymentSignals) continue;

    const outstanding = Math.max(0, totalCost - amountPaid);
    payables += outstanding;
  }

  return payables;
};

/**
 * Helper: Receivables from Delivered-but-unpaid Orders (up to end date)
 */
const calcReceivablesFromOrders = (orders = []) => {
  let receivables = 0;

  for (const o of orders) {
    const st = String(o.status || '').toLowerCase();
    if (st.includes('cancel')) continue;

    // Only Delivered are receivable here
    if (String(o.status || '').toLowerCase() !== 'delivered') continue;

    if (!_isPaid(o.paymentStatus)) {
      receivables += _safeNum(o.grandTotal, 0);
    }
  }

  return receivables;
};

/**
 * Helper: Cash from wallet ledger (optional, best-effort)
 */
const calcCashFromWalletLedger = async (start, end, branchIdOrZoneId = null) => {
  if (!WalletTransaction) return null;

  const branchMatch = buildBranchOrZoneMatch(branchIdOrZoneId);

  // Try A) direction-based, prefer business "date"
  const rowsA = await WalletTransaction.aggregate([
    { $match: { ...branchMatch, date: { $gte: start, $lte: end } } },
    { $group: { _id: '$direction', total: { $sum: '$amount' } } },
  ]);

  const hasDirection = Array.isArray(rowsA) && rowsA.some((r) => r && r._id);
  if (hasDirection) {
    const credit = _safeNum(rowsA.find((r) => String(r._id).toUpperCase() === 'CREDIT')?.total, 0);
    const debit = _safeNum(rowsA.find((r) => String(r._id).toUpperCase() === 'DEBIT')?.total, 0);
    return credit - debit;
  }

  // Try B) type-based, use createdAt, COMPLETED only
  const rowsB = await WalletTransaction.aggregate([
    {
      $match: {
        ...branchMatch,
        createdAt: { $gte: start, $lte: end },
        status: { $in: ['COMPLETED', 'Completed', 'completed'] },
      },
    },
    { $group: { _id: '$type', total: { $sum: '$amount' } } },
  ]);

  if (!Array.isArray(rowsB) || rowsB.length === 0) return null;

  const sumBy = (types) =>
    rowsB
      .filter((r) => types.includes(String(r._id || '').toUpperCase()))
      .reduce((s, r) => s + _safeNum(r.total, 0), 0);

  const credits = sumBy(['DEPOSIT', 'ADJUSTMENT_CREDIT']);
  const debits = sumBy(['WITHDRAWAL', 'REFUND', 'ADJUSTMENT_DEBIT']);

  return credits - debits;
};

/**
 * Expense source strategy:
 * - Primary: ExpenseTransaction (true ledger of expenses; uses ExpenseTransaction.date)
 * - Fallback (ONLY if ExpenseTransaction has none in range):
 *     DailySummary.expenses.total (uses DailySummary.date)
 *
 * This avoids double-counting when you migrated and also logged separately.
 */
const calcExpenses = (expensesTx = [], summaries = []) => {
  const breakdown = {
    salaries: 0,
    logistics: 0,
    utilities: 0,
    maintenance: 0,
    marketing: 0,
    admin: 0,
    total: 0,
    source: 'ExpenseTransaction',
  };

  const applyCategory = (catRaw, amt) => {
    const cat = String(catRaw || '').toLowerCase();

    if (cat.includes('salar') || cat.includes('wages') || cat.includes('staff')) breakdown.salaries += amt;
    else if (
      cat.includes('fuel') ||
      cat.includes('transport') ||
      cat.includes('vehicle') ||
      cat.includes('dispatch') ||
      cat.includes('logistics')
    )
      breakdown.logistics += amt;
    else if (
      cat.includes('power') ||
      cat.includes('electric') ||
      cat.includes('internet') ||
      cat.includes('diesel') ||
      cat.includes('utility')
    )
      breakdown.utilities += amt;
    else if (cat.includes('maint') || cat.includes('repair') || cat.includes('service')) breakdown.maintenance += amt;
    else if (cat.includes('market') || cat.includes('adver') || cat.includes('promo')) breakdown.marketing += amt;
    else breakdown.admin += amt;
  };

  if (Array.isArray(expensesTx) && expensesTx.length > 0) {
    for (const exp of expensesTx) {
      const amt = _safeNum(exp.amount, 0);
      applyCategory(exp.category || exp.type, amt);
      breakdown.total += amt;
    }
    return breakdown;
  }

  // fallback: DailySummary.expenses.total
  breakdown.source = 'DailySummary.expenses.total (fallback)';
  let fallbackTotal = 0;

  for (const s of summaries || []) {
    fallbackTotal += _safeNum(s?.expenses?.total, 0);
  }

  // We cannot categorize reliably from DailySummary totals, so record as admin bucket
  breakdown.admin = fallbackTotal;
  breakdown.total = fallbackTotal;

  return breakdown;
};

// -------------------------
// ✅ NEW: GL helpers (if GL exists)
// -------------------------
const _glEnabled = () => Boolean(ChartOfAccount && GeneralLedgerEntry);

const _loadCOAMap = async () => {
  const rows = await ChartOfAccount.find({ isActive: true }).lean();
  const map = new Map();
  for (const a of rows) map.set(String(a.accountCode), a);
  return map;
};

const _glAggregateAccountSums = async ({ start, end, branchKey, mode }) => {
  // mode: 'period' => start..end
  // mode: 'toEnd'  => <= end
  const match = { status: 'POSTED' };

  if (mode === 'period') match.date = { $gte: start, $lte: end };
  else match.date = { $lte: end };

  if (branchKey) match.branchKey = String(branchKey);

  return GeneralLedgerEntry.aggregate([
    { $match: match },
    { $unwind: '$lines' },
    {
      $group: {
        _id: '$lines.accountCode',
        debit: { $sum: '$lines.debit' },
        credit: { $sum: '$lines.credit' },
      },
    },
  ]);
};

const _computeBalance = (coa, debit, credit) => {
  const nb = coa?.normalBalance || 'DEBIT';
  const d = _safeNum(debit, 0);
  const c = _safeNum(credit, 0);
  // Return signed balance based on normal side
  return nb === 'CREDIT' ? c - d : d - c;
};

const _mapAggRowsToMap = (rows) => {
  const m = new Map();
  for (const r of rows || []) {
    m.set(String(r._id), { debit: _safeNum(r.debit, 0), credit: _safeNum(r.credit, 0) });
  }
  return m;
};

// For INCOME/EQUITY/LIABILITY accounts, balance is naturally credit-heavy; we want "positive amount" for reporting.
const _asPositiveForType = (type, signedBalance) => {
  if (type === 'INCOME' || type === 'LIABILITY' || type === 'EQUITY') return Math.max(0, -1 * signedBalance);
  return Math.max(0, signedBalance);
};

const _getSignedBal = (coaMap, aggMap, code) => {
  const coa = coaMap.get(String(code));
  const row = aggMap.get(String(code)) || { debit: 0, credit: 0 };
  return _computeBalance(coa, row.debit, row.credit);
};

const _glHasAnyEntries = async ({ end, branchKey }) => {
  const q = { status: 'POSTED', date: { $lte: end } };
  if (branchKey) q.branchKey = String(branchKey);
  const one = await GeneralLedgerEntry.findOne(q).select('_id').lean();
  return Boolean(one);
};

/**
 * @desc    Generate Financial Statements
 * @route   GET /api/v2/financials/statements
 *
 * Supports:
 *  - period=monthly|quarterly|yearly|custom
 *  - startDate, endDate (custom)
 *  - branchId OR serviceZoneId (treat as same concept)
 *
 * CRITICAL ACCURACY FIXES:
 *  - Orders filtered by orderDate (fallback createdAt only when orderDate missing)
 *  - ExpenseTransaction filtered by date (NOT createdAt)
 *  - POS DailySummary filtered ONLY by DailySummary.date (NOT createdAt)
 *  - Delivery revenue recognized ONLY when paid
 *
 * ✅ NEW:
 *  - If General Ledger exists AND has postings, statements are generated from GL (audit-grade)
 *  - Otherwise fallback to operational aggregation (your existing logic)
 */
const getFinancialStatements = async (req, res, next) => {
  try {
    const { period, startDate: qStart, endDate: qEnd, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    const { start, end } = getDateRange(period, qStart, qEnd);

    // -------------------------
    // ✅ GL MODE (preferred if available + has postings)
    // -------------------------
    if (_glEnabled()) {
      const hasAny = await _glHasAnyEntries({ end, branchKey });
      if (hasAny) {
        const coaMap = await _loadCOAMap();

        const periodRows = await _glAggregateAccountSums({ start, end, branchKey, mode: 'period' });
        const toEndRows = await _glAggregateAccountSums({ start, end, branchKey, mode: 'toEnd' });

        const periodMap = _mapAggRowsToMap(periodRows);
        const toEndMap = _mapAggRowsToMap(toEndRows);

        // ---- P&L (period) ----
        const signedRevPos = _getSignedBal(coaMap, periodMap, '4000'); // INCOME
        const signedRevDel = _getSignedBal(coaMap, periodMap, '4010'); // INCOME
        const signedCogs = _getSignedBal(coaMap, periodMap, '5000');   // EXPENSE

        const signedSalaries = _getSignedBal(coaMap, periodMap, '6000');
        const signedLogistics = _getSignedBal(coaMap, periodMap, '6100');
        const signedUtilities = _getSignedBal(coaMap, periodMap, '6200');
        const signedMaintenance = _getSignedBal(coaMap, periodMap, '6300');
        const signedMarketing = _getSignedBal(coaMap, periodMap, '6400');
        const signedAdmin = _getSignedBal(coaMap, periodMap, '6500');

        const revenuePOS = _asPositiveForType('INCOME', signedRevPos);
        const revenueDeliveryRecognized = _asPositiveForType('INCOME', signedRevDel);
        const revenueOther = 0;

        const totalRevenue = revenuePOS + revenueDeliveryRecognized + revenueOther;

        const calculatedCogs = _asPositiveForType('EXPENSE', signedCogs);

        const salaries = _asPositiveForType('EXPENSE', signedSalaries);
        const logistics = _asPositiveForType('EXPENSE', signedLogistics);
        const utilities = _asPositiveForType('EXPENSE', signedUtilities);
        const maintenance = _asPositiveForType('EXPENSE', signedMaintenance);
        const marketing = _asPositiveForType('EXPENSE', signedMarketing);
        const admin = _asPositiveForType('EXPENSE', signedAdmin);

        const totalOpex = salaries + logistics + utilities + maintenance + marketing + admin;

        const grossProfit = totalRevenue - calculatedCogs;
        const ebitda = grossProfit - totalOpex;

        // If you later post depreciation/interest/tax journals, these will become real.
        const depreciation = 0;
        const interestExpense = 0;
        const tax = 0;
        const netIncome = ebitda - depreciation - interestExpense - tax;

        // ---- Balance Sheet (to end) ----
        const cashOnHand = _asPositiveForType('ASSET', _getSignedBal(coaMap, toEndMap, '1000'));
        const bankTransfers = _asPositiveForType('ASSET', _getSignedBal(coaMap, toEndMap, '1010'));
        const bankPOS = _asPositiveForType('ASSET', _getSignedBal(coaMap, toEndMap, '1020'));
        const receivables = _asPositiveForType('ASSET', _getSignedBal(coaMap, toEndMap, '1100'));
        const inventoryVal = _asPositiveForType('ASSET', _getSignedBal(coaMap, toEndMap, '1200'));

        const payables = _asPositiveForType('LIABILITY', _getSignedBal(coaMap, toEndMap, '2000'));
        const accrued = _asPositiveForType('LIABILITY', _getSignedBal(coaMap, toEndMap, '2100'));
        const taxPayable = _asPositiveForType('LIABILITY', _getSignedBal(coaMap, toEndMap, '2200'));

        const shareCapital = _asPositiveForType('EQUITY', _getSignedBal(coaMap, toEndMap, '3000'));
        const retainedEarnings = _asPositiveForType('EQUITY', _getSignedBal(coaMap, toEndMap, '3100'));

        const responseData = {
          income: {
            revenue: {
              total: totalRevenue,
              lpg: totalRevenue,
              delivery: revenueDeliveryRecognized,
              pos: revenuePOS,
              other: revenueOther,

              // GL mode: these are not computed unless you post invoice/AR-specific journals separately.
              deliveryInvoiced: null,
              deliveryUnpaidDelivered: null,
            },
            cogs: {
              total: calculatedCogs,
              purchases: null,
              avgCostPerKg: null,
              totalKgSold: null,
            },
            grossProfit,
            expenses: {
              salaries,
              logistics,
              utilities,
              maintenance,
              marketing,
              admin,
              total: totalOpex,
              source: 'GeneralLedgerEntry',
            },
            ebitda,
            depreciation,
            interest: interestExpense,
            tax,
            netIncome,
          },
          balance: {
            assets: [
              { name: 'Cash on Hand', value: _safeNum(cashOnHand, 0) },
              { name: 'Bank - Transfers', value: _safeNum(bankTransfers, 0) },
              { name: 'Bank - POS Settlements', value: _safeNum(bankPOS, 0) },
              { name: 'Inventory Stock', value: _safeNum(inventoryVal, 0) },
              { name: 'Trade Receivables', value: _safeNum(receivables, 0) },
            ],
            liabilities: [
              { name: 'Trade Payables', value: _safeNum(payables, 0) },
              { name: 'Accrued Expenses', value: _safeNum(accrued, 0) },
              { name: 'Tax Payable', value: _safeNum(taxPayable, 0) },
            ],
            equity: [
              { name: 'Share Capital', value: _safeNum(shareCapital, 0) },
              { name: 'Retained Earnings', value: _safeNum(retainedEarnings, 0) },
            ],
            inventoryMeta: {
              remainingKg: null,
              valuationMethod: 'GL account 1200 (Inventory - LPG)',
            },
            cashMeta: {
              source: 'General Ledger (double-entry)',
            },
            cautions: [
              'Statements generated from General Ledger postings (audit-grade).',
              'Depreciation/Interest/Tax are 0 unless you post journal entries for them.',
              'If you need delivery invoiced vs recognized breakdown, post an invoice/AR journal or derive from Orders in a separate reconciliation report.',
            ],
          },
          cashFlow: {
            operating: ebitda - tax,
            investing: 0,
            financing: 0,
          },
          ratios: {
            grossMargin: totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0,
            netMargin: totalRevenue > 0 ? (netIncome / totalRevenue) * 100 : 0,
            dscr: 0,
          },
          period: { start, end },
          branch: {
            branchId: branchKey,
            note: branchKey ? 'Filtered by branchId/serviceZoneId (GL branchKey)' : 'All branches combined',
          },
          gl: { enabled: true },
        };

        return res.status(200).json(responseData);
      }
    }

    // -------------------------
    // FALLBACK MODE (operational aggregation)
    // -------------------------
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    // -------------------------
    // DATA FETCH (parallel)
    // -------------------------
    const [
      ordersDeliveredInPeriod,
      posSummariesApproved,
      expensesInPeriod,
      assets,
      loans,
      stockInsInPeriod,
      stockInsUpToEnd,
      deliveredOrdersUpToEnd,
    ] = await Promise.all([
      // DELIVERY SALES: Orders (use orderDate, fallback createdAt ONLY if orderDate missing)
      Order.find({
        ...branchMatch,
        ..._ordersDeliveryGuard(),
        status: 'Delivered',
        $or: [
          { orderDate: { $gte: start, $lte: end } },
          { orderDate: { $exists: false }, createdAt: { $gte: start, $lte: end } },
        ],
      })
        .select('grandTotal items paymentMethod paymentStatus status createdAt orderDate branchId channel serviceZoneId zoneId plantId')
        .lean(),

      // ✅ POS SALES: Daily Summary — filter ONLY by business date field (date), NOT createdAt
      DailySummary.find({
        ...branchMatch,
        status: 'approved',
        date: { $gte: start, $lte: end },
      }).lean(),

      // ✅ EXPENSES: IMPORTANT -> use business "date", NOT createdAt
      ExpenseTransaction.find({
        ...branchMatch,
        date: { $gte: start, $lte: end },
      }).lean(),

      Asset.find({}).lean(),
      Loan.find({}).lean(),

      // Stock purchases in period
      StockIn.find({
        ...branchMatch,
        purchaseDate: { $gte: start, $lte: end },
      }).lean(),

      // Stock purchases up to end date (for WAC + inventory valuation)
      StockIn.find({
        ...branchMatch,
        purchaseDate: { $lte: end },
      }).lean(),

      // Delivered orders up to end date (for receivables)
      Order.find({
        ...branchMatch,
        ..._ordersDeliveryGuard(),
        status: 'Delivered',
        $or: [
          { orderDate: { $lte: end } },
          { orderDate: { $exists: false }, createdAt: { $lte: end } },
        ],
      })
        .select('grandTotal paymentStatus status createdAt orderDate branchId channel serviceZoneId zoneId plantId')
        .lean(),
    ]);

    // -------------------------
    // A) INCOME STATEMENT (P&L)
    // -------------------------
    const delivery = calcDeliverySales(ordersDeliveredInPeriod);
    const pos = calcPosSales(posSummariesApproved);

    // ✅ Revenue recognition:
    // - Delivery recognized only when paid
    // - POS recognized from approved DailySummary within business date window
    const revenueDeliveryRecognized = delivery.recognizedRevenue;
    const revenueDeliveryInvoiced = delivery.invoicedRevenue;
    const revenueDeliveryUnpaidDelivered = delivery.unpaidDelivered;

    const revenuePOS = pos.revenue;
    const revenueOther = 0;

    const totalRevenue = revenueDeliveryRecognized + revenuePOS + revenueOther;
    const totalKgSold = _safeNum(delivery.kgSold, 0) + _safeNum(pos.kgSold, 0);

    // Purchases in period (real)
    const purchases = (stockInsInPeriod || []).reduce(
      (sum, s) => sum + _safeNum(s.quantityKg, 0) * _safeNum(s.costPerKg, 0),
      0
    );

    // ✅ COGS: Weighted Average Cost (WAC) × kg sold
    const { avgCostPerKg } = calcWeightedAvgCostPerKg(stockInsUpToEnd);
    const calculatedCogs = totalKgSold * avgCostPerKg;

    // ✅ OPEX: primary from ExpenseTransaction.date; fallback only if none found
    const expenseBreakdown = calcExpenses(expensesInPeriod, posSummariesApproved);
    const totalOpex = _safeNum(expenseBreakdown.total, 0);

    const grossProfit = totalRevenue - calculatedCogs;
    const ebitda = grossProfit - totalOpex;

    // Depreciation (proxy unless you implement schedules)
    const totalFixedAssets = (assets || []).reduce((sum, a) => sum + _safeNum(a.cost, 0), 0);
    const annualDepreciation = (assets || []).reduce((sum, a) => sum + _safeNum(a.cost, 0) * 0.15, 0); // 15% proxy
    const depreciation = period === 'monthly' ? annualDepreciation / 12 : annualDepreciation;

    // Interest (proxy from Loan model)
    const interestExpense = (loans || []).reduce((sum, l) => {
      const principal = _safeNum(l.principal, 0);
      const rate = _safeNum(l.interestRate, 0) / 100;
      if (principal <= 0 || rate <= 0) return sum;
      return sum + (principal * rate) / (period === 'monthly' ? 12 : 1);
    }, 0);

    const profitBeforeTax = ebitda - depreciation - interestExpense;
    const tax = profitBeforeTax > 0 ? profitBeforeTax * 0.3 : 0;
    const netIncome = profitBeforeTax - tax;

    // -------------------------
    // B) BALANCE SHEET
    // -------------------------
    const inventory = calcInventoryValuation(stockInsUpToEnd);

    // ✅ Receivables = Delivered but unpaid (up to end)
    const receivables = calcReceivablesFromOrders(deliveredOrdersUpToEnd);

    // Payables (only if StockIn has payment fields)
    const payables = calcPayablesFromStockIns(stockInsUpToEnd);

    // Cash: ledger preferred; fallback estimate if ledger not available
    let cashFromLedger = null;
    try {
      cashFromLedger = await calcCashFromWalletLedger(start, end, branchKey);
    } catch (e) {
      cashFromLedger = null;
    }

    // Fallback cash estimate (not audit-grade)
    const cashFallback = totalRevenue - totalOpex - purchases;
    const cash = cashFromLedger !== null ? cashFromLedger : cashFallback;

    const accumulatedDepreciation = Math.min(totalFixedAssets, totalFixedAssets * 0.3); // proxy
    const netFixedAssets = totalFixedAssets - accumulatedDepreciation;

    const liabilities = {
      payables,
      taxPayable: tax,
      longTermLoans: (loans || []).reduce((sum, l) => sum + _safeNum(l.principal, 0), 0),
    };

    const equity = {
      shareCapital: 10_000_000, // move to settings later
      retainedEarnings: Math.max(0, netIncome),
    };

    // -------------------------
    // C) RATIOS
    // -------------------------
    const annualDebtService = (loans || []).reduce((sum, l) => {
      const principal = _safeNum(l.principal, 0);
      const term = _safeNum(l.term, 0);
      const rate = _safeNum(l.interestRate, 0) / 100;
      if (principal <= 0) return sum;

      const principalRepay = term > 0 ? principal / term : 0;
      const interest = principal * rate;
      return sum + principalRepay + interest;
    }, 0);

    const periodDebtService = period === 'monthly' ? annualDebtService / 12 : annualDebtService;
    const dscr = periodDebtService > 0 ? ebitda / periodDebtService : 0;

    const responseData = {
      income: {
        revenue: {
          total: totalRevenue,
          lpg: revenueDeliveryRecognized + revenuePOS,
          delivery: revenueDeliveryRecognized,
          pos: revenuePOS,
          other: revenueOther,

          // ✅ transparency/debug/reconciliation
          deliveryInvoiced: revenueDeliveryInvoiced,
          deliveryUnpaidDelivered: revenueDeliveryUnpaidDelivered,
        },
        cogs: {
          total: calculatedCogs,
          purchases,
          avgCostPerKg,
          totalKgSold,
        },
        grossProfit,
        expenses: {
          salaries: _safeNum(expenseBreakdown.salaries, 0),
          logistics: _safeNum(expenseBreakdown.logistics, 0),
          utilities: _safeNum(expenseBreakdown.utilities, 0),
          maintenance: _safeNum(expenseBreakdown.maintenance, 0),
          marketing: _safeNum(expenseBreakdown.marketing, 0),
          admin: _safeNum(expenseBreakdown.admin, 0),
          total: totalOpex,
          source: expenseBreakdown.source,
        },
        ebitda,
        depreciation,
        interest: interestExpense,
        tax,
        netIncome,
      },
      balance: {
        assets: [
          { name: 'Net Fixed Assets (PPE)', value: _safeNum(netFixedAssets, 0) },
          { name: 'Cash & Equivalents', value: Math.abs(_safeNum(cash, 0)) },
          { name: 'Inventory Stock', value: _safeNum(inventory.totalValue, 0) },
          { name: 'Trade Receivables', value: _safeNum(receivables, 0) },
        ],
        liabilities: [
          { name: 'Trade Payables', value: _safeNum(liabilities.payables, 0) },
          { name: 'Tax Provision', value: _safeNum(liabilities.taxPayable, 0) },
          { name: 'Long Term Loans', value: _safeNum(liabilities.longTermLoans, 0) },
        ],
        equity: [
          { name: 'Share Capital', value: _safeNum(equity.shareCapital, 0) },
          { name: 'Retained Earnings', value: _safeNum(equity.retainedEarnings, 0) },
        ],
        inventoryMeta: {
          remainingKg: _safeNum(inventory.totalRemainingKg, 0),
          valuationMethod: 'SUM(StockIn.remainingKg * StockIn.costPerKg)',
        },
        cashMeta: {
          source:
            cashFromLedger !== null
              ? 'WalletTransaction ledger/proxy (best-effort)'
              : 'Fallback estimate (recognized revenue - opex - purchases)',
        },
        cautions: [
          'COGS uses Weighted Average Cost (WAC) × kg sold. For audit-grade FIFO/LIFO, introduce a SaleLedger tied to StockIn batches.',
          'Payables only computed if StockIn includes payment fields (amountPaid/isPaid/paymentStatus). Otherwise payables remain 0 (no assumptions).',
          'Delivery revenue is recognized only when paid. Delivered-but-unpaid orders are treated as Receivables.',
          'POS revenue is sourced from approved DailySummary records filtered by DailySummary.date (business date), not createdAt.',
          `Expenses are sourced from ${expenseBreakdown.source}. Filtering is always by business date (ExpenseTransaction.date / DailySummary.date).`,
          'WalletTransaction is not a perfect substitute for a bank/cash ledger; treat cashMeta as indicative until you implement a true General Ledger.',
          'GL module: if ChartOfAccount + GeneralLedgerEntry exist and have postings, statements automatically switch to GL mode.',
        ],
      },
      cashFlow: {
        operating: ebitda + depreciation - tax,
        investing:
          -1 *
          (assets || [])
            .filter((a) => a?.createdAt && new Date(a.createdAt) > start)
            .reduce((s, a) => s + _safeNum(a.cost, 0), 0),
        financing:
          (loans || [])
            .filter((l) => l?.createdAt && new Date(l.createdAt) > start)
            .reduce((s, l) => s + _safeNum(l.principal, 0), 0),
      },
      ratios: {
        grossMargin: totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0,
        netMargin: totalRevenue > 0 ? (netIncome / totalRevenue) * 100 : 0,
        dscr,
      },
      period: { start, end },
      branch: {
        branchId: branchKey,
        note: branchKey ? 'Filtered by branchId/serviceZoneId tolerant match' : 'All branches combined',
      },
      gl: { enabled: false },
      debug: {
        delivery: {
          deliveredOrdersInPeriod: Array.isArray(ordersDeliveredInPeriod) ? ordersDeliveredInPeriod.length : 0,
          recognizedRevenue: revenueDeliveryRecognized,
          invoicedRevenue: revenueDeliveryInvoiced,
          unpaidDelivered: revenueDeliveryUnpaidDelivered,
        },
        pos: {
          approvedDailySummariesInPeriod: Array.isArray(posSummariesApproved) ? posSummariesApproved.length : 0,
          posRevenue: revenuePOS,
        },
        expenses: {
          expenseTxCount: Array.isArray(expensesInPeriod) ? expensesInPeriod.length : 0,
          expenseSource: expenseBreakdown.source,
        },
      },
    };

    return res.status(200).json(responseData);
  } catch (error) {
    logger.error(`[FINANCIALS] Error generating statements: ${error.message}`, error);
    return next(new HttpError(500, 'Financial generation failed'));
  }
};

/**
 * @desc    Export Data to CSV/Excel for External Auditors/Banks
 * @route   GET /api/v2/financials/export
 *
 * Supports: branchId/serviceZoneId filters
 *
 * ACCURACY FIXES:
 *  - Sales export uses orderDate (fallback createdAt only when orderDate missing)
 *  - Expenses export uses date (NOT createdAt)
 *  - POS export uses DailySummary.date (NOT createdAt)
 */
const exportData = async (req, res, next) => {
  try {
    const { type, start, end, format, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    let data = [];
    let filename = 'report';

    const s = start ? new Date(start) : null;
    const e = end ? new Date(end) : null;

    if (!s || !e || Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) {
      throw new HttpError(400, 'Invalid start/end date supplied.');
    }

    // inclusive end-of-day
    e.setHours(23, 59, 59, 999);

    if (type === 'sales') {
      const orders = await Order.find({
        ...branchMatch,
        ..._ordersDeliveryGuard(),
        $or: [
          { orderDate: { $gte: s, $lte: e } },
          { orderDate: { $exists: false }, createdAt: { $gte: s, $lte: e } },
        ],
      }).lean();

      data = orders.map((o) => {
        const dt = o.orderDate || o.createdAt || new Date();
        const st = String(o.status || '').toLowerCase();
        const delivered = st === 'delivered';

        return {
          Date: new Date(dt).toISOString().split('T')[0],
          OrderID: o.id || o._id,
          Customer: o.recipientName || '',
          Amount: _safeNum(o.grandTotal, 0),
          Status: o.status || '',
          Payment: o.paymentMethod || '',
          PaymentStatus: o.paymentStatus || '',
          RecognizedRevenue: delivered && _isPaid(o.paymentStatus) ? _safeNum(o.grandTotal, 0) : 0,
          ReceivableIfUnpaidDelivered: delivered && !_isPaid(o.paymentStatus) ? _safeNum(o.grandTotal, 0) : 0,
          BranchId: o.branchId || o.serviceZoneId || o.zoneId || o.plantId || '',
        };
      });

      filename = 'sales_ledger';
    } else if (type === 'financials') {
      // ✅ EXPENSES: business date
      const expenses = await ExpenseTransaction.find({ ...branchMatch, date: { $gte: s, $lte: e } }).lean();

      const expenseRows = (expenses || []).map((x) => ({
        Date: (x.date ? new Date(x.date) : new Date()).toISOString().split('T')[0],
        Type: 'Expense',
        Category: x.category || x.type || '',
        Description: x.description || '',
        Debit: _safeNum(x.amount, 0),
        Credit: 0,
        BranchId: x.branchId || x.serviceZoneId || x.zoneId || x.plantId || '',
      }));

      // ✅ POS: business date
      const posSummaries = await DailySummary.find({
        ...branchMatch,
        status: 'approved',
        date: { $gte: s, $lte: e },
      }).lean();

      const posRows = (posSummaries || []).map((d) => ({
        Date: (d.date ? new Date(d.date) : new Date()).toISOString().split('T')[0],
        Type: 'POS',
        Category: 'DailySummary.sales.totalRevenue',
        Description: `POS sales (${d.cashierName || 'Cashier'})`,
        Debit: 0,
        Credit: _safeNum(d?.sales?.totalRevenue, 0),
        BranchId: d.branchId || d.serviceZoneId || d.zoneId || d.plantId || '',
      }));

      let walletRows = [];
      if (WalletTransaction) {
        const w = await WalletTransaction.find({
          ...branchMatch,
          $or: [{ date: { $gte: s, $lte: e } }, { createdAt: { $gte: s, $lte: e } }],
        }).lean();

        walletRows = (w || []).map((t) => {
          const direction = String(t.direction || '').toUpperCase();
          const typeU = String(t.type || '').toUpperCase();

          // ledger-style
          const isDebitLedger = direction === 'DEBIT';
          const isCreditLedger = direction === 'CREDIT';

          // wallet-style (proxy)
          const isCreditWallet = ['DEPOSIT', 'ADJUSTMENT_CREDIT'].includes(typeU);
          const isDebitWallet = ['WITHDRAWAL', 'REFUND', 'ADJUSTMENT_DEBIT', 'FEE'].includes(typeU);

          const isDebit = isDebitLedger || (!direction && isDebitWallet);
          const isCredit = isCreditLedger || (!direction && isCreditWallet);

          const dt = t.date || t.createdAt || new Date();

          return {
            Date: new Date(dt).toISOString().split('T')[0],
            Type: 'Wallet',
            Category: t.direction || t.type || '',
            Description: t.narration || t.referenceType || t.description || '',
            Debit: isDebit ? _safeNum(t.amount, 0) : 0,
            Credit: isCredit ? _safeNum(t.amount, 0) : 0,
            BranchId: t.branchId || t.serviceZoneId || t.zoneId || t.plantId || '',
          };
        });
      }

      data = [...expenseRows, ...posRows, ...walletRows];
      filename = 'general_ledger';
    } else if (type === 'inventory') {
      const stock = await StockIn.find({ ...branchMatch, purchaseDate: { $gte: s, $lte: e } }).lean();

      data = (stock || []).map((b) => ({
        Date: b.purchaseDate ? new Date(b.purchaseDate).toISOString().split('T')[0] : '',
        Supplier: b.supplier || '',
        QuantityKg: _safeNum(b.quantityKg, 0),
        RemainingKg: _safeNum(b.remainingKg, 0),
        CostPerKg: _safeNum(b.costPerKg, 0),
        TotalCost: _safeNum(b.quantityKg, 0) * _safeNum(b.costPerKg, 0),
        RemainingValue: _safeNum(b.remainingKg, 0) * _safeNum(b.costPerKg, 0),
        PaymentStatus: b.paymentStatus || (typeof b.isPaid === 'boolean' ? (b.isPaid ? 'paid' : 'unpaid') : ''),
        AmountPaid: _safeNum(b.amountPaid ?? b.paidAmount, 0),
        BranchId: b.branchId || b.serviceZoneId || b.zoneId || b.plantId || '',
      }));

      filename = 'inventory_valuation';
    } else {
      throw new HttpError(400, 'Invalid export type. Use sales | financials | inventory.');
    }

    if (branchKey) filename = `${filename}_${String(branchKey).slice(0, 12)}`;

    if (format === 'csv') {
      const parser = new Parser();
      const csv = parser.parse(data);
      res.header('Content-Type', 'text/csv');
      res.attachment(`${filename}.csv`);
      return res.send(csv);
    }

    return res.json(data);
  } catch (e) {
    return next(e instanceof HttpError ? e : new HttpError(500, 'Export failed'));
  }
};

/**
 * Revenue assurance report
 * - Uses StockIn batches and DELIVERY Orders between batches
 * - Supports branchId/serviceZoneId filter
 *
 * ACCURACY FIX:
 * - Orders date uses orderDate (fallback createdAt only when orderDate missing)
 * - Recognize revenue only when paid (to align with financial statements)
 */
const getRevenueAssuranceReport = async (req, res, next) => {
  try {
    const { branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const batches = await StockIn.find({ ...branchMatch }).sort({ purchaseDate: -1 }).limit(20).lean();

    const report = await Promise.all(
      (batches || []).map(async (batch) => {
        const nextBatch = await StockIn.findOne({
          ...branchMatch,
          purchaseDate: { $gt: batch.purchaseDate },
        }).sort({ purchaseDate: 1 });

        const endDate = nextBatch ? nextBatch.purchaseDate : new Date();

        const sales = await Order.aggregate([
          {
            $match: {
              ...branchMatch,
              ..._ordersDeliveryGuard(),
              status: 'Delivered',
              $or: [
                { orderDate: { $gte: new Date(batch.purchaseDate), $lt: new Date(endDate) } },
                {
                  orderDate: { $exists: false },
                  createdAt: { $gte: new Date(batch.purchaseDate), $lt: new Date(endDate) },
                },
              ],
            },
          },
          {
            $group: {
              _id: null,
              totalInvoiced: { $sum: '$grandTotal' },
              totalRecognized: {
                $sum: {
                  $cond: [
                    {
                      $in: [
                        { $toLower: { $ifNull: ['$paymentStatus', ''] } },
                        ['completed', 'paid', 'success', 'successful'],
                      ],
                    },
                    '$grandTotal',
                    0,
                  ],
                },
              },
              count: { $sum: 1 },
            },
          },
        ]);

        const actualInvoicedRevenue = _safeNum(sales[0]?.totalInvoiced, 0);
        const actualRecognizedRevenue = _safeNum(sales[0]?.totalRecognized, 0);

        const expectedRevenue = _safeNum(batch.quantityKg, 0) * _safeNum(batch.targetSalePricePerKg, 0);
        const discrepancy = actualRecognizedRevenue - expectedRevenue;

        const integrityScore =
          expectedRevenue > 0 ? Math.max(0, 100 - (Math.abs(discrepancy) / expectedRevenue) * 100) : 0;

        return {
          branchId: batch.branchId || branchKey || null,
          batchId: batch._id,
          date: batch.purchaseDate,
          supplier: batch.supplier,
          quantityKg: _safeNum(batch.quantityKg, 0),
          expectedRevenue,
          actualInvoicedRevenue,
          actualRecognizedRevenue,
          discrepancyRecognizedVsExpected: discrepancy,
          integrityScore: Math.round(integrityScore),
          progress: 100,
        };
      })
    );

    return res.status(200).json(report);
  } catch (e) {
    return next(e);
  }
};

/**
 * Tax compliance report (data-driven)
 * - Supports branchId/serviceZoneId filter
 *
 * ACCURACY FIX:
 * - Orders use orderDate (fallback createdAt only when orderDate missing)
 * - POS uses DailySummary.date (NOT createdAt)
 * - Expenses use business date
 * - Delivery revenue uses recognized (paid) to align with financial statements
 */
const getTaxComplianceReport = async (req, res, next) => {
  try {
    const { branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;
    const branchMatch = buildBranchOrZoneMatch(branchKey);

    const { start, end } = getDateRange('yearly');

    const [ordersDeliveredYear, posSummariesApproved, expensesYear] = await Promise.all([
      Order.find({
        ...branchMatch,
        ..._ordersDeliveryGuard(),
        status: 'Delivered',
        $or: [
          { orderDate: { $gte: start, $lte: end } },
          { orderDate: { $exists: false }, createdAt: { $gte: start, $lte: end } },
        ],
      })
        .select('grandTotal paymentStatus orderDate createdAt status')
        .lean(),

      // ✅ POS: strictly by date
      DailySummary.find({
        ...branchMatch,
        status: 'approved',
        date: { $gte: start, $lte: end },
      }).lean(),

      ExpenseTransaction.find({
        ...branchMatch,
        date: { $gte: start, $lte: end },
      }).lean(),
    ]);

    const deliveryRecognized = (ordersDeliveredYear || []).reduce((sum, o) => {
      const delivered = String(o.status || '').toLowerCase() === 'delivered';
      return sum + (delivered && _isPaid(o.paymentStatus) ? _safeNum(o.grandTotal, 0) : 0);
    }, 0);

    const posRev = (posSummariesApproved || []).reduce((sum, s) => sum + _safeNum(s?.sales?.totalRevenue, 0), 0);
    const totalRevenue = deliveryRecognized + posRev;

    const totalExpenses = (expensesYear || []).reduce((sum, e) => sum + _safeNum(e.amount, 0), 0);

    // VAT (assumed 7.5%) — adjust if you treat POS/delivery differently
    const vatPayable = totalRevenue * 0.075;

    return res.status(200).json({
      branchId: branchKey,
      taxableRevenue: totalRevenue,
      vatPayable,
      totalExpenses,
      citStatus: 'Pioneer Status Exempt',
      filingDueDate: '2025-01-21',
      period: { start, end },
      notes: [
        'Delivery revenue used here is recognized (paid) to align with Management Accounts.',
        'POS is sourced from approved DailySummary records filtered by DailySummary.date (business date), not createdAt.',
        'Expenses are filtered by ExpenseTransaction.date (business date), not createdAt.',
        'If VAT should be computed on invoiced deliveries (paid+unpaid), switch to summing all delivered grandTotal.',
      ],
    });
  } catch (e) {
    return next(e);
  }
};

module.exports = {
  getFinancialStatements,
  exportData,
  getRevenueAssuranceReport,
  getTaxComplianceReport,
};
