// File: src/api/v2/gl/gl.controller.js

const HttpError = require('../../../utils/HttpError');
const { logger } = require('../../../config/logger.config');

const ChartOfAccount = require('../../../models/chartOfAccount.model');
const GeneralLedgerEntry = require('../../../models/generalLedgerEntry.model');

// ✅ GL Orchestrator (single source of truth for posting)
// Expected exports (GL-first):
//  - bootstrap()
//  - rebuild({ startDate, endDate, branchId, dryRun })
//  - postApproved({ date, branchId })
//  - retryFailed({ startDate, endDate, branchId })
//  - postingExceptions({ startDate, endDate, branchId })
//  - trialBalance({ startDate, endDate, branchId })
const posting = require('./posting.service');

const {
  bootstrap,
  rebuild: rebuildPosting,
  postApproved,
  retryFailed,
  postingExceptions,
  trialBalance: trialBalanceService,
} = posting;

// -------------------- tiny helpers --------------------

const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

// -------------------- Controllers --------------------

// GET /api/v2/gl/coa
const getCOA = async (req, res, next) => {
  try {
    const rows = await ChartOfAccount.find({ isActive: true }).sort({ accountCode: 1 }).lean();
    return res.json(rows);
  } catch (e) {
    logger.error('[GL] getCOA error', e);
    return next(new HttpError(500, 'Failed to fetch COA'));
  }
};

// POST /api/v2/gl/bootstrap
const bootstrapCOA = async (req, res, next) => {
  try {
    if (typeof bootstrap !== 'function') {
      return next(new HttpError(501, 'GL bootstrap is not available (posting.service.bootstrap missing)'));
    }

    const result = await bootstrap();
    return res.json({ ok: true, ...result });
  } catch (e) {
    logger.error('[GL] bootstrap error', e);
    return next(new HttpError(500, 'Failed to bootstrap COA'));
  }
};

// POST /api/v2/gl/rebuild?startDate=&endDate=&branchId=&serviceZoneId=&dryRun=
const rebuild = async (req, res, next) => {
  try {
    const { startDate, endDate, branchId, serviceZoneId, dryRun } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    if (!startDate || !endDate) {
      return next(new HttpError(400, 'startDate and endDate are required'));
    }

    if (typeof rebuildPosting !== 'function') {
      return next(new HttpError(501, 'GL rebuild is not available (posting.service.rebuild missing)'));
    }

    const s = toISODate(startDate);
    const e = toISODate(endDate);
    if (!s || !e) return next(new HttpError(400, 'Invalid startDate or endDate'));

    const result = await rebuildPosting({
      startDate,
      endDate,
      branchId: branchKey,
      dryRun: String(dryRun || '').toLowerCase() === 'true',
    });

    return res.json({ ok: true, ...result });
  } catch (e) {
    logger.error('[GL] rebuild error', e);
    return next(new HttpError(500, e.message || 'GL rebuild failed'));
  }
};

// POST /api/v2/gl/post-approved?date=YYYY-MM-DD&branchId=&serviceZoneId=
const postApprovedForDate = async (req, res, next) => {
  try {
    const { date, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    if (!date) return next(new HttpError(400, 'date is required (YYYY-MM-DD)'));
    if (typeof postApproved !== 'function') {
      return next(new HttpError(501, 'post-approved is not available (posting.service.postApproved missing)'));
    }

    const d = toISODate(date);
    if (!d) return next(new HttpError(400, 'Invalid date. Use YYYY-MM-DD'));

    const result = await postApproved({ date, branchId: branchKey });
    return res.json({ ok: true, date: d.toISOString().slice(0, 10), branchId: branchKey, ...result });
  } catch (e) {
    logger.error('[GL] post-approved error', e);
    return next(new HttpError(500, e.message || 'Failed to post approved documents'));
  }
};

// POST /api/v2/gl/retry-failed?startDate=&endDate=&branchId=&serviceZoneId=
const retryFailedPostings = async (req, res, next) => {
  try {
    const { startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    if (!startDate || !endDate) return next(new HttpError(400, 'startDate and endDate are required'));
    if (typeof retryFailed !== 'function') {
      return next(new HttpError(501, 'retry-failed is not available (posting.service.retryFailed missing)'));
    }

    const s = toISODate(startDate);
    const e = toISODate(endDate);
    if (!s || !e) return next(new HttpError(400, 'Invalid startDate or endDate'));

    const result = await retryFailed({ startDate, endDate, branchId: branchKey });
    return res.json({
      ok: true,
      start: s.toISOString(),
      end: endOfDay(e).toISOString(),
      branchId: branchKey,
      ...result,
    });
  } catch (e) {
    logger.error('[GL] retry-failed error', e);
    return next(new HttpError(500, e.message || 'Failed to retry failed postings'));
  }
};

// GET /api/v2/gl/posting-exceptions?startDate=&endDate=&branchId=&serviceZoneId=
const getPostingExceptions = async (req, res, next) => {
  try {
    const { startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    if (!startDate || !endDate) return next(new HttpError(400, 'startDate and endDate are required'));
    if (typeof postingExceptions !== 'function') {
      return next(
        new HttpError(501, 'posting-exceptions is not available (posting.service.postingExceptions missing)')
      );
    }

    const s = toISODate(startDate);
    const e = toISODate(endDate);
    if (!s || !e) return next(new HttpError(400, 'Invalid startDate or endDate'));

    const result = await postingExceptions({ startDate, endDate, branchId: branchKey });
    return res.json({
      ok: true,
      start: s.toISOString(),
      end: endOfDay(e).toISOString(),
      branchId: branchKey,
      ...result,
    });
  } catch (e) {
    logger.error('[GL] posting-exceptions error', e);
    return next(new HttpError(500, e.message || 'Failed to fetch posting exceptions'));
  }
};

// GET /api/v2/gl/trial-balance?startDate=&endDate=&branchId=&serviceZoneId=
const getTrialBalance = async (req, res, next) => {
  try {
    const { startDate, endDate, branchId, serviceZoneId } = req.query;
    const branchKey = branchId || serviceZoneId || null;

    // Preferred path: use posting.service trialBalance (keeps logic consistent)
    if (startDate && endDate) {
      if (typeof trialBalanceService !== 'function') {
        return next(new HttpError(501, 'trial-balance is not available (posting.service.trialBalance missing)'));
      }

      const tb = await trialBalanceService({ startDate, endDate, branchId: branchKey });

      // tb is expected to already include COA metadata per row
      return res.json({
        period: {
          start: toISODate(startDate) || new Date(startDate),
          end: endOfDay(toISODate(endDate) || new Date(endDate)),
        },
        branch: { branchId: branchKey || null },
        totals: {
          debit: safeNum(tb?.totals?.debit, 0),
          credit: safeNum(tb?.totals?.credit, 0),
          balanced: Boolean(tb?.ok),
          diff: safeNum(tb?.diff, 0),
        },
        rows: (tb?.rows || []).map((r) => ({
          accountCode: String(r.accountCode),
          name: r.accountName || 'Unknown',
          type: r.accountType || 'UNKNOWN',
          normalBalance: r.normalBalance || null,
          debit: safeNum(r.debit, 0),
          credit: safeNum(r.credit, 0),
          balance: safeNum(r.balance, 0),
        })),
      });
    }

    // Manual mode (no dates supplied) - aggregate directly from GL collection
    const start = startDate ? toISODate(startDate) : new Date('2000-01-01');
    const end = endDate ? endOfDay(toISODate(endDate)) : endOfDay(new Date());

    if (!start || !end || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
      return next(new HttpError(400, 'Invalid date range'));
    }

    const match = { status: 'POSTED', date: { $gte: start, $lte: end } };

    // Compatibility: match either branchKey or branchId fields
    if (branchKey) {
      const b = String(branchKey);
      match.$or = [{ branchKey: b }, { branchId: b }];
    }

    const rows = await GeneralLedgerEntry.aggregate([
      { $match: match },
      { $unwind: '$lines' },
      {
        $group: {
          _id: '$lines.accountCode',
          debit: { $sum: '$lines.debit' },
          credit: { $sum: '$lines.credit' },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const coa = await ChartOfAccount.find({ isActive: true }).lean();
    const coaMap = new Map(coa.map((a) => [String(a.accountCode), a]));

    const shaped = rows.map((r) => {
      const meta = coaMap.get(String(r._id)) || null;
      const debit = safeNum(r.debit, 0);
      const credit = safeNum(r.credit, 0);
      const balance = meta?.normalBalance === 'CREDIT' ? credit - debit : debit - credit;
      return {
        accountCode: String(r._id),
        name: meta?.name || 'Unknown',
        type: meta?.type || 'UNKNOWN',
        normalBalance: meta?.normalBalance || null,
        debit,
        credit,
        balance,
      };
    });

    const totalDebit = shaped.reduce((s, x) => s + safeNum(x.debit, 0), 0);
    const totalCredit = shaped.reduce((s, x) => s + safeNum(x.credit, 0), 0);

    return res.json({
      period: { start, end },
      branch: { branchId: branchKey || null },
      totals: {
        debit: totalDebit,
        credit: totalCredit,
        balanced: Math.abs(totalDebit - totalCredit) <= 0.5,
        diff: Math.abs(totalDebit - totalCredit),
      },
      rows: shaped,
    });
  } catch (e) {
    logger.error('[GL] trial balance error', e);
    return next(new HttpError(500, e.message || 'Failed to compute trial balance'));
  }
};

module.exports = {
  getCOA,
  bootstrapCOA,
  rebuild,
  postApprovedForDate,
  retryFailedPostings,
  getPostingExceptions,
  getTrialBalance,
};