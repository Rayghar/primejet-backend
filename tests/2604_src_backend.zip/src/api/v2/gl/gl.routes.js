// File: src/api/v2/gl/gl.routes.js

const express = require('express');
const authMiddleware = require('../../../middleware/auth.middleware');
const gl = require('./gl.controller');

const router = express.Router();

// GL reference data
router.get('/coa', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getCOA);

// GL setup/bootstrap
router.post('/bootstrap', authMiddleware(['admin', 'finance_lead']), gl.bootstrapCOA);

// Rebuild journals from operational data
// Example: POST /api/v2/gl/rebuild?startDate=2025-06-01&endDate=2025-08-31
// Optional: &branchId=... or &serviceZoneId=...&dryRun=true
router.post('/rebuild', authMiddleware(['admin', 'finance_lead']), gl.rebuild);

// Day-to-day posting flow (GL-first)
// Post all approved sources for a business date
// Example: POST /api/v2/gl/post-approved?date=2025-08-31&branchId=...
router.post('/post-approved', authMiddleware(['admin', 'finance_lead']), gl.postApprovedForDate);

// Retry failures within a range
// Example: POST /api/v2/gl/retry-failed?startDate=2025-06-01&endDate=2025-08-31
router.post('/retry-failed', authMiddleware(['admin', 'finance_lead']), gl.retryFailedPostings);

// Inspect posting exceptions (grouped by reason)
// Example: GET /api/v2/gl/posting-exceptions?startDate=2025-06-01&endDate=2025-08-31
router.get('/posting-exceptions', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getPostingExceptions);

// Trial balance
// Example: GET /api/v2/gl/trial-balance?startDate=2025-06-01&endDate=2025-08-31
router.get('/trial-balance', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getTrialBalance);

module.exports = router;