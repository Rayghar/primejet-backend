// File: src/api/v2/gl/handlers/postDailySummaryPOS.js
//
// GL Posting Handler: DailySummary (POS)
//
// Posts a double-entry journal from an APPROVED DailySummary using BUSINESS DATE (DailySummary.date).
//
// Journal (default policy):
//   Dr Cash/Bank (split by cashAmount / transferAmount / posAmount)
//   Cr Sales Revenue - POS (4000)
//   Dr COGS (5000)  [optional if kgSold + WAC available]
//   Cr Inventory (1200)
//
// Key behaviors:
// - Migration-safe: uses DailySummary.date (NOT createdAt)
// - Idempotent: upserts by {branchKey, sourceType, sourceId, entryType}
// - Balancing: if tender split != totalRevenue, uses "Cash Over/Short" account to balance
// - Posting metadata: best-effort update to DailySummary.posting.* (requires schema support)

const mongoose = require('mongoose');

const DailySummary = require('../../../../models/dailySummary.model');
const GeneralLedgerEntry = require('../../../../models/generalLedgerEntry.model');
const StockIn = require('../../../../models/stockIn.model');

// Optional: policy matrix (recommended). If missing, fallback to defaults in this file.
let policy = null;
try {
  // Expected location: src/api/v2/gl/policyMatrix.js
  // (handlers/* sits under src/api/v2/gl/handlers)
  // eslint-disable-next-line global-require
  policy = require('../policyMatrix');
} catch (e) {
  policy = null;
}

// -------------------------
// tiny helpers
// -------------------------
const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

const toBranchKey = (doc) => {
  const v = doc?.branchId ?? doc?.serviceZoneId ?? doc?.zoneId ?? doc?.plantId ?? null;
  return v == null ? null : String(v);
};

const sumLines = (lines) => {
  const debit = (lines || []).reduce((s, l) => s + safeNum(l.debit, 0), 0);
  const credit = (lines || []).reduce((s, l) => s + safeNum(l.credit, 0), 0);
  return { debit, credit };
};

const assertBalanced = (lines, tolerance = 0.5) => {
  const { debit, credit } = sumLines(lines);
  const diff = Math.abs(debit - credit);
  if (diff > tolerance) {
    const e = new Error(`Unbalanced journal: debit=${debit}, credit=${credit}, diff=${diff}`);
    e.code = 'UNBALANCED_JOURNAL';
    e.meta = { debit, credit, diff };
    throw e;
  }
};

// -------------------------
// WAC (Weighted Average Cost) helper
// -------------------------
const getWacCostPerKgAsOf = async (branchKey, asOfDate) => {
  const match = { purchaseDate: { $lte: asOfDate } };

  // tolerant branch match: StockIn may store branchId as ObjectId or string.
  if (branchKey) {
    match.$or = [{ branchId: branchKey }, { serviceZoneId: branchKey }, { zoneId: branchKey }, { plantId: branchKey }];

    if (mongoose.Types.ObjectId.isValid(branchKey)) {
      const oid = new mongoose.Types.ObjectId(branchKey);
      match.$or.push({ branchId: oid }, { serviceZoneId: oid }, { zoneId: oid }, { plantId: oid });
    }
  }

  const rows = await StockIn.find(match).select('quantityKg costPerKg').lean();

  let totalKg = 0;
  let totalCost = 0;

  for (const b of rows || []) {
    const q = safeNum(b?.quantityKg, 0);
    const c = safeNum(b?.costPerKg, 0);
    if (q > 0 && c > 0) {
      totalKg += q;
      totalCost += q * c;
    }
  }

  return totalKg > 0 ? totalCost / totalKg : 0;
};

// -------------------------
// policy-backed defaults
// -------------------------
const DEFAULT_ACCOUNTS = {
  // tender / cash accounts
  CASH_ON_HAND: '1000',
  BANK_TRANSFER: '1010',
  BANK_POS: '1020',

  // revenue + inventory/COGS
  REVENUE_POS: '4000',
  COGS_LPG: '5000',
  INVENTORY_LPG: '1200',

  // balancing / exceptions
  CASH_OVER_SHORT: '1050', // recommended new COA line (add in bootstrap/policyMatrix)
};

const getAccounts = () => {
  // If you have a policy matrix, prefer it; otherwise use defaults.
  // Suggested policy structure:
  // policy.accounts = { ... }
  const a = policy?.accounts && typeof policy.accounts === 'object' ? policy.accounts : {};
  return {
    CASH_ON_HAND: a.CASH_ON_HAND || DEFAULT_ACCOUNTS.CASH_ON_HAND,
    BANK_TRANSFER: a.BANK_TRANSFER || DEFAULT_ACCOUNTS.BANK_TRANSFER,
    BANK_POS: a.BANK_POS || DEFAULT_ACCOUNTS.BANK_POS,
    REVENUE_POS: a.REVENUE_POS || DEFAULT_ACCOUNTS.REVENUE_POS,
    COGS_LPG: a.COGS_LPG || DEFAULT_ACCOUNTS.COGS_LPG,
    INVENTORY_LPG: a.INVENTORY_LPG || DEFAULT_ACCOUNTS.INVENTORY_LPG,
    CASH_OVER_SHORT: a.CASH_OVER_SHORT || DEFAULT_ACCOUNTS.CASH_OVER_SHORT,
  };
};

const getTolerances = () => {
  const t = policy?.tolerances && typeof policy.tolerances === 'object' ? policy.tolerances : {};
  return {
    journalBalance: safeNum(t.journalBalance, 0.5),
    tenderMismatch: safeNum(t.tenderMismatch, 1), // ₦1
  };
};

// -------------------------
// DB write helper (idempotent upsert)
// -------------------------
const upsertGLEntry = async ({ date, branchKey, sourceType, sourceId, entryType = 'PRIMARY', narration, lines }) => {
  const { debit, credit } = sumLines(lines);

  const doc = {
    date,
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
    status: 'POSTED',
    narration: narration || '',
    lines,
    totals: { debit, credit },
  };

  const filter = {
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
  };

  // Upsert ensures rebuilds are repeatable
  await GeneralLedgerEntry.updateOne(filter, { $set: doc }, { upsert: true });

  // Fetch the id for linking (optional)
  const saved = await GeneralLedgerEntry.findOne(filter).select('_id').lean();
  return saved?._id || null;
};

// -------------------------
// Posting handler
// -------------------------
/**
 * postDailySummaryPOS
 *
 * @param {Object|string} dsOrId - DailySummary document OR id
 * @param {Object} opts
 * @param {string|null} opts.entryType - default 'PRIMARY'
 * @param {boolean} opts.postCogs - default true (will only post if kgSold>0 and WAC>0)
 * @param {string|null} opts.postedBy - for posting metadata on source doc
 *
 * @returns {Promise<{posted?:boolean, skipped?:boolean, reason?:string, glEntryId?:any}>}
 */
async function postDailySummaryPOS(dsOrId, opts = {}) {
  const accounts = getAccounts();
  const tol = getTolerances();

  // Load doc if id was passed
  const ds =
    typeof dsOrId === 'string' || mongoose.Types.ObjectId.isValid(String(dsOrId))
      ? await DailySummary.findById(dsOrId).lean()
      : dsOrId;

  if (!ds) return { skipped: true, reason: 'DAILY_NOT_FOUND' };

  const businessDate = toISODate(ds?.date);
  if (!businessDate) return { skipped: true, reason: 'DAILY_INVALID_DATE' };

  const branchKey = toBranchKey(ds);
  if (!branchKey) return { skipped: true, reason: 'DAILY_MISSING_BRANCH' };

  const status = String(ds?.status || '').toLowerCase().trim();
  if (status !== 'approved') return { skipped: true, reason: 'DAILY_NOT_APPROVED' };

  const revenue = safeNum(ds?.sales?.totalRevenue, 0);
  const kgSold = safeNum(ds?.sales?.totalKgSold, 0);

  if (revenue <= 0) return { skipped: true, reason: 'DAILY_ZERO_REVENUE' };

  // Tender split (migration format supports posAmount/cashAmount/transferAmount)
  const cashAmt = safeNum(ds?.sales?.cashAmount, 0);
  const transferAmt = safeNum(ds?.sales?.transferAmount, 0);
  const posAmt = safeNum(ds?.sales?.posAmount, 0);

  const tenderTotal = cashAmt + transferAmt + posAmt;
  const tenderDiff = safeNum(revenue - tenderTotal, 0); // positive means "missing tender", negative means "extra tender"

  // If tender split is present but doesn't reconcile, we can:
  // - within tolerance: push balancing line to CASH_OVER_SHORT
  // - above tolerance: fail (so it shows in exceptions)
  if (Math.abs(tenderDiff) > tol.tenderMismatch) {
    const e = new Error(
      `DailySummary tender mismatch: revenue=${revenue}, tenderTotal=${tenderTotal}, diff=${tenderDiff}`
    );
    e.code = 'DAILY_TENDER_MISMATCH';
    e.meta = { revenue, tenderTotal, diff: tenderDiff, dailySummaryId: ds?.dailySummaryId || ds?._id };
    throw e;
  }

  const lines = [];

  // Debit tender accounts
  // If no tender split provided (all zero), assume CASH_ON_HAND for full revenue.
  const hasAnyTender = tenderTotal > 0;
  if (!hasAnyTender) {
    lines.push({
      accountCode: accounts.CASH_ON_HAND,
      debit: revenue,
      credit: 0,
      narration: 'POS sale (no tender split) - assumed cash',
    });
  } else {
    if (cashAmt > 0) {
      lines.push({
        accountCode: accounts.CASH_ON_HAND,
        debit: cashAmt,
        credit: 0,
        narration: 'POS sale - cash',
      });
    }
    if (transferAmt > 0) {
      lines.push({
        accountCode: accounts.BANK_TRANSFER,
        debit: transferAmt,
        credit: 0,
        narration: 'POS sale - transfer',
      });
    }
    if (posAmt > 0) {
      lines.push({
        accountCode: accounts.BANK_POS,
        debit: posAmt,
        credit: 0,
        narration: 'POS sale - POS/card settlement',
      });
    }

    // Balance tiny tender rounding differences using CASH_OVER_SHORT
    if (Math.abs(tenderDiff) > 0) {
      if (tenderDiff > 0) {
        // need more debit to match revenue
        lines.push({
          accountCode: accounts.CASH_OVER_SHORT,
          debit: tenderDiff,
          credit: 0,
          narration: 'Tender rounding/over-short (debit)',
        });
      } else {
        // too much debit already; add credit
        lines.push({
          accountCode: accounts.CASH_OVER_SHORT,
          debit: 0,
          credit: Math.abs(tenderDiff),
          narration: 'Tender rounding/over-short (credit)',
        });
      }
    }
  }

  // Credit revenue (POS)
  lines.push({
    accountCode: accounts.REVENUE_POS,
    debit: 0,
    credit: revenue,
    narration: 'POS sales revenue',
  });

  // Optional COGS + Inventory reduction
  const shouldPostCogs = opts.postCogs !== false; // default true
  if (shouldPostCogs && kgSold > 0) {
    const wac = await getWacCostPerKgAsOf(branchKey, endOfDay(businessDate));
    const cogs = kgSold > 0 && wac > 0 ? kgSold * wac : 0;

    // If no WAC, skip COGS rather than block posting (migration-friendly)
    if (cogs > 0) {
      lines.push({
        accountCode: accounts.COGS_LPG,
        debit: cogs,
        credit: 0,
        narration: `COGS (WAC) for POS sales: ${kgSold}kg × ${wac}`,
      });
      lines.push({
        accountCode: accounts.INVENTORY_LPG,
        debit: 0,
        credit: cogs,
        narration: 'Inventory reduction for POS sales',
      });
    }
  }

  // Ensure balanced
  assertBalanced(lines, tol.journalBalance);

  const sourceId = String(ds?.dailySummaryId || ds?._id);
  const glEntryId = await upsertGLEntry({
    date: businessDate,
    branchKey,
    sourceType: 'DAILY_SUMMARY',
    sourceId,
    entryType: opts.entryType || 'PRIMARY',
    narration: `POS DailySummary ${sourceId}`,
    lines,
  });

  // Best-effort: update source doc posting metadata (requires schema support)
  try {
    await DailySummary.updateOne(
      { _id: ds._id },
      {
        $set: {
          posting: {
            status: 'POSTED',
            glEntryId,
            postedAt: new Date(),
            postedBy: opts.postedBy || null,
            attempts: safeNum(ds?.posting?.attempts, 0) + 1,
            errorCode: null,
            errorMessage: null,
            version: safeNum(ds?.posting?.version, 1),
          },
        },
      }
    );
  } catch (e) {
    // ignore if schema doesn't support posting fields yet
  }

  return { posted: true, glEntryId, branchKey, businessDate };
}

module.exports = postDailySummaryPOS;
module.exports.postDailySummaryPOS = postDailySummaryPOS;