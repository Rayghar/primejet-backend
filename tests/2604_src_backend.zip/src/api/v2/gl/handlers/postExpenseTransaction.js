// File: src/api/v2/gl/handlers/postExpenseTransaction.js
//
// GL Posting Handler: ExpenseTransaction
//
// Posts a double-entry journal from an ExpenseTransaction using BUSINESS DATE (ExpenseTransaction.date).
//
// Journal (default policy):
//   Dr Expense (mapped by category/type)   -> 6000..6500
//   Cr Cash/Bank/AP (mapped by paymentDisposition/mode/paymentMethod)
//      CASH      -> 1000
//      TRANSFER  -> 1010
//      POS       -> 1020
//      UNPAID/AP -> 2000
//
// Key behaviors:
// - Migration-safe: uses ExpenseTransaction.date (NOT createdAt)
// - Idempotent: upserts by {branchKey, sourceType, sourceId, entryType}
// - Posting metadata: best-effort update to ExpenseTransaction.posting.* (requires schema support)

const mongoose = require('mongoose');

const ExpenseTransaction = require('../../../../models/expenseTransaction.model');
const GeneralLedgerEntry = require('../../../../models/generalLedgerEntry.model');

// Optional: policy matrix (recommended). If missing, fallback to defaults in this file.
let policy = null;
try {
  // Expected location: src/api/v2/gl/policyMatrix.js
  // eslint-disable-next-line global-require
  policy = require('../policyMatrix');
} catch (e) {
  policy = null;
}

// -------------------------
// tiny helpers
// -------------------------
const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const toBranchKey = (doc) => {
  const v = doc?.branchId ?? doc?.serviceZoneId ?? doc?.zoneId ?? doc?.plantId ?? null;
  return v == null ? null : String(v);
};

const sumLines = (lines) => {
  const debit = (lines || []).reduce((s, l) => s + safeNum(l.debit, 0), 0);
  const credit = (lines || []).reduce((s, l) => s + safeNum(l.credit, 0), 0);
  return { debit, credit };
};

const assertBalanced = (lines, tolerance = 0.5) => {
  const { debit, credit } = sumLines(lines);
  const diff = Math.abs(debit - credit);
  if (diff > tolerance) {
    const e = new Error(`Unbalanced journal: debit=${debit}, credit=${credit}, diff=${diff}`);
    e.code = 'UNBALANCED_JOURNAL';
    e.meta = { debit, credit, diff };
    throw e;
  }
};

// -------------------------
// policy-backed defaults
// -------------------------
const DEFAULT_ACCOUNTS = {
  CASH_ON_HAND: '1000',
  BANK_TRANSFER: '1010',
  BANK_POS: '1020',
  ACCOUNTS_PAYABLE: '2000',

  // OPEX buckets
  EXP_STAFF: '6000',
  EXP_LOGISTICS: '6100',
  EXP_UTILITIES: '6200',
  EXP_MAINTENANCE: '6300',
  EXP_MARKETING: '6400',
  EXP_ADMIN: '6500',
};

const getAccounts = () => {
  const a = policy?.accounts && typeof policy.accounts === 'object' ? policy.accounts : {};
  return {
    CASH_ON_HAND: a.CASH_ON_HAND || DEFAULT_ACCOUNTS.CASH_ON_HAND,
    BANK_TRANSFER: a.BANK_TRANSFER || DEFAULT_ACCOUNTS.BANK_TRANSFER,
    BANK_POS: a.BANK_POS || DEFAULT_ACCOUNTS.BANK_POS,
    ACCOUNTS_PAYABLE: a.ACCOUNTS_PAYABLE || DEFAULT_ACCOUNTS.ACCOUNTS_PAYABLE,

    EXP_STAFF: a.EXP_STAFF || DEFAULT_ACCOUNTS.EXP_STAFF,
    EXP_LOGISTICS: a.EXP_LOGISTICS || DEFAULT_ACCOUNTS.EXP_LOGISTICS,
    EXP_UTILITIES: a.EXP_UTILITIES || DEFAULT_ACCOUNTS.EXP_UTILITIES,
    EXP_MAINTENANCE: a.EXP_MAINTENANCE || DEFAULT_ACCOUNTS.EXP_MAINTENANCE,
    EXP_MARKETING: a.EXP_MARKETING || DEFAULT_ACCOUNTS.EXP_MARKETING,
    EXP_ADMIN: a.EXP_ADMIN || DEFAULT_ACCOUNTS.EXP_ADMIN,
  };
};

const getTolerances = () => {
  const t = policy?.tolerances && typeof policy.tolerances === 'object' ? policy.tolerances : {};
  return {
    journalBalance: safeNum(t.journalBalance, 0.5),
  };
};

// -------------------------
// mapping helpers
// -------------------------
const mapExpenseToAccount = (exp, accounts) => {
  // If policy provides explicit category mappings, use them first.
  // Suggested policy structure:
  // policy.expenseCategoryMap = [{ match: /regex/i, accountCode: '6100' }, ...]
  const mapRules = Array.isArray(policy?.expenseCategoryMap) ? policy.expenseCategoryMap : [];

  const raw = String(exp?.category || exp?.type || '').trim();
  const rawLower = raw.toLowerCase();

  for (const r of mapRules) {
    try {
      const re = r?.match instanceof RegExp ? r.match : null;
      if (re && re.test(raw)) return String(r.accountCode);
      if (typeof r?.contains === 'string' && rawLower.includes(String(r.contains).toLowerCase())) return String(r.accountCode);
    } catch (e) {
      // ignore invalid rule
    }
  }

  // Fallback heuristic mapping
  if (rawLower.includes('salar') || rawLower.includes('wages') || rawLower.includes('staff')) return accounts.EXP_STAFF;
  if (
    rawLower.includes('fuel') ||
    rawLower.includes('transport') ||
    rawLower.includes('vehicle') ||
    rawLower.includes('dispatch') ||
    rawLower.includes('logistics')
  )
    return accounts.EXP_LOGISTICS;
  if (
    rawLower.includes('power') ||
    rawLower.includes('electric') ||
    rawLower.includes('internet') ||
    rawLower.includes('diesel') ||
    rawLower.includes('utility')
  )
    return accounts.EXP_UTILITIES;
  if (rawLower.includes('maint') || rawLower.includes('repair') || rawLower.includes('service')) return accounts.EXP_MAINTENANCE;
  if (rawLower.includes('market') || rawLower.includes('adver') || rawLower.includes('promo')) return accounts.EXP_MARKETING;
  return accounts.EXP_ADMIN;
};

const mapPaymentDispositionToCreditAccount = (exp, accounts) => {
  // Prefer explicit field if you add it in UI/model:
  // exp.paymentDisposition: CASH|TRANSFER|POS|UNPAID|AP|PAYABLE
  const pd = String(exp?.paymentDisposition || exp?.disposition || '').toUpperCase().trim();
  if (pd === 'CASH') return accounts.CASH_ON_HAND;
  if (pd === 'TRANSFER' || pd === 'BANK') return accounts.BANK_TRANSFER;
  if (pd === 'POS' || pd === 'CARD') return accounts.BANK_POS;
  if (pd === 'UNPAID' || pd === 'AP' || pd === 'PAYABLE') return accounts.ACCOUNTS_PAYABLE;

  // Fallback based on mode/paymentMethod
  const m = String(exp?.paymentMethod || exp?.mode || exp?.paymentMode || '').toLowerCase().trim();
  if (m.includes('pos') || m.includes('card')) return accounts.BANK_POS;
  if (m.includes('transfer') || m.includes('bank')) return accounts.BANK_TRANSFER;

  // If no signals, default to cash to avoid blocking (but you may prefer AP instead)
  return accounts.CASH_ON_HAND;
};

// -------------------------
// idempotent upsert helper
// -------------------------
const upsertGLEntry = async ({ date, branchKey, sourceType, sourceId, entryType = 'PRIMARY', narration, lines }) => {
  const { debit, credit } = sumLines(lines);

  const doc = {
    date,
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
    status: 'POSTED',
    narration: narration || '',
    lines,
    totals: { debit, credit },
  };

  const filter = {
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
  };

  await GeneralLedgerEntry.updateOne(filter, { $set: doc }, { upsert: true });

  const saved = await GeneralLedgerEntry.findOne(filter).select('_id').lean();
  return saved?._id || null;
};

// -------------------------
// Posting handler
// -------------------------
/**
 * postExpenseTransaction
 *
 * @param {Object|string} expOrId - ExpenseTransaction document OR id
 * @param {Object} opts
 * @param {string|null} opts.entryType - default 'PRIMARY'
 * @param {string|null} opts.postedBy - for posting metadata on source doc
 *
 * @returns {Promise<{posted?:boolean, skipped?:boolean, reason?:string, glEntryId?:any}>}
 */
async function postExpenseTransaction(expOrId, opts = {}) {
  const accounts = getAccounts();
  const tol = getTolerances();

  // Load doc if id was passed
  const exp =
    typeof expOrId === 'string' || mongoose.Types.ObjectId.isValid(String(expOrId))
      ? await ExpenseTransaction.findById(expOrId).lean()
      : expOrId;

  if (!exp) return { skipped: true, reason: 'EXPENSE_NOT_FOUND' };

  const businessDate = toISODate(exp?.date);
  if (!businessDate) return { skipped: true, reason: 'EXPENSE_INVALID_DATE' };

  const branchKey = toBranchKey(exp);
  if (!branchKey) return { skipped: true, reason: 'EXPENSE_MISSING_BRANCH' };

  const amount = safeNum(exp?.amount, 0);
  if (amount <= 0) return { skipped: true, reason: 'EXPENSE_ZERO_AMOUNT' };

  // Optional: if you have an approval field, enforce it here.
  // Many of your docs don’t show status; keep it permissive for migration.
  const st = String(exp?.status || '').toLowerCase().trim();
  if (st && ['rejected', 'cancelled', 'canceled', 'void'].includes(st)) return { skipped: true, reason: 'EXPENSE_VOIDED' };

  const debitAccount = mapExpenseToAccount(exp, accounts);
  const creditAccount = mapPaymentDispositionToCreditAccount(exp, accounts);

  // If policy forces mapping strictness
  if (policy?.strictMappings === true) {
    const allowed = new Set([
      accounts.EXP_STAFF,
      accounts.EXP_LOGISTICS,
      accounts.EXP_UTILITIES,
      accounts.EXP_MAINTENANCE,
      accounts.EXP_MARKETING,
      accounts.EXP_ADMIN,
    ].map(String));
    if (!allowed.has(String(debitAccount))) {
      const e = new Error(`Expense category unmapped: ${String(exp?.category || exp?.type || '')}`);
      e.code = 'EXPENSE_CATEGORY_UNMAPPED';
      e.meta = { expenseId: String(exp?._id), category: exp?.category, type: exp?.type };
      throw e;
    }
  }

  const description = String(exp?.description || exp?.narration || 'Expense').trim();

  const lines = [
    { accountCode: String(debitAccount), debit: amount, credit: 0, narration: description },
    { accountCode: String(creditAccount), debit: 0, credit: amount, narration: 'Expense settlement' },
  ];

  assertBalanced(lines, tol.journalBalance);

  const sourceId = String(exp?._id);
  const glEntryId = await upsertGLEntry({
    date: businessDate,
    branchKey,
    sourceType: 'EXPENSE',
    sourceId,
    entryType: opts.entryType || 'PRIMARY',
    narration: `Expense ${sourceId} - ${description}`.slice(0, 180),
    lines,
  });

  // Best-effort: update source doc posting metadata (requires schema support)
  try {
    await ExpenseTransaction.updateOne(
      { _id: exp._id },
      {
        $set: {
          posting: {
            status: 'POSTED',
            glEntryId,
            postedAt: new Date(),
            postedBy: opts.postedBy || null,
            attempts: safeNum(exp?.posting?.attempts, 0) + 1,
            errorCode: null,
            errorMessage: null,
            version: safeNum(exp?.posting?.version, 1),
          },
        },
      }
    );
  } catch (e) {
    // ignore if schema doesn't support posting fields yet
  }

  return { posted: true, glEntryId, branchKey, businessDate };
}

module.exports = postExpenseTransaction;
module.exports.postExpenseTransaction = postExpenseTransaction;