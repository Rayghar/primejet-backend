// File: src/api/v2/gl/handlers/postStockIn.js
//
// GL Posting Handler: StockIn (Inventory Purchase)
//
// Posts a double-entry journal from a StockIn document using BUSINESS DATE (StockIn.purchaseDate).
//
// Journal (policy/default):
//   Dr Inventory - LPG (1200)
//   Cr Bank/Cash/AP depending on payment signals:
//     - if explicitly paid: Cr Bank - Transfers (1010)   [default assumption for supplier payments]
//     - if partially paid:  Cr Bank (1010) for paid portion + Cr AP (2000) for outstanding
//     - if no payment signals: Cr AP (2000) (do NOT assume cash)
//
// Key behaviors:
// - Migration-safe: uses StockIn.purchaseDate (NOT createdAt)
// - Idempotent: upserts by {branchKey, sourceType, sourceId, entryType}
// - Posting metadata: best-effort update to StockIn.posting.* (requires schema support)

const mongoose = require('mongoose');

const StockIn = require('../../../../models/stockIn.model');
const GeneralLedgerEntry = require('../../../../models/generalLedgerEntry.model');

// Optional: policy matrix (recommended). If missing, fallback to defaults in this file.
let policy = null;
try {
  // Expected location: src/api/v2/gl/policyMatrix.js
  // eslint-disable-next-line global-require
  policy = require('../policyMatrix');
} catch (e) {
  policy = null;
}

// -------------------------
// tiny helpers
// -------------------------
const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

const toBranchKey = (doc) => {
  const v = doc?.branchId ?? doc?.serviceZoneId ?? doc?.zoneId ?? doc?.plantId ?? null;
  return v == null ? null : String(v);
};

const sumLines = (lines) => {
  const debit = (lines || []).reduce((s, l) => s + safeNum(l.debit, 0), 0);
  const credit = (lines || []).reduce((s, l) => s + safeNum(l.credit, 0), 0);
  return { debit, credit };
};

const assertBalanced = (lines, tolerance = 0.5) => {
  const { debit, credit } = sumLines(lines);
  const diff = Math.abs(debit - credit);
  if (diff > tolerance) {
    const e = new Error(`Unbalanced journal: debit=${debit}, credit=${credit}, diff=${diff}`);
    e.code = 'UNBALANCED_JOURNAL';
    e.meta = { debit, credit, diff };
    throw e;
  }
};

// -------------------------
// policy-backed defaults
// -------------------------
const DEFAULT_ACCOUNTS = {
  INVENTORY_LPG: '1200',
  CASH_ON_HAND: '1000',
  BANK_TRANSFER: '1010',
  BANK_POS: '1020',
  ACCOUNTS_PAYABLE: '2000',
};

const getAccounts = () => {
  const a = policy?.accounts && typeof policy.accounts === 'object' ? policy.accounts : {};
  return {
    INVENTORY_LPG: a.INVENTORY_LPG || DEFAULT_ACCOUNTS.INVENTORY_LPG,
    CASH_ON_HAND: a.CASH_ON_HAND || DEFAULT_ACCOUNTS.CASH_ON_HAND,
    BANK_TRANSFER: a.BANK_TRANSFER || DEFAULT_ACCOUNTS.BANK_TRANSFER,
    BANK_POS: a.BANK_POS || DEFAULT_ACCOUNTS.BANK_POS,
    ACCOUNTS_PAYABLE: a.ACCOUNTS_PAYABLE || DEFAULT_ACCOUNTS.ACCOUNTS_PAYABLE,
  };
};

const getTolerances = () => {
  const t = policy?.tolerances && typeof policy.tolerances === 'object' ? policy.tolerances : {};
  return {
    journalBalance: safeNum(t.journalBalance, 0.5),
  };
};

// If you later store supplier payment method, you can refine this.
// For now: supplier payments are assumed transfer/bank when "paid".
const mapStockPaymentToCreditAccount = (stock, accounts) => {
  const pm = String(stock?.paymentMethod || stock?.mode || stock?.paymentMode || '').toLowerCase().trim();
  if (pm.includes('cash')) return accounts.CASH_ON_HAND;
  if (pm.includes('pos') || pm.includes('card')) return accounts.BANK_POS;
  if (pm.includes('transfer') || pm.includes('bank')) return accounts.BANK_TRANSFER;
  return accounts.BANK_TRANSFER;
};

// Determine payment signals for StockIn
const stockPaymentSignals = (stock) => {
  const amountPaid = safeNum(stock?.amountPaid ?? stock?.paidAmount, 0);

  const hasSignals =
    Object.prototype.hasOwnProperty.call(stock, 'amountPaid') ||
    Object.prototype.hasOwnProperty.call(stock, 'paidAmount') ||
    Object.prototype.hasOwnProperty.call(stock, 'isPaid') ||
    Object.prototype.hasOwnProperty.call(stock, 'paymentStatus');

  const ps = String(stock?.paymentStatus || '').toLowerCase().trim();
  const explicitlyPaid =
    stock?.isPaid === true ||
    ['paid', 'settled', 'completed', 'success', 'successful'].includes(ps);

  return { hasSignals, amountPaid, explicitlyPaid, paymentStatus: ps };
};

// -------------------------
// idempotent upsert helper
// -------------------------
const upsertGLEntry = async ({ date, branchKey, sourceType, sourceId, entryType = 'PRIMARY', narration, lines }) => {
  const { debit, credit } = sumLines(lines);

  const doc = {
    date,
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
    status: 'POSTED',
    narration: narration || '',
    lines,
    totals: { debit, credit },
  };

  const filter = {
    branchKey: branchKey || null,
    sourceType,
    sourceId: String(sourceId),
    entryType,
  };

  await GeneralLedgerEntry.updateOne(filter, { $set: doc }, { upsert: true });

  const saved = await GeneralLedgerEntry.findOne(filter).select('_id').lean();
  return saved?._id || null;
};

// -------------------------
// Posting handler
// -------------------------
/**
 * postStockIn
 *
 * @param {Object|string} stockOrId - StockIn document OR id
 * @param {Object} opts
 * @param {string|null} opts.entryType - default 'PRIMARY'
 * @param {string|null} opts.postedBy - for posting metadata on source doc
 *
 * @returns {Promise<{posted?:boolean, skipped?:boolean, reason?:string, glEntryId?:any}>}
 */
async function postStockIn(stockOrId, opts = {}) {
  const accounts = getAccounts();
  const tol = getTolerances();

  // Load doc if id was passed
  const stock =
    typeof stockOrId === 'string' || mongoose.Types.ObjectId.isValid(String(stockOrId))
      ? await StockIn.findById(stockOrId).lean()
      : stockOrId;

  if (!stock) return { skipped: true, reason: 'STOCKIN_NOT_FOUND' };

  const businessDate = toISODate(stock?.purchaseDate);
  if (!businessDate) return { skipped: true, reason: 'STOCKIN_INVALID_PURCHASE_DATE' };

  const branchKey = toBranchKey(stock);
  if (!branchKey) return { skipped: true, reason: 'STOCKIN_MISSING_BRANCH' };

  const qty = safeNum(stock?.quantityKg, 0);
  const cpk = safeNum(stock?.costPerKg, 0);

  if (qty <= 0 || cpk <= 0) return { skipped: true, reason: 'STOCKIN_INVALID_QTY_OR_COST' };

  const total = qty * cpk;
  if (total <= 0) return { skipped: true, reason: 'STOCKIN_TOTAL_ZERO' };

  const { hasSignals, amountPaid, explicitlyPaid } = stockPaymentSignals(stock);

  // Build journal lines
  const lines = [{ accountCode: String(accounts.INVENTORY_LPG), debit: total, credit: 0, narration: 'Inventory purchase (LPG)' }];

  if (hasSignals && explicitlyPaid) {
    const creditAcc = mapStockPaymentToCreditAccount(stock, accounts);
    lines.push({ accountCode: String(creditAcc), debit: 0, credit: total, narration: 'Inventory purchase paid' });
  } else if (hasSignals && amountPaid > 0 && amountPaid < total) {
    const creditAccPaid = mapStockPaymentToCreditAccount(stock, accounts);
    lines.push({ accountCode: String(creditAccPaid), debit: 0, credit: amountPaid, narration: 'Paid portion' });
    lines.push({
      accountCode: String(accounts.ACCOUNTS_PAYABLE),
      debit: 0,
      credit: Math.max(0, total - amountPaid),
      narration: 'Outstanding payable portion',
    });
  } else {
    // If no payment signals or unpaid: do NOT assume cash/bank. Use AP.
    lines.push({ accountCode: String(accounts.ACCOUNTS_PAYABLE), debit: 0, credit: total, narration: 'Accounts payable (supplier)' });
  }

  assertBalanced(lines, tol.journalBalance);

  const sourceId = String(stock?._id);
  const glEntryId = await upsertGLEntry({
    date: businessDate,
    branchKey,
    sourceType: 'STOCK_IN',
    sourceId,
    entryType: opts.entryType || 'PRIMARY',
    narration: `StockIn ${sourceId} - ${qty}kg @ ${cpk}`.slice(0, 180),
    lines,
  });

  // Best-effort: update source doc posting metadata (requires schema support)
  try {
    await StockIn.updateOne(
      { _id: stock._id },
      {
        $set: {
          posting: {
            status: 'POSTED',
            glEntryId,
            postedAt: new Date(),
            postedBy: opts.postedBy || null,
            attempts: safeNum(stock?.posting?.attempts, 0) + 1,
            errorCode: null,
            errorMessage: null,
            version: safeNum(stock?.posting?.version, 1),
          },
        },
      }
    );
  } catch (e) {
    // ignore if schema doesn't support posting fields yet
  }

  return {
    posted: true,
    glEntryId,
    branchKey,
    businessDate: endOfDay(businessDate),
    total,
    qtyKg: qty,
    costPerKg: cpk,
    payment: { hasSignals, amountPaid, explicitlyPaid },
  };
}

module.exports = postStockIn;
module.exports.postStockIn = postStockIn;