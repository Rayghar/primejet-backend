// File: src/api/v2/gl/posting.service.js
//
// GL-ONLY Orchestrator (GL-FIRST)
// - This file MUST NOT contain accounting logic.
// - It coordinates: bootstrap COA, rebuild, post-approved, retry-failed, trial-balance, posting-exceptions
// - Accounting logic lives in handlers/* + services/* (WAC, COA mapping, policy matrix)
//
// What this orchestrator enforces:
// ✅ Migration-safe business dates:
//    - DailySummary.date
//    - ExpenseTransaction.date
//    - StockIn.purchaseDate
//    - Order.orderDate (fallback createdAt ONLY if orderDate missing)
// ✅ Idempotency:
//    - Handlers upsert journals by (sourceType, sourceId, branchKey, entryType/version) in GeneralLedgerEntry
// ✅ Posting metadata back to source docs:
//    - posting.status, posting.glEntryIds, posting.attempts, posting.errorCode/errorMessage, etc.
// ✅ Visibility:
//    - rebuild returns posted/skipped/failed + reason counts + example IDs (so “153 errors” is explainable)

const mongoose = require('mongoose');

const ChartOfAccount = require('../../../models/chartOfAccount.model');
const GeneralLedgerEntry = require('../../../models/generalLedgerEntry.model');

const Order = require('../../../models/order.model');
const DailySummary = require('../../../models/dailySummary.model');
const ExpenseTransaction = require('../../../models/expenseTransaction.model');
const StockIn = require('../../../models/stockIn.model');

// Handlers (accounting logic)
const postDailySummaryPOS = require('./handlers/postDailySummaryPOS');
const postExpenseTransaction = require('./handlers/postExpenseTransaction');
const postStockIn = require('./handlers/postStockIn');
const postOrderDelivery = require('./handlers/postOrderDelivery');
const postReversal = require('./handlers/postReversal');

// Services
const { ensureDefaultCOA } = require('./services/coaMapping.service');

// -------------------------
// tiny utils
// -------------------------
const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const hasVal = (v) => v !== undefined && v !== null && String(v).trim() !== '';

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const endOfDay = (d) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};

const startOfDay = (d) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};

const toBranchKey = (docOrId) => {
  if (!docOrId) return null;
  if (typeof docOrId === 'string') return docOrId;
  const v =
    docOrId?.branchId ??
    docOrId?.serviceZoneId ??
    docOrId?.zoneId ??
    docOrId?.plantId ??
    docOrId?.branchKey ??
    null;
  return v == null ? null : String(v);
};

// tolerant branch matcher (ObjectId or string across collections)
const buildBranchOrZoneMatch = (branchKey) => {
  if (!branchKey) return {};
  const s = String(branchKey);

  const ors = [{ branchId: s }, { serviceZoneId: s }, { zoneId: s }, { plantId: s }, { branchKey: s }];

  if (mongoose.Types.ObjectId.isValid(s)) {
    const oid = new mongoose.Types.ObjectId(s);
    ors.push({ branchId: oid }, { serviceZoneId: oid }, { zoneId: oid }, { plantId: oid });
  }

  return { $or: ors };
};

const keyOfReason = (r) => String(r || 'UNKNOWN').toUpperCase();

// -------------------------
// Posting metadata helpers
// -------------------------

/**
 * We write posting metadata like:
 * posting: {
 *   status: 'UNPOSTED'|'POSTED'|'FAILED'|'SKIPPED'
 *   glEntryIds: []
 *   attempts: 0
 *   errorCode/errorMessage
 * }
 *
 * NOTE:
 * - We do NOT assume these fields existed historically.
 * - Mongoose will create nested fields safely.
 */
const updateSourcePostingMeta = async ({ model, id, patch }) => {
  if (!model || !id || !patch) return;

  const $set = {};
  const $inc = {};

  if (patch.status) $set['posting.status'] = patch.status;

  if (patch.postedAt !== undefined) $set['posting.postedAt'] = patch.postedAt;
  if (patch.postedBy !== undefined) $set['posting.postedBy'] = patch.postedBy;

  // Explicitly clear errors when POSTED
  if (patch.errorCode !== undefined) $set['posting.errorCode'] = patch.errorCode;
  if (patch.errorMessage !== undefined) $set['posting.errorMessage'] = patch.errorMessage;

  if (patch.version !== undefined) $set['posting.version'] = patch.version;

  if (patch.glEntryId !== undefined) $set['posting.glEntryId'] = patch.glEntryId;
  if (patch.glEntryIds !== undefined) $set['posting.glEntryIds'] = patch.glEntryIds;

  if (typeof patch.attemptsInc === 'number') $inc['posting.attempts'] = patch.attemptsInc;

  // Keep safe: only include operators when needed
  const update = {};
  if (Object.keys($set).length) update.$set = $set;
  if (Object.keys($inc).length) update.$inc = $inc;

  if (!Object.keys(update).length) return;

  await model.updateOne({ _id: id }, update);
};

// -------------------------
// Orchestrator: stats tracking
// -------------------------
const makeStats = () => ({
  posted: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  skipped: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  failed: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  reasons: {},   // { CODE: count }
  examples: {},  // { CODE: [id1,id2...] }
});

const bumpReason = (stats, code, id) => {
  const k = keyOfReason(code);
  stats.reasons[k] = (stats.reasons[k] || 0) + 1;
  if (!stats.examples[k]) stats.examples[k] = [];
  if (id && stats.examples[k].length < 10) stats.examples[k].push(String(id));
};

// -------------------------
// Orchestrator: bootstrap
// -------------------------
const bootstrap = async () => {
  await ensureDefaultCOA();
  const count = await ChartOfAccount.countDocuments({ isActive: true });
  return { ok: true, insertedOrExisting: count };
};

// -------------------------
// Core posting runner (shared)
// -------------------------

/**
 * Handler contract:
 * handler.post(doc, ctx?) returns:
 *  {
 *    status: 'POSTED'|'SKIPPED'|'FAILED',
 *    reasonCode?: '...',
 *    glEntryIds?: ['...'],
 *    message?: '...'
 *  }
 *
 * NOTE: handlers do the actual GL upsert. Orchestrator only:
 *  - captures outcome
 *  - updates source posting metadata
 *  - aggregates stats
 */
const runOne = async ({ handler, model, doc, sourceType, stats, postedBy = 'system', ctx = {} }) => {
  const id = doc?._id;

  // Mark as QUEUED (optional but helpful in UI). We do it just-in-time.
  try {
    await updateSourcePostingMeta({
      model,
      id,
      patch: { status: 'QUEUED', attemptsInc: 0, postedBy, version: 1 },
    });
  } catch (_) {
    // do not block posting if metadata fails
  }

  try {
    const result = await handler.post(doc, { postedBy, ...ctx });

    const status = String(result?.status || 'FAILED').toUpperCase();
    const glEntryIds = Array.isArray(result?.glEntryIds) ? result.glEntryIds.map(String) : [];

    if (status === 'POSTED') {
      stats.posted[sourceType] += 1;

      await updateSourcePostingMeta({
        model,
        id,
        patch: {
          status: 'POSTED',
          glEntryIds,
          glEntryId: glEntryIds?.[0] || null,
          errorCode: null,
          errorMessage: null,
          postedAt: new Date(),
          postedBy,
          attemptsInc: 1,
          version: 1,
        },
      });

      return { ok: true, status: 'POSTED', glEntryIds };
    }

    if (status === 'SKIPPED') {
      stats.skipped[sourceType] += 1;

      const reason = keyOfReason(result?.reasonCode || 'SKIPPED');
      bumpReason(stats, reason, id);

      await updateSourcePostingMeta({
        model,
        id,
        patch: {
          status: 'SKIPPED',
          glEntryIds: [],
          glEntryId: null,
          errorCode: reason,
          errorMessage: result?.message || 'Skipped by policy/validation',
          postedAt: null,
          postedBy,
          attemptsInc: 1,
          version: 1,
        },
      });

      return { ok: true, status: 'SKIPPED', reasonCode: reason };
    }

    // FAILED
    stats.failed[sourceType] += 1;
    const reason = keyOfReason(result?.reasonCode || 'FAILED');
    bumpReason(stats, reason, id);

    await updateSourcePostingMeta({
      model,
      id,
      patch: {
        status: 'FAILED',
        glEntryIds: [],
        glEntryId: null,
        errorCode: reason,
        errorMessage: result?.message || 'Posting failed',
        postedAt: null,
        postedBy,
        attemptsInc: 1,
        version: 1,
      },
    });

    return { ok: false, status: 'FAILED', reasonCode: reason };
  } catch (e) {
    stats.failed[sourceType] += 1;

    const reason = keyOfReason(e?.code || e?.name || 'EXCEPTION');
    bumpReason(stats, reason, id);

    await updateSourcePostingMeta({
      model,
      id,
      patch: {
        status: 'FAILED',
        glEntryIds: [],
        glEntryId: null,
        errorCode: reason,
        errorMessage: e?.message || String(e),
        postedAt: null,
        postedBy,
        attemptsInc: 1,
        version: 1,
      },
    });

    return { ok: false, status: 'FAILED', reasonCode: reason };
  }
};

// -------------------------
// Query builders (migration-safe)
// -------------------------

/**
 * Orders:
 * - Only DELIVERY (channel missing OR 'DELIVERY')
 * - Delivered only (posting handler enforces paid rule, but we reduce input noise here)
 * - Business date: orderDate preferred, fallback createdAt ONLY when orderDate missing
 */
const buildOrderRebuildMatch = ({ startIncl, endIncl, branchMatch, requireDelivered = false }) => {
  const dateOr = [
    { orderDate: { $gte: startIncl, $lte: endIncl } },
    { orderDate: { $exists: false }, createdAt: { $gte: startIncl, $lte: endIncl } },
  ];

  const channelOr = [{ channel: { $exists: false } }, { channel: 'DELIVERY' }];

  const and = [{ $or: dateOr }, { $or: channelOr }];

  if (requireDelivered) and.push({ status: 'Delivered' });

  return { ...branchMatch, $and: and };
};

/**
 * DailySummary:
 * - Business date: date
 * - In rebuild we allow all statuses (approved/in_progress) and let handler SKIP by policy.
 *   This is important for migration visibility.
 */
const buildDailyRebuildMatch = ({ startIncl, endIncl, branchMatch, requireApproved = false }) => {
  const base = { ...branchMatch, date: { $gte: startIncl, $lte: endIncl } };
  if (requireApproved) base.status = 'approved';
  return base;
};

/**
 * Expenses:
 * - Business date: date
 * - status may vary; handler decides (or you can enforce approved here if your workflow is strict)
 */
const buildExpenseRebuildMatch = ({ startIncl, endIncl, branchMatch, requireApproved = false }) => {
  const base = { ...branchMatch, date: { $gte: startIncl, $lte: endIncl } };
  if (requireApproved) base.status = { $in: ['approved', 'Approved', 'APPROVED'] };
  return base;
};

/**
 * StockIn:
 * - Business date: purchaseDate
 */
const buildStockRebuildMatch = ({ startIncl, endIncl, branchMatch }) => ({
  ...branchMatch,
  purchaseDate: { $gte: startIncl, $lte: endIncl },
});

// -------------------------
// Orchestrator: rebuild (migration + recovery)
// -------------------------
//
// Purpose: migration/recovery. Rebuild GL from operational docs for a date range.
// Behavior:
// 1) (optional) deletes GL entries in range (and branchKey if provided) unless dryRun=true
// 2) pulls operational docs using business date fields
// 3) posts in safe sequence: StockIn -> DailySummary -> Orders -> Expenses
//    (so Inventory/WAC exist before COGS on sales)
// 4) returns full visibility: posted/skipped/failed + reasons/examples
//
const rebuild = async ({ startDate, endDate, branchId = null, dryRun = false, postedBy = 'system' }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }

  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);

  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const branchMatch = buildBranchOrZoneMatch(branchKey);

  // 1) Delete GL entries in range (only if not dryRun)
  if (!dryRun) {
    const delFilter = { date: { $gte: startIncl, $lte: endIncl } };
    if (branchKey) delFilter.branchKey = branchKey;
    await GeneralLedgerEntry.deleteMany(delFilter);
  }

  // 2) Pull operational docs (business dates only)
  const [stockIns, dailies, orders, expenses] = await Promise.all([
    StockIn.find(buildStockRebuildMatch({ startIncl, endIncl, branchMatch })).lean(),
    DailySummary.find(buildDailyRebuildMatch({ startIncl, endIncl, branchMatch, requireApproved: false })).lean(),
    Order.find(buildOrderRebuildMatch({ startIncl, endIncl, branchMatch, requireDelivered: false })).lean(),
    ExpenseTransaction.find(buildExpenseRebuildMatch({ startIncl, endIncl, branchMatch, requireApproved: false })).lean(),
  ]);

  const stats = makeStats();

  // 3) Post in safe sequence
  // NOTE: when dryRun=true, we still execute handlers in "dryRun mode" if they support it;
  // otherwise we simulate by not deleting GL but handlers might still upsert.
  // Best practice: handlers should honor ctx.dryRun and avoid writing.
  const ctx = { dryRun: Boolean(dryRun), branchKey };

  for (const s of stockIns) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postStockIn, model: StockIn, doc: s, sourceType: 'STOCK_IN', stats, postedBy, ctx });
  }

  for (const d of dailies) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postDailySummaryPOS, model: DailySummary, doc: d, sourceType: 'DAILY_SUMMARY', stats, postedBy, ctx });
  }

  for (const o of orders) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postOrderDelivery, model: Order, doc: o, sourceType: 'ORDER', stats, postedBy, ctx });
  }

  for (const e of expenses) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postExpenseTransaction, model: ExpenseTransaction, doc: e, sourceType: 'EXPENSE', stats, postedBy, ctx });
  }

  return {
    ok: true,
    dryRun: Boolean(dryRun),
    start: startIncl.toISOString(),
    end: endIncl.toISOString(),
    branchId: branchKey,
    found: {
      stockIns: stockIns?.length || 0,
      dailies: dailies?.length || 0,
      orders: orders?.length || 0,
      expenses: expenses?.length || 0,
    },
    ...stats,
  };
};

// -------------------------
// Orchestrator: post-approved (day-to-day ops)
// -------------------------
//
// Posts all APPROVED docs for a single business date.
// This replaces “rebuild all the time”.
//
// Input shape (controller uses this):
//   postApproved({ date: 'YYYY-MM-DD', branchId })
//
const postApproved = async ({ date, branchId = null, postedBy = 'system' }) => {
  const d = toISODate(date);
  if (!d) {
    const e = new Error('Invalid date');
    e.code = 'BAD_DATE';
    throw e;
  }

  const start = startOfDay(d);
  const end = endOfDay(d);

  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const branchMatch = buildBranchOrZoneMatch(branchKey);

  const [stockIns, dailies, orders, expenses] = await Promise.all([
    StockIn.find(buildStockRebuildMatch({ startIncl: start, endIncl: end, branchMatch })).lean(),
    DailySummary.find(buildDailyRebuildMatch({ startIncl: start, endIncl: end, branchMatch, requireApproved: true })).lean(),
    Order.find(buildOrderRebuildMatch({ startIncl: start, endIncl: end, branchMatch, requireDelivered: true })).lean(),
    ExpenseTransaction.find(buildExpenseRebuildMatch({ startIncl: start, endIncl: end, branchMatch, requireApproved: true })).lean(),
  ]);

  const stats = makeStats();
  const ctx = { dryRun: false, branchKey };

  for (const s of stockIns) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postStockIn, model: StockIn, doc: s, sourceType: 'STOCK_IN', stats, postedBy, ctx });
  }

  for (const ds of dailies) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postDailySummaryPOS, model: DailySummary, doc: ds, sourceType: 'DAILY_SUMMARY', stats, postedBy, ctx });
  }

  for (const o of orders) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postOrderDelivery, model: Order, doc: o, sourceType: 'ORDER', stats, postedBy, ctx });
  }

  for (const ex of expenses) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postExpenseTransaction, model: ExpenseTransaction, doc: ex, sourceType: 'EXPENSE', stats, postedBy, ctx });
  }

  return {
    ok: true,
    date: start.toISOString().slice(0, 10),
    branchId: branchKey,
    found: {
      stockIns: stockIns?.length || 0,
      dailies: dailies?.length || 0,
      orders: orders?.length || 0,
      expenses: expenses?.length || 0,
    },
    ...stats,
  };
};

// -------------------------
// Orchestrator: retry-failed
// -------------------------
//
// Finds FAILED source docs in a date range and retries handlers.
//
const retryFailed = async ({ startDate, endDate, branchId = null, postedBy = 'system' }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }

  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);

  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const branchMatch = buildBranchOrZoneMatch(branchKey);

  const [stockIns, dailies, orders, expenses] = await Promise.all([
    StockIn.find({ ...buildStockRebuildMatch({ startIncl, endIncl, branchMatch }), 'posting.status': 'FAILED' }).lean(),
    DailySummary.find({ ...buildDailyRebuildMatch({ startIncl, endIncl, branchMatch, requireApproved: false }), 'posting.status': 'FAILED' }).lean(),
    Order.find({ ...buildOrderRebuildMatch({ startIncl, endIncl, branchMatch, requireDelivered: false }), 'posting.status': 'FAILED' }).lean(),
    ExpenseTransaction.find({ ...buildExpenseRebuildMatch({ startIncl, endIncl, branchMatch, requireApproved: false }), 'posting.status': 'FAILED' }).lean(),
  ]);

  const stats = makeStats();
  const ctx = { dryRun: false, branchKey };

  for (const s of stockIns) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postStockIn, model: StockIn, doc: s, sourceType: 'STOCK_IN', stats, postedBy, ctx });
  }
  for (const d of dailies) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postDailySummaryPOS, model: DailySummary, doc: d, sourceType: 'DAILY_SUMMARY', stats, postedBy, ctx });
  }
  for (const o of orders) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postOrderDelivery, model: Order, doc: o, sourceType: 'ORDER', stats, postedBy, ctx });
  }
  for (const e of expenses) {
    // eslint-disable-next-line no-await-in-loop
    await runOne({ handler: postExpenseTransaction, model: ExpenseTransaction, doc: e, sourceType: 'EXPENSE', stats, postedBy, ctx });
  }

  return {
    ok: true,
    start: startIncl.toISOString(),
    end: endIncl.toISOString(),
    branchId: branchKey,
    found: {
      stockIns: stockIns?.length || 0,
      dailies: dailies?.length || 0,
      orders: orders?.length || 0,
      expenses: expenses?.length || 0,
    },
    ...stats,
  };
};

// -------------------------
// Orchestrator: trial-balance
// -------------------------
const trialBalance = async ({ startDate, endDate, branchId = null }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }

  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);

  const branchKey = hasVal(branchId) ? String(branchId) : null;

  const match = { status: 'POSTED', date: { $gte: startIncl, $lte: endIncl } };
  if (branchKey) match.branchKey = branchKey;

  const rows = await GeneralLedgerEntry.aggregate([
    { $match: match },
    { $unwind: '$lines' },
    {
      $group: {
        _id: '$lines.accountCode',
        debit: { $sum: '$lines.debit' },
        credit: { $sum: '$lines.credit' },
      },
    },
    { $sort: { _id: 1 } },
  ]);

  const coa = await ChartOfAccount.find({ isActive: true }).lean();
  const coaMap = new Map(coa.map((a) => [String(a.accountCode), a]));

  const shaped = rows.map((r) => {
    const meta = coaMap.get(String(r._id)) || null;
    const debit = safeNum(r.debit, 0);
    const credit = safeNum(r.credit, 0);
    const balance = meta?.normalBalance === 'CREDIT' ? credit - debit : debit - credit;

    return {
      accountCode: String(r._id),
      accountName: meta?.name || 'Unknown',
      accountType: meta?.type || 'UNKNOWN',
      normalBalance: meta?.normalBalance || null,
      debit,
      credit,
      balance,
    };
  });

  const totals = shaped.reduce(
    (acc, r) => {
      acc.debit += safeNum(r.debit, 0);
      acc.credit += safeNum(r.credit, 0);
      return acc;
    },
    { debit: 0, credit: 0 }
  );

  const diff = Math.abs(totals.debit - totals.credit);

  return {
    ok: diff <= 0.5,
    totals,
    diff,
    rows: shaped,
    period: { start: startIncl, end: endIncl },
    branch: { branchId: branchKey },
  };
};

// -------------------------
// Orchestrator: posting-exceptions
// -------------------------
//
// Reads posting.status/errorCode from source docs and returns grouped failures.
// This is the “explain the 153 errors” endpoint.
//
const postingExceptions = async ({ startDate, endDate, branchId = null }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }

  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);

  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const branchMatch = buildBranchOrZoneMatch(branchKey);

  const [stockIns, dailies, orders, expenses] = await Promise.all([
    StockIn.find({ ...branchMatch, purchaseDate: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' })
      .select('_id purchaseDate posting branchId serviceZoneId zoneId plantId')
      .lean(),

    DailySummary.find({ ...branchMatch, date: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' })
      .select('_id date posting branchId serviceZoneId zoneId plantId')
      .lean(),

    Order.find({
      ...branchMatch,
      $and: [
        {
          $or: [
            { orderDate: { $gte: startIncl, $lte: endIncl } },
            { orderDate: { $exists: false }, createdAt: { $gte: startIncl, $lte: endIncl } },
          ],
        },
      ],
      'posting.status': 'FAILED',
    })
      .select('_id orderDate createdAt posting branchId serviceZoneId zoneId plantId')
      .lean(),

    ExpenseTransaction.find({ ...branchMatch, date: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' })
      .select('_id date posting branchId serviceZoneId zoneId plantId')
      .lean(),
  ]);

  const reasons = {};
  const pushOne = (sourceType, doc, businessDate) => {
    const code = keyOfReason(doc?.posting?.errorCode || 'FAILED');
    if (!reasons[code]) reasons[code] = { count: 0, examples: [] };

    reasons[code].count += 1;

    if (reasons[code].examples.length < 10) {
      reasons[code].examples.push({
        sourceType,
        sourceId: String(doc._id),
        branchKey: toBranchKey(doc),
        businessDate: businessDate ? new Date(businessDate).toISOString().slice(0, 10) : null,
        message: doc?.posting?.errorMessage || null,
        attempts: safeNum(doc?.posting?.attempts, 0),
      });
    }
  };

  (stockIns || []).forEach((x) => pushOne('STOCK_IN', x, x.purchaseDate));
  (dailies || []).forEach((x) => pushOne('DAILY_SUMMARY', x, x.date));
  (orders || []).forEach((x) => pushOne('ORDER', x, x.orderDate || x.createdAt));
  (expenses || []).forEach((x) => pushOne('EXPENSE', x, x.date));

  return {
    ok: true,
    start: startIncl.toISOString(),
    end: endIncl.toISOString(),
    branchId: branchKey,
    totals: {
      failed:
        (stockIns?.length || 0) + (dailies?.length || 0) + (orders?.length || 0) + (expenses?.length || 0),
    },
    reasons,
  };
};

module.exports = {
  // setup
  bootstrap,

  // migration + recovery
  rebuild,

  // daily ops
  postApproved,
  retryFailed,

  // finance controls
  trialBalance,
  postingExceptions,

  // reversal utility (admin use)
  postReversal,
};