// File: src/api/v2/gl/services/coaMapping.service.js
//
// Purpose (GL-first):
// Central place to map operational fields -> GL accounts.
//
// - Expense category/type -> OPEX account (6000-6500)
// - Payment disposition/method -> cash/bank/AP account (1000/1010/1020/2000)
// - Revenue accounts (POS vs Delivery) (4000/4010)
// - Inventory/COGS accounts (1200/5000)
// - Optional: allow overrides from a Policy Matrix config.
//
// Notes:
// - This module is used by posting handlers.
// - It MUST stay deterministic (no silent guessing that changes over time).
//
// Expected operational fields (for clean posting):
// - ExpenseTransaction: { category/type, paymentDisposition/paymentMethod/mode }
// - DailySummary.sales: { cashAmount, transferAmount, posAmount, totalRevenue }
// - Order: { paymentMethod, paymentStatus, status }
// - StockIn: { paymentStatus/isPaid/amountPaid, etc. }

const ChartOfAccount = require('../../../../models/chartOfAccount.model');

let policy = null;
try {
  // eslint-disable-next-line global-require
  policy = require('../policyMatrix');
} catch (e) {
  policy = null;
}

// -------------------------
// tiny helpers
// -------------------------
const safeStr = (v) => (v === undefined || v === null ? '' : String(v));
const lc = (v) => safeStr(v).toLowerCase().trim();

const hasVal = (v) => safeStr(v).trim() !== '';

const DEFAULT_ACCOUNTS = Object.freeze({
  // Assets
  CASH_ON_HAND: '1000',
  BANK_TRANSFERS: '1010',
  BANK_POS: '1020',
  ACCOUNTS_RECEIVABLE: '1100',
  INVENTORY_LPG: '1200',

  // Liabilities
  ACCOUNTS_PAYABLE: '2000',
  TAX_PAYABLE: '2200',

  // Equity
  SHARE_CAPITAL: '3000',
  RETAINED_EARNINGS: '3100',

  // Income
  SALES_POS: '4000',
  SALES_DELIVERY: '4010',

  // Expenses
  COGS_LPG: '5000',
  STAFF_COSTS: '6000',
  LOGISTICS_FUEL: '6100',
  UTILITIES: '6200',
  MAINTENANCE: '6300',
  MARKETING: '6400',
  ADMIN_GENERAL: '6500',
});

const DEFAULT_EXPENSE_CATEGORY_MAP = Object.freeze({
  staff: DEFAULT_ACCOUNTS.STAFF_COSTS,
  salaries: DEFAULT_ACCOUNTS.STAFF_COSTS,
  wages: DEFAULT_ACCOUNTS.STAFF_COSTS,

  logistics: DEFAULT_ACCOUNTS.LOGISTICS_FUEL,
  fuel: DEFAULT_ACCOUNTS.LOGISTICS_FUEL,
  transport: DEFAULT_ACCOUNTS.LOGISTICS_FUEL,
  dispatch: DEFAULT_ACCOUNTS.LOGISTICS_FUEL,
  vehicle: DEFAULT_ACCOUNTS.LOGISTICS_FUEL,

  utilities: DEFAULT_ACCOUNTS.UTILITIES,
  power: DEFAULT_ACCOUNTS.UTILITIES,
  electricity: DEFAULT_ACCOUNTS.UTILITIES,
  diesel: DEFAULT_ACCOUNTS.UTILITIES,
  internet: DEFAULT_ACCOUNTS.UTILITIES,

  maintenance: DEFAULT_ACCOUNTS.MAINTENANCE,
  repair: DEFAULT_ACCOUNTS.MAINTENANCE,
  service: DEFAULT_ACCOUNTS.MAINTENANCE,

  marketing: DEFAULT_ACCOUNTS.MARKETING,
  advert: DEFAULT_ACCOUNTS.MARKETING,
  promo: DEFAULT_ACCOUNTS.MARKETING,

  admin: DEFAULT_ACCOUNTS.ADMIN_GENERAL,
  general: DEFAULT_ACCOUNTS.ADMIN_GENERAL,
  office: DEFAULT_ACCOUNTS.ADMIN_GENERAL,
});

/**
 * Policy overrides:
 * If you have policyMatrix.js with mappings, we respect it:
 *   policy.coa.accounts -> override codes
 *   policy.expenses.categoryKeywords -> keyword->accountCode overrides
 *   policy.payments.paymentToAccount -> payment disposition/method -> accountCode
 */
const loadPolicyOverrides = () => {
  const p = policy && typeof policy === 'object' ? policy : {};
  const coa = p.coa && typeof p.coa === 'object' ? p.coa : {};
  const accounts = coa.accounts && typeof coa.accounts === 'object' ? coa.accounts : {};
  const expenses = p.expenses && typeof p.expenses === 'object' ? p.expenses : {};
  const categoryKeywords =
    expenses.categoryKeywords && typeof expenses.categoryKeywords === 'object' ? expenses.categoryKeywords : {};
  const payments = p.payments && typeof p.payments === 'object' ? p.payments : {};
  const paymentToAccount =
    payments.paymentToAccount && typeof payments.paymentToAccount === 'object' ? payments.paymentToAccount : {};

  return { accounts, categoryKeywords, paymentToAccount };
};

const getAccountCode = (key) => {
  const { accounts } = loadPolicyOverrides();
  return accounts?.[key] || DEFAULT_ACCOUNTS[key] || null;
};

// -------------------------
// COA validation (optional, but recommended)
// -------------------------
const _coaCache = {
  loadedAt: 0,
  ttlMs: 30_000,
  codes: new Set(),
};

const refreshCOACacheIfNeeded = async () => {
  const now = Date.now();
  if (now - _coaCache.loadedAt < _coaCache.ttlMs && _coaCache.codes.size > 0) return;

  const rows = await ChartOfAccount.find({ isActive: true }).select('accountCode').lean();
  _coaCache.codes = new Set((rows || []).map((r) => String(r.accountCode)));
  _coaCache.loadedAt = now;
};

const ensureAccountExists = async (accountCode) => {
  if (!accountCode) return false;
  await refreshCOACacheIfNeeded();
  return _coaCache.codes.has(String(accountCode));
};

const ensureAccountsExistOrThrow = async (codes = []) => {
  await refreshCOACacheIfNeeded();
  const missing = (codes || []).filter((c) => c && !_coaCache.codes.has(String(c)));
  if (missing.length) {
    const e = new Error(`COA missing required accounts: ${missing.join(', ')}`);
    e.code = 'COA_MISSING_ACCOUNTS';
    e.missing = missing;
    throw e;
  }
};

// -------------------------
// MAPPING: Expense category -> account
// -------------------------
const mapExpenseCategoryToAccount = async (expense) => {
  const { categoryKeywords } = loadPolicyOverrides();

  const raw = lc(expense?.category || expense?.type);
  if (!raw) return getAccountCode('ADMIN_GENERAL');

  // 1) policy keyword overrides (strongest)
  //    e.g., { "rent": "6500", "generator": "6200" }
  for (const [keyword, accountCode] of Object.entries(categoryKeywords || {})) {
    if (!keyword) continue;
    if (raw.includes(lc(keyword))) return String(accountCode);
  }

  // 2) default keyword mapping
  for (const [keyword, accountCode] of Object.entries(DEFAULT_EXPENSE_CATEGORY_MAP)) {
    if (raw.includes(keyword)) return String(accountCode);
  }

  // 3) fallback (admin/general)
  return getAccountCode('ADMIN_GENERAL');
};

// -------------------------
// MAPPING: Payment disposition -> cash/bank/AP account
// -------------------------
/**
 * mapPaymentToCreditAccount
 * Used for the CREDIT side of an Expense or Stock purchase:
 * - CASH      -> 1000
 * - TRANSFER  -> 1010
 * - POS       -> 1020
 * - UNPAID/AP -> 2000
 */
const mapPaymentToCreditAccount = async (paymentDispositionOrMethod) => {
  const { paymentToAccount } = loadPolicyOverrides();

  const pm = lc(paymentDispositionOrMethod);

  // 1) policy overrides
  if (hasVal(pm)) {
    for (const [k, v] of Object.entries(paymentToAccount || {})) {
      if (lc(k) === pm) return String(v);
    }
  }

  // 2) defaults (tolerant synonyms)
  if (pm.includes('unpaid') || pm.includes('payable') || pm.includes('credit') || pm.includes('ap')) return getAccountCode('ACCOUNTS_PAYABLE');
  if (pm.includes('transfer') || pm.includes('bank')) return getAccountCode('BANK_TRANSFERS');
  if (pm.includes('pos') || pm === 'card') return getAccountCode('BANK_POS');
  return getAccountCode('CASH_ON_HAND');
};

/**
 * mapPOSReceiptsSplitToDebitAccounts
 * For DailySummary POS totals, we want to DEBIT the receipt accounts (cash/transfer/pos)
 * in the correct proportions, then CREDIT revenue.
 *
 * Input dailySummary.sales:
 * - cashAmount
 * - transferAmount
 * - posAmount
 * - totalRevenue
 *
 * Output lines like:
 *   [{ accountCode: '1000', amount: 64600 }, { accountCode:'1010', amount:0 }, { accountCode:'1020', amount:71000 }]
 *
 * If split is missing/zeros, we fall back to "1000" cash.
 */
const mapPOSReceiptsSplitToDebitAccounts = async (dailySummary) => {
  const cash = Number(dailySummary?.sales?.cashAmount || 0) || 0;
  const transfer = Number(dailySummary?.sales?.transferAmount || 0) || 0;
  const pos = Number(dailySummary?.sales?.posAmount || 0) || 0;
  const totalRevenue = Number(dailySummary?.sales?.totalRevenue || 0) || 0;

  const parts = [
    { accountCode: getAccountCode('CASH_ON_HAND'), amount: cash },
    { accountCode: getAccountCode('BANK_TRANSFERS'), amount: transfer },
    { accountCode: getAccountCode('BANK_POS'), amount: pos },
  ].filter((p) => p.amount > 0.00001);

  const sumParts = parts.reduce((s, p) => s + p.amount, 0);

  // If no split data, debit cash-on-hand for total revenue
  if (parts.length === 0 || sumParts <= 0) {
    return totalRevenue > 0
      ? [{ accountCode: getAccountCode('CASH_ON_HAND'), amount: totalRevenue }]
      : [];
  }

  // If split exists but doesn't match total revenue, we keep the split and (optionally) adjust
  // To avoid silent corruption, we DO NOT auto-normalize. Posting handler can decide what to do.
  // We return the split as-is plus a metadata summary.
  return parts;
};

/**
 * mapOrderPaymentToDebitAccount
 * Used for DELIVERY paid orders:
 * - paymentMethod/card/pos -> 1020
 * - transfer/bank         -> 1010
 * - else cash             -> 1000
 *
 * For unpaid delivered orders:
 * - debit AR (1100)
 */
const mapOrderPaymentToDebitAccount = async (order, paid) => {
  if (!paid) return getAccountCode('ACCOUNTS_RECEIVABLE');

  const pm = lc(order?.paymentMethod);
  if (pm.includes('pos') || pm === 'card') return getAccountCode('BANK_POS');
  if (pm.includes('transfer') || pm.includes('bank')) return getAccountCode('BANK_TRANSFERS');
  return getAccountCode('CASH_ON_HAND');
};

// -------------------------
// Account getters (centralized)
// -------------------------
const getRevenueAccountPOS = () => getAccountCode('SALES_POS');
const getRevenueAccountDelivery = () => getAccountCode('SALES_DELIVERY');
const getInventoryAccount = () => getAccountCode('INVENTORY_LPG');
const getCogsAccount = () => getAccountCode('COGS_LPG');

// -------------------------
// Validate core COA required by posting engine
// -------------------------
const validateCoreCOAOrThrow = async () => {
  const required = [
    getAccountCode('CASH_ON_HAND'),
    getAccountCode('BANK_TRANSFERS'),
    getAccountCode('BANK_POS'),
    getAccountCode('ACCOUNTS_RECEIVABLE'),
    getAccountCode('INVENTORY_LPG'),
    getAccountCode('ACCOUNTS_PAYABLE'),
    getAccountCode('SALES_POS'),
    getAccountCode('SALES_DELIVERY'),
    getAccountCode('COGS_LPG'),
    getAccountCode('STAFF_COSTS'),
    getAccountCode('LOGISTICS_FUEL'),
    getAccountCode('UTILITIES'),
    getAccountCode('MAINTENANCE'),
    getAccountCode('MARKETING'),
    getAccountCode('ADMIN_GENERAL'),
  ].filter(Boolean);

  await ensureAccountsExistOrThrow(required);
  return { ok: true, requiredCount: required.length };
};

module.exports = {
  DEFAULT_ACCOUNTS,

  // COA validation
  ensureAccountExists,
  ensureAccountsExistOrThrow,
  validateCoreCOAOrThrow,

  // Expense mappings
  mapExpenseCategoryToAccount,

  // Payment mappings
  mapPaymentToCreditAccount,
  mapPOSReceiptsSplitToDebitAccounts,
  mapOrderPaymentToDebitAccount,

  // Core account getters
  getRevenueAccountPOS,
  getRevenueAccountDelivery,
  getInventoryAccount,
  getCogsAccount,
};