/**
 * File: src/api/v2/gl/services/journalUpsert.service.js
 * Shared helper for handlers to upsert balanced journals.
 *
 * IMPORTANT:
 * - GeneralLedgerEntry schema enforces unique index on:
 *   { branchKey, sourceType, sourceId, entryType }
 * - Therefore upsert filter MUST match that key (no version in filter).
 */
const GeneralLedgerEntry = require('../../../../models/generalLedgerEntry.model');

const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const normalizeLines = (lines) =>
  (Array.isArray(lines) ? lines : [])
    .map((l) => ({
      accountCode: String(l.accountCode || '').trim(),
      debit: safeNum(l.debit, 0),
      credit: safeNum(l.credit, 0),
      narration: l.narration ? String(l.narration) : '',
    }))
    .filter((l) => l.accountCode && (l.debit > 0 || l.credit > 0));

const sumLines = (lines) => {
  const debit = (lines || []).reduce((s, l) => s + safeNum(l.debit, 0), 0);
  const credit = (lines || []).reduce((s, l) => s + safeNum(l.credit, 0), 0);
  return { debit, credit };
};

const assertBalanced = (lines, tolerance = 0.5) => {
  const { debit, credit } = sumLines(lines);
  const diff = Math.abs(debit - credit);
  if (diff > tolerance) {
    const e = new Error(`Unbalanced journal: debit=${debit} credit=${credit} diff=${diff}`);
    e.code = 'UNBALANCED_JOURNAL';
    throw e;
  }
};

/**
 * Upsert journal by schema idempotency key:
 *  { branchKey, sourceType, sourceId, entryType }
 *
 * NOTE: we accept "version" but we DO NOT use it in filter,
 * otherwise it conflicts with the schema unique index.
 */
const upsertJournal = async ({ date, branchKey, sourceType, sourceId, entryType, narration, lines }) => {
  if (!date || Number.isNaN(new Date(date).getTime())) {
    const e = new Error('Invalid journal date');
    e.code = 'BAD_DATE';
    throw e;
  }
  if (!sourceType || !sourceId) {
    const e = new Error('sourceType and sourceId are required');
    e.code = 'MISSING_SOURCE';
    throw e;
  }

  const normalized = normalizeLines(lines);
  assertBalanced(normalized);

  const totals = sumLines(normalized);

  const doc = {
    date: new Date(date),
    branchKey: branchKey ? String(branchKey) : null,
    sourceType: String(sourceType),
    sourceId: String(sourceId),
    entryType: entryType ? String(entryType) : 'PRIMARY',
    narration: narration || '',
    status: 'POSTED',
    lines: normalized,
    totals,
  };

  const filter = {
    branchKey: doc.branchKey,
    sourceType: doc.sourceType,
    sourceId: doc.sourceId,
    entryType: doc.entryType,
  };

  await GeneralLedgerEntry.updateOne(filter, { $set: doc }, { upsert: true });

  const found = await GeneralLedgerEntry.findOne(filter).select('_id').lean();
  return { glEntryIds: found?._id ? [String(found._id)] : [], created: false };
};

module.exports = { upsertJournal, assertBalanced };