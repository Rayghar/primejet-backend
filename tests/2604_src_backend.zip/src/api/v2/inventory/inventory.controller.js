// src/api/v2/inventory/inventory.controller.js
const Asset = require('../../../models/asset.model');
const Loan = require('../../../models/loan.model');
const Cylinder = require('../../../models/cylinder.model');
const StockIn = require('../../../models/stockIn.model');
const Order = require('../../../models/order.model');
const DailySummary = require('../../../models/dailySummary.model');
const HttpError = require('../../../utils/HttpError');
const { logger } = require('../../../config/logger.config');
const mongoose = require('mongoose');

// -------------------------
// Helpers
// -------------------------
const hasVal = (v) => v !== undefined && v !== null && String(v).trim() !== '';

const toNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

// Supports older/newer API callers: branchId or serviceZoneId
const getBranchScope = (req) => {
  const branchId = req.query?.branchId || req.query?.serviceZoneId || req.body?.branchId || req.body?.serviceZoneId;
  return hasVal(branchId) ? String(branchId) : '';
};

const parseDateSafe = (v) => {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
};

const findByAnyIdAndDelete = async (Model, id) => {
  if (!id) return null;

  // Try custom "id" first (your app pattern), then Mongo _id
  let deleted = await Model.findOneAndDelete({ id });
  if (deleted) return deleted;

  if (mongoose.Types.ObjectId.isValid(id)) {
    deleted = await Model.findByIdAndDelete(id);
    if (deleted) return deleted;
  }

  return null;
};

/**
 * Fetches all assets.
 * Optional filter: branchId/serviceZoneId (if asset model stores branchId)
 */
const getAssets = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);
    const filter = {};
    if (branchId) filter.branchId = branchId;

    const assets = await Asset.find(filter).sort({ createdAt: -1, _id: -1 });
    res.status(200).json(assets);
  } catch (error) {
    logger.error('Error fetching assets:', error);
    next(new HttpError(500, 'Failed to fetch assets.'));
  }
};

/**
 * Adds a new asset.
 */
const addAsset = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);

    const payload = {
      ...req.body,
      cost: toNum(req.body?.cost, 0),
    };

    // Make IDs explicit and consistent with frontend delete flow
    if (!payload.id) payload.id = new mongoose.Types.ObjectId().toString();
    if (branchId && !payload.branchId) payload.branchId = branchId;

    if (hasVal(payload.purchaseDate)) {
      const parsed = parseDateSafe(payload.purchaseDate);
      if (!parsed) throw new HttpError(400, 'Invalid purchaseDate.');
      payload.purchaseDate = parsed;
    }

    const newAsset = new Asset(payload);
    await newAsset.save();

    res.status(201).json(newAsset);
  } catch (error) {
    logger.error('Error adding asset:', error);
    if (error instanceof HttpError) return next(error);
    if (error.name === 'ValidationError') return next(new HttpError(400, error.message));
    next(new HttpError(500, 'Failed to add asset.'));
  }
};

/**
 * Deletes an asset by its ID.
 */
const deleteAsset = async (req, res, next) => {
  try {
    const { assetId } = req.params;
    const deleted = await findByAnyIdAndDelete(Asset, assetId);
    if (!deleted) throw new HttpError(404, 'Asset not found.');

    res.status(200).json({ message: 'Asset deleted successfully.' });
  } catch (error) {
    logger.error('Error deleting asset:', error);
    next(error instanceof HttpError ? error : new HttpError(500, 'Failed to delete asset.'));
  }
};

/**
 * Fetches all loans.
 * Optional filter: branchId/serviceZoneId (if loan model stores branchId)
 */
const getLoans = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);
    const filter = {};
    if (branchId) filter.branchId = branchId;

    const loans = await Loan.find(filter).sort({ createdAt: -1, _id: -1 });
    res.status(200).json(loans);
  } catch (error) {
    logger.error('Error fetching loans:', error);
    next(new HttpError(500, 'Failed to fetch loans.'));
  }
};

/**
 * Adds a new loan.
 */
const addLoan = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);

    const payload = {
      ...req.body,
      principal: toNum(req.body?.principal, 0),
      interestRate: toNum(req.body?.interestRate, 0),
      term: toNum(req.body?.term, 0),
    };

    if (!payload.id) payload.id = new mongoose.Types.ObjectId().toString();
    if (branchId && !payload.branchId) payload.branchId = branchId;

    const newLoan = new Loan(payload);
    await newLoan.save();

    res.status(201).json(newLoan);
  } catch (error) {
    logger.error('Error adding loan:', error);
    if (error.name === 'ValidationError') return next(new HttpError(400, error.message));
    next(new HttpError(500, 'Failed to add loan.'));
  }
};

/**
 * Deletes a loan by its ID.
 */
const deleteLoan = async (req, res, next) => {
  try {
    const { loanId } = req.params;
    const deleted = await findByAnyIdAndDelete(Loan, loanId);
    if (!deleted) throw new HttpError(404, 'Loan not found.');

    res.status(200).json({ message: 'Loan deleted successfully.' });
  } catch (error) {
    logger.error('Error deleting loan:', error);
    next(error instanceof HttpError ? error : new HttpError(500, 'Failed to delete loan.'));
  }
};

/**
 * Fetches all cylinders.
 * Optional filter: branchId/serviceZoneId (if cylinder model stores branchId)
 */
const getCylinders = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);
    const filter = {};
    if (branchId) filter.branchId = branchId;

    const cylinders = await Cylinder.find(filter).sort({ createdAt: -1, _id: -1 });
    res.status(200).json(cylinders);
  } catch (error) {
    logger.error('Error fetching cylinders:', error);
    next(new HttpError(500, 'Failed to fetch cylinders.'));
  }
};

/**
 * Adds a new cylinder.
 */
const addCylinder = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);

    const payload = {
      ...req.body,
      quantity: toNum(req.body?.quantity, 0),
    };

    if (!payload.id) payload.id = new mongoose.Types.ObjectId().toString();
    if (branchId && !payload.branchId) payload.branchId = branchId;

    const newCylinder = new Cylinder(payload);
    await newCylinder.save();

    res.status(201).json(newCylinder);
  } catch (error) {
    logger.error('Error adding cylinder:', error);
    if (error.name === 'ValidationError') return next(new HttpError(400, error.message));
    next(new HttpError(500, 'Failed to add cylinder.'));
  }
};

/**
 * Deletes a cylinder by its ID.
 */
const deleteCylinder = async (req, res, next) => {
  try {
    const { cylinderId } = req.params;
    const deleted = await findByAnyIdAndDelete(Cylinder, cylinderId);
    if (!deleted) throw new HttpError(404, 'Cylinder batch not found.');

    res.status(200).json({ message: 'Cylinder batch deleted successfully.' });
  } catch (error) {
    logger.error('Error deleting cylinder:', error);
    next(error instanceof HttpError ? error : new HttpError(500, 'Failed to delete cylinder.'));
  }
};

/**
 * Logs a new stock-in (bulk LPG purchase) transaction.
 */
const addStockIn = async (req, res, next) => {
  try {
    const {
      quantityKg,
      supplier,
      purchaseDate,
      costPerKg,
      targetSalePricePerKg,
    } = req.body;

    const branchId = getBranchScope(req);
    const loggedBy = { uid: req.user?.id, email: req.user?.email };

    if (!branchId) {
      throw new HttpError(400, 'branchId (or serviceZoneId) is required for stock-in.');
    }

    const qty = toNum(quantityKg, NaN);
    const cost = toNum(costPerKg, NaN);
    const targetPrice = toNum(targetSalePricePerKg, NaN);
    const purchaseDt = parseDateSafe(purchaseDate);

    if (!Number.isFinite(qty) || qty <= 0) throw new HttpError(400, 'quantityKg must be a positive number.');
    if (!Number.isFinite(cost) || cost < 0) throw new HttpError(400, 'costPerKg must be a valid number.');
    if (!Number.isFinite(targetPrice) || targetPrice < 0) throw new HttpError(400, 'targetSalePricePerKg must be a valid number.');
    if (!purchaseDt) throw new HttpError(400, 'purchaseDate is invalid.');

    const newStockIn = new StockIn({
      id: new mongoose.Types.ObjectId().toString(),
      branchId,
      quantityKg: qty,
      supplier,
      purchaseDate: purchaseDt,
      costPerKg: cost,
      targetSalePricePerKg: targetPrice,
      remainingKg: qty,
      loggedBy,
    });

    await newStockIn.save();

    logger.info(`New stock-in logged: ${qty}kg from ${supplier} (branch ${branchId}) by ${req.user?.email || 'system'}`);
    res.status(201).json({ message: 'Stock-in logged successfully.', stockIn: newStockIn });
  } catch (error) {
    logger.error('Error adding stock-in:', error);
    if (error.name === 'ValidationError') {
      return next(new HttpError(400, error.message));
    }
    next(error instanceof HttpError ? error : new HttpError(500, 'Failed to log stock-in.'));
  }
};

/**
 * ✅ Provides a comprehensive summary of inventory data.
 * Source of truth = StockIn.remainingKg
 */
const getInventorySummary = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);

    const stockMatch = {};
    if (branchId) stockMatch.branchId = branchId;

    // Total stocked (for reporting only)
    const totalStockedResult = await StockIn.aggregate([
      { $match: stockMatch },
      { $group: { _id: null, total: { $sum: '$quantityKg' } } },
    ]);
    const totalStockedKg = toNum(totalStockedResult[0]?.total, 0);

    // ✅ Source of truth: remaining stock
    const remainingResult = await StockIn.aggregate([
      { $match: stockMatch },
      { $group: { _id: null, remaining: { $sum: '$remainingKg' } } },
    ]);
    const currentBulkLpgKg = toNum(remainingResult[0]?.remaining, 0);

    // Derived sold (informational only)
    const totalSoldKg = Math.max(0, totalStockedKg - currentBulkLpgKg);

    // Capacity approximation for dashboards (lets UI show stock % if desired)
    const totalCapacity = totalStockedKg;

    // Cylinders may or may not be branch-scoped in your schema
    const cylinderMatch = {};
    if (branchId) cylinderMatch.branchId = branchId;

    let totalCylinders = 0;
    try {
      const totalCylindersResult = await Cylinder.aggregate([
        { $match: cylinderMatch },
        { $group: { _id: null, total: { $sum: '$quantity' } } },
      ]);
      totalCylinders = toNum(totalCylindersResult[0]?.total, 0);
    } catch (e) {
      // If Cylinder schema has no branchId but branch filter supplied, fallback gracefully
      if (branchId) {
        const totalCylindersResult = await Cylinder.aggregate([
          { $group: { _id: null, total: { $sum: '$quantity' } } },
        ]);
        totalCylinders = toNum(totalCylindersResult[0]?.total, 0);
      } else {
        throw e;
      }
    }

    const lowStockThresholdKg = 1000;
    const lowStockAlert = currentBulkLpgKg < lowStockThresholdKg;
    const stockUtilizationPct = totalCapacity > 0 ? (currentBulkLpgKg / totalCapacity) * 100 : 0;

    res.status(200).json({
      branchId: branchId || null,
      currentBulkLpgKg,
      currentStock: currentBulkLpgKg, // alias for frontend compatibility
      totalSoldKg,
      totalStockedKg,
      totalCapacity,
      totalCylinders,
      lowStockAlert,
      lowStockThresholdKg,
      stockUtilizationPct: Number(stockUtilizationPct.toFixed(2)),
    });
  } catch (error) {
    logger.error('Error fetching inventory summary:', error);
    next(new HttpError(500, 'Failed to fetch inventory summary.'));
  }
};

/**
 * ✅ Fetches LPG stock-in history with profitability.
 * Uses batch consumption = quantityKg - remainingKg
 */
const getLpgStockInHistory = async (req, res, next) => {
  try {
    const branchId = getBranchScope(req);

    const stockMatch = {};
    if (branchId) stockMatch.branchId = branchId;

    const stockIns = await StockIn.find(stockMatch).sort({ purchaseDate: -1, _id: -1 }).lean();

    // Fetch relevant sales inputs once (branch-aware where possible)
    const orderFilter = {
      status: 'Delivered',
    };
    if (branchId) orderFilter.branchId = branchId;

    const summaryFilter = {
      status: 'approved',
    };
    if (branchId) summaryFilter.branchId = branchId;

    const [deliveredOrders, approvedSummaries] = await Promise.all([
      Order.find(orderFilter).select('grandTotal items orderDate createdAt channel branchId').lean(),
      DailySummary.find(summaryFilter).select('date sales pricePerKg branchId').lean(),
    ]);

    const historyWithProfitability = stockIns.map((batch) => {
      const quantityKg = toNum(batch.quantityKg, 0);
      const remainingKg = toNum(batch.remainingKg, 0);
      const costPerKg = toNum(batch.costPerKg, 0);
      const targetSalePricePerKg = toNum(batch.targetSalePricePerKg, 0);
      const batchPurchaseDate = parseDateSafe(batch.purchaseDate) || new Date(0);

      const batchSoldKg = Math.max(0, quantityKg - remainingKg);

      const expectedRevenue = quantityKg * targetSalePricePerKg;
      const totalCost = quantityKg * costPerKg;

      // Filter sales after batch purchaseDate
      const relevantOrders = deliveredOrders.filter((o) => {
        const d = parseDateSafe(o.orderDate || o.createdAt);
        if (!d) return false;
        // If channel exists, keep delivery-only (exclude POS DailySummary overlap)
        if (String(o.channel || '').toUpperCase() === 'POS') return false;
        return d >= batchPurchaseDate;
      });

      const relevantSummaries = approvedSummaries.filter((s) => {
        const d = parseDateSafe(s.date);
        if (!d) return false;
        return d >= batchPurchaseDate;
      });

      // Compute average realized prices (simple, non-double-counting)
      const deliveryKg = relevantOrders.reduce((sum, o) => {
        const itemsKg = Array.isArray(o.items)
          ? o.items.reduce((s, it) => s + toNum(it?.quantity, 0), 0)
          : 0;
        return sum + itemsKg;
      }, 0);
      const deliveryRevenue = relevantOrders.reduce((sum, o) => sum + toNum(o?.grandTotal, 0), 0);
      const deliveryAvgPrice = deliveryKg > 0 ? deliveryRevenue / deliveryKg : 0;

      const posKg = relevantSummaries.reduce((sum, s) => sum + toNum(s?.sales?.totalKgSold, 0), 0);
      const posRevenue = relevantSummaries.reduce((sum, s) => sum + toNum(s?.sales?.totalRevenue, 0), 0);
      const posAvgPrice = posKg > 0 ? posRevenue / posKg : 0;

      // Estimate revenue for this batch sold kg using blended avg price
      let observedAvgPrice = 0;
      if (deliveryAvgPrice > 0 && posAvgPrice > 0) observedAvgPrice = (deliveryAvgPrice + posAvgPrice) / 2;
      else if (deliveryAvgPrice > 0) observedAvgPrice = deliveryAvgPrice;
      else if (posAvgPrice > 0) observedAvgPrice = posAvgPrice;
      else observedAvgPrice = targetSalePricePerKg || 0;

      const estimatedActualRevenue = batchSoldKg * observedAvgPrice;

      const profitLoss = estimatedActualRevenue - totalCost;
      const profitMargin = totalCost > 0 ? (profitLoss / totalCost) * 100 : 0;
      const salesProgress = quantityKg > 0 ? (batchSoldKg / quantityKg) * 100 : 0;

      return {
        ...batch,
        batchSoldKg,
        expectedRevenue,
        totalCost,
        estimatedActualRevenue,
        profitLoss,
        profitMargin: Number(profitMargin.toFixed(2)),
        salesProgress: Number(salesProgress.toFixed(2)),
        observedAvgPricePerKg: Number(toNum(observedAvgPrice, 0).toFixed(2)),
      };
    });

    res.status(200).json(historyWithProfitability);
  } catch (error) {
    logger.error('Error fetching LPG stock-in history:', error);
    next(new HttpError(500, 'Failed to retrieve LPG stock-in history.'));
  }
};

module.exports = {
  getAssets,
  addAsset,
  deleteAsset,
  getLoans,
  addLoan,
  deleteLoan,
  getCylinders,
  addCylinder,
  deleteCylinder,
  addStockIn,
  getInventorySummary,
  getLpgStockInHistory,
};
