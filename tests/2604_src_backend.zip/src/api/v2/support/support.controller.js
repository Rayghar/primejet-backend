const mongoose = require('mongoose');
const Order = require('../../../models/order.model');
const Run = require('../../../models/run.model');
const User = require('../../../models/user.model');
const HttpError = require('../../../utils/HttpError');
const { logger } = require('../../../config/logger.config');

const safeInt = (v, d = 10) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : d;
};

const normalizeRunStatus = (s) => String(s || '').toLowerCase();

const getSupportHub = async (req, res, next) => {
  try {
    const limit = Math.min(50, Math.max(5, safeInt(req.query.limit, 10)));
    const sinceDays = Math.min(30, Math.max(1, safeInt(req.query.sinceDays, 7)));
    const branchId = req.query.branchId || null;

    const since = new Date();
    since.setDate(since.getDate() - sinceDays);

    // ------------------------------------------------------------
    // 1) Active runs snapshot
    // ------------------------------------------------------------
    const runsMatch = {};
    if (branchId) runsMatch.branchId = branchId;

    const activeRuns = await Run.find(runsMatch)
      .select('id overallStatus driverId stops totalStops estimatedStartDate createdAt updatedAt')
      .lean();

    const assignedRuns = activeRuns.filter((r) => normalizeRunStatus(r.overallStatus) === 'assigned');
    const activeDeliveryRuns = activeRuns.filter((r) =>
      ['in progress', 'active', 'on delivery'].includes(normalizeRunStatus(r.overallStatus))
    );

    // ------------------------------------------------------------
    // 2) Unassigned orders count (fast path)
    //    We treat an order as "new/unassigned" if:
    //    - not delivered/canceled/failed
    //    - not assigned to driver (driverId missing)
    //    - recent (since)
    // ------------------------------------------------------------
    const orderBaseMatch = {
      status: { $nin: ['Delivered', 'Canceled', 'Failed'] },
      $or: [{ driverId: { $exists: false } }, { driverId: null }, { driverId: '' }],
      createdAt: { $gte: since },
    };
    if (branchId) orderBaseMatch.branchId = branchId;

    const newCustomerOrdersCount = await Order.countDocuments(orderBaseMatch);

    // ------------------------------------------------------------
    // 3) Recent customer orders (latest orders)
    //    Uses lookups to attach customer details if available
    //    We use "userId" if it exists, else fallback to "customerId".
    // ------------------------------------------------------------
    const recentOrders = await Order.aggregate([
      {
        $match: {
          ...(branchId ? { branchId } : {}),
          createdAt: { $gte: since },
        },
      },
      { $sort: { createdAt: -1 } },
      { $limit: limit },

      // derive a best-effort customer key
      {
        $addFields: {
          _customerKey: {
            $ifNull: ['$userId', '$customerId'],
          },
        },
      },

      // join user (optional)
      {
        $lookup: {
          from: User.collection.name,
          localField: '_customerKey',
          foreignField: 'id',
          as: '_user',
        },
      },
      { $unwind: { path: '$_user', preserveNullAndEmptyArrays: true } },

      {
        $project: {
          _id: 0,
          id: '$id',
          status: '$status',
          paymentStatus: '$paymentStatus',
          grandTotal: '$grandTotal',
          orderDate: '$orderDate',
          createdAt: '$createdAt',
          updatedAt: '$updatedAt',
          branchId: '$branchId',

          // customer identity
          customerId: '$_customerKey',
          customerName: {
            $ifNull: [
              '$customerName',
              { $ifNull: ['$_user.name', { $ifNull: ['$_user.fullName', 'Customer'] }] },
            ],
          },
          customerEmail: { $ifNull: ['$customerEmail', '$_user.email'] },
          customerPhone: { $ifNull: ['$customerPhone', '$_user.phone'] },
        },
      },
    ]);

    // ------------------------------------------------------------
    // 4) Customers needing attention:
    //    group recent orders by customer and count pending/active.
    // ------------------------------------------------------------
    const attentionCustomers = await Order.aggregate([
      {
        $match: {
          ...(branchId ? { branchId } : {}),
          createdAt: { $gte: since },
          status: { $nin: ['Delivered', 'Canceled', 'Failed'] },
        },
      },
      {
        $addFields: {
          _customerKey: { $ifNull: ['$userId', '$customerId'] },
          _statusLower: { $toLower: { $ifNull: ['$status', ''] } },
        },
      },
      {
        $group: {
          _id: '$_customerKey',
          pendingCount: {
            $sum: {
              $cond: [
                {
                  $or: [
                    { $regexMatch: { input: '$_statusLower', regex: 'pending' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'placed' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'processing' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'ready' } },
                  ],
                },
                1,
                0,
              ],
            },
          },
          activeCount: {
            $sum: {
              $cond: [
                {
                  $or: [
                    { $regexMatch: { input: '$_statusLower', regex: 'driver assigned' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'delivery' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'in progress' } },
                    { $regexMatch: { input: '$_statusLower', regex: 'pickup' } },
                  ],
                },
                1,
                0,
              ],
            },
          },
          totalOrders: { $sum: 1 },
          lastOrderAt: { $max: '$createdAt' },
        },
      },
      { $sort: { lastOrderAt: -1 } },
      { $limit: Math.min(limit, 15) },

      // attach user (optional)
      {
        $lookup: {
          from: User.collection.name,
          localField: '_id',
          foreignField: 'id',
          as: '_user',
        },
      },
      { $unwind: { path: '$_user', preserveNullAndEmptyArrays: true } },

      {
        $project: {
          _id: 0,
          customerId: '$_id',
          customerName: { $ifNull: ['$_user.name', { $ifNull: ['$_user.fullName', 'Customer'] }] },
          customerEmail: '$_user.email',
          customerPhone: '$_user.phone',
          pendingCount: 1,
          activeCount: 1,
          totalOrders: 1,
          lastOrderAt: 1,
        },
      },
    ]);

    // ------------------------------------------------------------
    // Final response
    // ------------------------------------------------------------
    return res.status(200).json({
      ok: true,
      params: { limit, sinceDays, branchId: branchId || null },

      queue: {
        newCustomerOrders: newCustomerOrdersCount,
        ordersAssigned: assignedRuns.length,
        activeDeliveries: activeDeliveryRuns.length,
        totalRuns: activeRuns.length,
      },

      recentOrders,
      attentionCustomers,
    });
  } catch (error) {
    logger.error('[SUPPORT HUB] Error:', error);
    next(error instanceof HttpError ? error : new HttpError(500, 'Failed to load support hub.'));
  }
};

module.exports = {
  getSupportHub,
};
