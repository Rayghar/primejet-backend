const express = require('express');
const router = express.Router();

const authMiddleware = require('../../../middleware/auth.middleware');
const { getSupportHub } = require('./support.controller');

// GET /api/v2/support/hub?limit=10&sinceDays=7&branchId=...
router.get('/hub', authMiddleware, getSupportHub);

module.exports = router;
