// src/models/dailySummary.model.js
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const PostingSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['UNPOSTED', 'POSTED', 'FAILED'],
      default: 'UNPOSTED',
      index: true,
    },
    glEntryId: { type: String, default: null },
    glEntryIds: { type: [String], default: [] },
    postedAt: { type: Date, default: null },
    postedBy: { type: String, default: null },
    attempts: { type: Number, default: 0 },
    errorCode: { type: String, default: null },
    errorMessage: { type: String, default: null },
    // keep for future use but do NOT use it in GL idempotency
    version: { type: Number, default: 1 },
  },
  { _id: false }
);

const dailySummarySchema = new mongoose.Schema(
  {
    dailySummaryId: {
      type: String,
      unique: true,
      required: true,
      default: uuidv4,
      index: true,
    },

    // ✅ Business date used for POS accounting
    date: { type: Date, required: true, index: true },

    // Plant/Branch
    branchId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Plant',
      required: true,
      index: true,
    },

    cashierName: { type: String, required: true, minlength: 3, maxlength: 100 },

    // ✅ pricePerKg is used in controller/service
    pricePerKg: { type: Number, required: true, min: 0.01, default: 0.01 },

    status: {
      type: String,
      enum: ['in_progress', 'pending_approval', 'approved', 'rejected'],
      default: 'in_progress',
      index: true,
    },

    openingMeters: {
      meterA: { type: Number, required: true, default: 0 },
      meterB: { type: Number, default: 0 },
    },
    closingMeters: {
      meterA: { type: Number, required: true, default: 0 },
      meterB: { type: Number, default: 0 },
    },

    // ✅ Must match data-entry.service expectations
    sales: {
      totalRevenue: { type: Number, default: 0 },     // used by GL + financials
      totalKgSold: { type: Number, default: 0 },
      posAmount: { type: Number, default: 0 },
      cashAmount: { type: Number, default: 0 },
      transferAmount: { type: Number, default: 0 },

      // Keep (if you ever store sale tx IDs)
      items: [{ type: mongoose.Schema.Types.ObjectId, ref: 'SaleTransaction' }],

      // Backward compatibility if any legacy code wrote this
      calculatedRevenue: { type: Number, default: 0 },
    },

    expenses: {
      total: { type: Number, default: 0 },
      items: [{ type: mongoose.Schema.Types.ObjectId, ref: 'ExpenseTransaction' }],
    },

    reconciliation: {
      calculatedRevenue: { type: Number, default: 0 },
      discrepancy: { type: Number, default: 0 },
    },

    managerApproval: {
      approvedBy: { type: String, default: null },
      approvedAt: { type: Date, default: null },
      rejectedBy: { type: String, default: null },
      rejectedAt: { type: Date, default: null },
      isApproved: { type: Boolean, default: false },
      rejectionReason: { type: String, default: null },
    },

    // ✅ Required for GL posting pipeline to persist state
    posting: { type: PostingSchema, default: () => ({}) },

    createdBy: { type: String, default: null },
  },
  { timestamps: true }
);

dailySummarySchema.index({ dailySummaryId: 1 }, { unique: true });

module.exports = mongoose.model('DailySummary', dailySummarySchema);