const mongoose = require('mongoose');

const PostingSchema = new mongoose.Schema(
  {
    status: { type: String, enum: ['UNPOSTED', 'POSTED', 'FAILED'], default: 'UNPOSTED', index: true },
    glEntryId: { type: String, default: null },
    glEntryIds: { type: [String], default: [] },
    postedAt: { type: Date, default: null },
    postedBy: { type: String, default: null },
    attempts: { type: Number, default: 0 },
    errorCode: { type: String, default: null },
    errorMessage: { type: String, default: null },
    version: { type: Number, default: 1 },
  },
  { _id: false }
);

const expenseTransactionSchema = new mongoose.Schema(
  {
    dailySummaryId: { type: mongoose.Schema.Types.ObjectId, ref: 'DailySummary', required: true, index: true },

    // Keep string to support both ObjectId-string and serviceZone UUID if needed
    branchId: { type: String, required: true, index: true },

    cashierId: { type: String, required: true, index: true },

    // ✅ Controller validates this; must persist it
    category: {
      type: String,
      enum: ['Fuel', 'Maintenance', 'Salaries', 'Utilities', 'Miscellaneous'],
      required: true,
      index: true,
    },

    // Optional: supports GL handler credit mapping
    paymentDisposition: { type: String, default: null }, // CASH|TRANSFER|POS|UNPAID

    description: { type: String, required: true },
    amount: { type: Number, required: true, min: 0.01 },

    isReconciled: { type: Boolean, default: false },

    // ✅ Business date
    date: { type: Date, required: true, default: Date.now, index: true },

    posting: { type: PostingSchema, default: () => ({}) },
  },
  { timestamps: true }
);

module.exports = mongoose.model('ExpenseTransaction', expenseTransactionSchema);