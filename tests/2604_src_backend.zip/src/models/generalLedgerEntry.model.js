// File: src/models/generalLedgerEntry.model.js
const mongoose = require('mongoose');

const glLineSchema = new mongoose.Schema(
  {
    accountCode: { type: String, required: true, index: true },
    debit: { type: Number, default: 0, min: 0 },
    credit: { type: Number, default: 0, min: 0 },
    narration: { type: String, default: '', trim: true },
  },
  { _id: false }
);

const generalLedgerEntrySchema = new mongoose.Schema(
  {
    // Business date of the journal (critical for migration accuracy)
    date: { type: Date, required: true, index: true },

    // YYYY-MM for easier grouping
    periodKey: { type: String, required: true, index: true },

    // Always store branchKey as STRING in GL (so mixed ObjectId/string sources don’t break postings)
    branchKey: { type: String, default: null, index: true },

    // Traceability
    sourceType: {
      type: String,
      required: true,
      enum: ['DAILY_SUMMARY', 'SALE_TX', 'EXPENSE', 'STOCK_IN', 'ORDER', 'MANUAL', 'REVERSAL'],
      index: true,
    },
    sourceId: { type: String, default: null, index: true }, // string form of _id or external id
    entryType: { type: String, default: 'AUTO', index: true }, // AUTO | RECEIPT | ADJUSTMENT | REVERSAL
    version: { type: Number, default: 1, min: 1 },

    narration: { type: String, default: '', trim: true },

    status: {
      type: String,
      enum: ['POSTED', 'REVERSED', 'VOID'],
      default: 'POSTED',
      index: true,
    },

    // Journal lines (debit/credit)
    lines: { type: [glLineSchema], default: [] },

    // Optional reversal linkage
    reversedByEntryId: { type: mongoose.Schema.Types.ObjectId, ref: 'GeneralLedgerEntry', default: null },
    reversesEntryId: { type: mongoose.Schema.Types.ObjectId, ref: 'GeneralLedgerEntry', default: null },
  },
  { timestamps: true }
);

// Idempotency: one journal per (branchKey, sourceType, sourceId, entryType, version)
generalLedgerEntrySchema.index(
  { branchKey: 1, sourceType: 1, sourceId: 1, entryType: 1, version: 1 },
  { unique: true, partialFilterExpression: { sourceId: { $type: 'string' } } }
);

module.exports = mongoose.model('GeneralLedgerEntry', generalLedgerEntrySchema);