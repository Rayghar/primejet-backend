// File: src/models/saleTransaction.model.js
const mongoose = require('mongoose');

const postingSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      enum: ['UNPOSTED', 'QUEUED', 'POSTED', 'FAILED', 'SKIPPED', 'REVERSED'],
      default: 'UNPOSTED',
      index: true,
    },
    glEntryId: { type: mongoose.Schema.Types.ObjectId, ref: 'GeneralLedgerEntry', default: null },
    glEntryIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'GeneralLedgerEntry' }],
    postedAt: { type: Date, default: null },
    postedBy: { type: String, default: null },
    attempts: { type: Number, default: 0 },
    errorCode: { type: String, default: null },
    errorMessage: { type: String, default: null },
    version: { type: Number, default: 1 },
  },
  { _id: false }
);

const saleTransactionSchema = new mongoose.Schema(
  {
    // ✅ business date
    date: { type: Date, required: true, index: true },

    branchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Plant', required: true, index: true },

    // Optional: link to a DailySummary closeout
    dailySummaryId: { type: mongoose.Schema.Types.ObjectId, ref: 'DailySummary', default: null, index: true },

    // LPG metrics
    kgSold: { type: Number, required: true, min: 0 },
    pricePerKg: { type: Number, required: true, min: 0 },

    // Amounts (allow split)
    totalRevenue: { type: Number, required: true, min: 0 },
    cashAmount: { type: Number, default: 0, min: 0 },
    transferAmount: { type: Number, default: 0, min: 0 },
    posAmount: { type: Number, default: 0, min: 0 },

    // Workflow
    status: {
      type: String,
      enum: ['draft', 'pending_approval', 'approved', 'rejected'],
      default: 'draft',
      index: true,
    },

    cashierName: { type: String, default: null, trim: true },

    // ✅ GL posting metadata
    posting: { type: postingSchema, default: () => ({}) },
  },
  { timestamps: true }
);

saleTransactionSchema.index({ branchId: 1, date: 1 });
saleTransactionSchema.index({ dailySummaryId: 1, date: 1 });

module.exports = mongoose.model('SaleTransaction', saleTransactionSchema);