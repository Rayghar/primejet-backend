// src/models/stockIn.model.js
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const PostingSchema = new mongoose.Schema(
  {
    status: { type: String, enum: ['UNPOSTED', 'POSTED', 'FAILED'], default: 'UNPOSTED', index: true },
    glEntryId: { type: String, default: null },
    glEntryIds: { type: [String], default: [] },
    postedAt: { type: Date, default: null },
    postedBy: { type: String, default: null },
    attempts: { type: Number, default: 0 },
    errorCode: { type: String, default: null },
    errorMessage: { type: String, default: null },
    version: { type: Number, default: 1 },
  },
  { _id: false }
);

const stockInSchema = new mongoose.Schema(
  {
    id: {
      type: String,
      required: true,
      unique: true,
      default: () => uuidv4(),
      index: true,
    },

    // can be ObjectId string OR serviceZone UUID depending on your deployment
    branchId: { type: String, required: true, index: true },

    quantityKg: { type: Number, required: true, min: 0.01 },
    remainingKg: { type: Number, required: true, min: 0 },

    supplier: { type: String, required: true, trim: true, maxlength: 100 },

    // ✅ business date for inventory + WAC
    purchaseDate: { type: Date, required: true, index: true },

    costPerKg: { type: Number, required: true, min: 0.01 },
    targetSalePricePerKg: { type: Number, required: true, min: 0.01 },

    // ✅ Payment signals for payables logic (financials + GL handler)
    amountPaid: { type: Number, default: 0 },
    paidAmount: { type: Number, default: 0 },
    isPaid: { type: Boolean, default: false },
    paymentStatus: { type: String, default: null }, // paid|settled|completed|...

    loggedBy: {
      uid: { type: String, required: true },
      email: { type: String, required: true },
    },

    posting: { type: PostingSchema, default: () => ({}) },
  },
  { timestamps: true }
);

module.exports = mongoose.model('StockIn', stockInSchema);