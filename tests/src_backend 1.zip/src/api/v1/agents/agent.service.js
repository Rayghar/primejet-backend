// File: src/api/v1/agents/agent.service.js
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const Agent = require('../../../models/agent.model');
const AgentReferralEvent = require('../../../models/agentReferralEvent.model');
const User = require('../../../models/user.model'); // To update user's referredByAgentId
const HttpError = require('../../../utils/HttpError');
const JWT_SECRET = process.env.JWT_SECRET || 'your-default-super-secret-key-for-dev';

// Base URL for your app's deep links (e.g., from Firebase Dynamic Links or custom scheme)
// This should be configured in your .env file.
const BASE_APP_DEEPLINK_URL = process.env.BASE_APP_DEEPLINK_URL || 'https://yourdomain.com/app';
const APP_STORE_LINK = process.env.APP_STORE_LINK || 'https://play.google.com/store/apps/details?id=com.example.yourapp';

// Helper to generate a unique agent code
const generateUniqueAgentCode = async (length = 6) => {
  let agentCode;
  let isUnique = false;
  while (!isUnique) {
    agentCode = crypto.randomBytes(Math.ceil(length / 2)).toString('hex').slice(0, length).toUpperCase();
    const existingAgent = await Agent.findOne({ agentCode });
    if (!existingAgent) {
      isUnique = true;
    }
  }
  return agentCode;
};

const login = async (email, password) => {
  const lcEmail = email.toLowerCase();
  let userRecord;

  // First, check if the user is an Agent
  let user = await Agent.findOne({ email: lcEmail }).select('+password');

  // If not found as an Agent, check if they are an Admin
  if (!user) {
    user = await Admin.findOne({ email: lcEmail }).select('+password');
  }

  if (!user) {
    throw new HttpError(401, 'Invalid email or password.');
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    throw new HttpError(401, 'Invalid email or password.');
  }

  // Create a JWT payload (works for both Admins and Agents)
  const payload = { id: user.id, role: user.role || 'admin' }; // Default to 'admin' role if not specified
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1d' });

  // Return the token and the user object (excluding password)
  const userObject = user.toObject();
  delete userObject.password;

  return { token, agent: userObject }; // Keep 'agent' key for frontend compatibility
};

// Admin: Create a new agent
const createAgent = async (agentData) => {
  const { name, email, phone, password, agentCode: providedAgentCode, isActive } = agentData;

  // Check for uniqueness of email, phone, and agentCode
  const existingAgentByPhone = await Agent.findOne({ phone });
  if (existingAgentByPhone) {
    throw new HttpError(409, 'Agent with this phone number already exists.');
  }
  if (email) {
    const existingAgentByEmail = await Agent.findOne({ email });
    if (existingAgentByEmail) {
      throw new HttpError(409, 'Agent with this email already exists.');
    }
  }

  const agentCodeToUse = providedAgentCode ? providedAgentCode.toUpperCase() : await generateUniqueAgentCode();
  const existingAgentByCode = await Agent.findOne({ agentCode: agentCodeToUse });
  if (existingAgentByCode) {
    throw new HttpError(409, `Agent code '${agentCodeToUse}' already exists. Please choose another.`);
  }

  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const referralLink = `${BASE_APP_DEEPLINK_URL}/agent_onboard?agentCode=${agentCodeToUse}`;

  const newAgent = new Agent({
    id: uuidv4(),
    name,
    email,
    phone,
    password: hashedPassword,
    agentCode: agentCodeToUse,
    referralLink,
    isActive,
  });

  await newAgent.save();
  return newAgent.toObject();
};

// Admin: Get all agents with pagination and search
const getAgents = async ({ page = 1, limit = 10, search = '', isActive }) => {
  const query = {};
  if (search) {
    const searchRegex = new RegExp(search, 'i');
    query.$or = [
      { name: searchRegex },
      { email: searchRegex },
      { phone: searchRegex },
      { agentCode: searchRegex },
    ];
  }
  if (typeof isActive === 'boolean') {
    query.isActive = isActive;
  }

  const totalAgents = await Agent.countDocuments(query);
  const agents = await Agent.find(query)
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit);

  return {
    agents: agents.map(agent => agent.toObject()),
    currentPage: page,
    totalPages: Math.ceil(totalAgents / limit),
    totalAgents,
  };
};

// Admin: Get a single agent by ID
const getAgentById = async (agentId) => {
  const agent = await Agent.findOne({ id: agentId });
  if (!agent) {
    throw new HttpError(404, 'Agent not found.');
  }
  return agent.toObject();
};

const getAllReferredCustomers = async ({ page = 1, limit = 15, search = '' }) => {
  const query = {
    // Find users who have the referredByAgentId field populated
    referredByAgentId: { $exists: true, $ne: null }
  };

  if (search) {
    const searchRegex = new RegExp(search, 'i');
    // Find agents that match the search query to filter users by them
    const matchingAgents = await Agent.find({
      $or: [{ name: searchRegex }, { agentCode: searchRegex }]
    }).select('id');
    const matchingAgentIds = matchingAgents.map(agent => agent.id);

    query.$or = [
      { name: searchRegex },
      { email: searchRegex },
      { phone: searchRegex },
      { referredByAgentId: { $in: matchingAgentIds } } // Find users referred by the matched agents
    ];
  }

  const totalCustomers = await User.countDocuments(query);
  const customers = await User.find(query)
    .populate('referredByAgentId', 'name agentCode') // Populate agent details
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit);

  return {
    customers: customers.map(user => user.toObject()),
    currentPage: page,
    totalPages: Math.ceil(totalCustomers / limit),
    totalCustomers,
  };
};

// Admin: Update an agent
const updateAgent = async (agentId, updateData) => {
  const agent = await Agent.findOne({ id: agentId });
  if (!agent) {
    throw new HttpError(404, 'Agent not found for update.');
  }

  // Handle uniqueness checks for email, phone, agentCode if they are being updated
  if (updateData.phone && updateData.phone !== agent.phone) {
    const existingAgent = await Agent.findOne({ phone: updateData.phone, id: { $ne: agentId } });
    if (existingAgent) throw new HttpError(409, 'Phone number is already used by another agent.');
  }
  if (updateData.email && updateData.email !== agent.email) {
    const existingAgent = await Agent.findOne({ email: updateData.email, id: { $ne: agentId } });
    if (existingAgent) throw new HttpError(409, 'Email is already used by another agent.');
  }
  if (updateData.agentCode && updateData.agentCode.toUpperCase() !== agent.agentCode) {
    const existingAgent = await Agent.findOne({ agentCode: updateData.agentCode.toUpperCase(), id: { $ne: agentId } });
    if (existingAgent) throw new HttpError(409, 'Agent code is already in use.');
    updateData.agentCode = updateData.agentCode.toUpperCase(); // Ensure uppercase
    // If agent code changes, the referralLink needs to be updated too
    updateData.referralLink = `${BASE_APP_DEEPLINK_URL}/agent_onboard?agentCode=${updateData.agentCode}`;
  }

  if (updateData.password) {
    const salt = await bcrypt.genSalt(10);
    updateData.password = await bcrypt.hash(updateData.password, salt);
  }



  Object.keys(updateData).forEach(key => {
    if (updateData[key] !== undefined && key !== 'id' && key !== 'referralLink' && key !== 'totalCustomersReferred') {
      agent[key] = updateData[key];
    }
  });

  await agent.save();
  return agent.toObject();
};

// Admin: Delete an agent
const deleteAgent = async (agentId) => {
  const agent = await Agent.findOneAndDelete({ id: agentId });
  if (!agent) {
    throw new HttpError(404, 'Agent not found for deletion.');
  }
  // Optional: Also delete associated AgentReferralEvents if desired
  await AgentReferralEvent.deleteMany({ agentId });
  return { message: 'Agent and associated referral events deleted successfully.' };
};

// Public: Track a link click
const trackAgentLinkClick = async (agentCode, metadata = {}) => {
  const agent = await Agent.findOne({ agentCode: agentCode.toUpperCase() });
  if (!agent) {
    console.warn(`[AGENT_SERVICE] Agent code '${agentCode}' not found for link click tracking.`);
    return null; // Or throw HttpError if you want to indicate invalid code
  }

  const event = new AgentReferralEvent({
    id: uuidv4(),
    agentId: agent.id,
    eventType: 'LINK_CLICK',
    metadata: {
      ...metadata,
      userAgent: metadata.userAgent || 'unknown', // Example: capture user agent
      ipAddress: metadata.ipAddress || 'unknown', // Example: capture IP
    },
  });
  await event.save();
  console.log(`[AGENT_SERVICE] Logged LINK_CLICK for agent ${agent.id}.`);
  return agent; // Return the agent to allow redirection
};

// Internal: Mark customer as registered via agent
const markCustomerRegisteredByAgent = async (agentCode, customerId) => {
  const agent = await Agent.findOne({ agentCode: agentCode.toUpperCase() });
  if (!agent) {
    console.warn(`[AGENT_SERVICE] Agent code '${agentCode}' not found when marking customer ${customerId} as registered.`);
    return;
  }

  // Check if this customer has already been attributed to this agent
  const existingEvent = await AgentReferralEvent.findOne({
    agentId: agent.id,
    customerId: customerId,
    eventType: 'CUSTOMER_REGISTERED',
  });

  if (existingEvent) {
    console.log(`[AGENT_SERVICE] Customer ${customerId} already registered via agent ${agent.id}. Skipping duplicate event.`);
    return;
  }

  // Update agent's totalCustomersReferred count
  agent.totalCustomersReferred = (agent.totalCustomersReferred || 0) + 1;
  await agent.save();

  // Log the customer registration event
  const event = new AgentReferralEvent({
    id: uuidv4(),
    agentId: agent.id,
    customerId: customerId,
    eventType: 'CUSTOMER_REGISTERED',
  });
  await event.save();
  console.log(`[AGENT_SERVICE] Logged CUSTOMER_REGISTERED for customer ${customerId} via agent ${agent.id}.`);
};

// Admin: Get agent performance report (simple)
const getAgentPerformance = async (agentId) => {
  const agent = await Agent.findOne({ id: agentId });
  if (!agent) {
    throw new HttpError(404, 'Agent not found.');
  }

  const totalClicks = await AgentReferralEvent.countDocuments({ agentId, eventType: 'LINK_CLICK' });
  const totalRegistrations = await AgentReferralEvent.countDocuments({ agentId, eventType: 'CUSTOMER_REGISTERED' });

  return {
    agent: agent.toObject(),
    totalClicks,
    totalRegistrations,
    conversionRate: totalClicks > 0 ? (totalRegistrations / totalClicks) * 100 : 0,
  };
};

// Internal: Records the first successful purchase by a customer referred by an agent.
const recordFirstPurchase = async (agentId, customerId, order) => {
  const event = new AgentReferralEvent({
    agentId: agentId,
    customerId: customerId,
    eventType: 'FIRST_PURCHASE_COMPLETED',
    metadata: {
      orderId: order.id,
      purchaseAmountKobo: order.finalAmountPaid,
      orderDate: order.orderDate,
    },
  });
  await event.save();
  console.log(`[AGENT_SERVICE] Logged FIRST_PURCHASE_COMPLETED for customer ${customerId} via agent ${agentId}.`);
};

// ================== ADD THIS NEW FUNCTION ==================
/**
 * Admin: Get a summary of the campaign performance for the current day.
 */
const getCampaignSummary = async () => {
  // Define the start and end of the current day in the server's local timezone
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

  // Find customers who were created today and have a referring agent
  const referredToday = await User.find({
    referredByAgentId: { $exists: true, $ne: null },
    createdAt: { $gte: startOfDay, $lt: endOfDay }
  }).populate('referredByAgentId', 'name'); // Populate agent's name for top agent calculation

  const totalReferralsToday = referredToday.length;
  const totalRewardsToday = totalReferralsToday * 500; // NGN 500 reward per referral

  // Find the top performing agent for the day
  let topAgentToday = { name: 'N/A', referrals: 0 };
  if (totalReferralsToday > 0) {
    // Tally up referrals per agent
    const agentPerformance = referredToday.reduce((acc, user) => {
      if (user.referredByAgentId && user.referredByAgentId._id) {
          const agentId = user.referredByAgentId._id.toString();
          if (!acc[agentId]) {
            acc[agentId] = { name: user.referredByAgentId.name, referrals: 0 };
          }
          acc[agentId].referrals++;
      }
      return acc;
    }, {});

    // Find the agent with the highest tally
    const topPerformer = Object.values(agentPerformance).sort((a, b) => b.referrals - a.referrals)[0];
    if (topPerformer) {
      topAgentToday = topPerformer;
    }
  }

  return {
    totalReferralsToday,
    totalRewardsToday,
    topAgentToday,
  };
};


module.exports = {
  createAgent,
  getAgents,
  getAgentById,
  updateAgent,
  deleteAgent,
  trackAgentLinkClick,
  markCustomerRegisteredByAgent,
  getAgentPerformance,
  login,
  getAllReferredCustomers,
  getCampaignSummary,
  recordFirstPurchase,


};