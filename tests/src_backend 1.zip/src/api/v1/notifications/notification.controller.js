// File: src/api/v1/notifications/notification.controller.js
const notificationService = require('./notification.service');
const { logger } = require('../../../config/logger.config');

const getUserNotifications = async (req, res, next) => {
  try {
    const notifications = await notificationService.getUserNotifications(req.user.id);
    res.status(200).json(notifications);
  } catch (error) {
    next(error);
  }
};

const getUnreadCount = async (req, res, next) => {
  try {
    const count = await notificationService.getUnreadCount(req.user.id);
    res.status(200).json(count);
  } catch (error) {
    next(error);
  }
};

const markAllAsRead = async (req, res, next) => {
  try {
    const result = await notificationService.markAllAsRead(req.user.id);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

// Mark a single notification as read
const markAsRead = async (req, res, next) => {
  try {
    const { notificationId } = req.params;
    const result = await notificationService.markNotificationAsRead(notificationId, req.user.id);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

// Clear all notifications for the user
const clearAll = async (req, res, next) => {
  try {
    const result = await notificationService.clearAllNotifications(req.user.id);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

const getAdminNotifications = async (req, res, next) => {
  try {
    const { page, limit, type, unreadOnly } = req.query;

    const result = await notificationService.getAdminNotifications({
      page: parseInt(page, 10) || 1,
      limit: parseInt(limit, 10) || 20,
      type,
      unreadOnly: unreadOnly === 'true', // Convert query string to boolean
    });

    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getUserNotifications,
  getUnreadCount,
  markAllAsRead,
  getAdminNotifications,
  markAsRead,
  clearAll,
};
