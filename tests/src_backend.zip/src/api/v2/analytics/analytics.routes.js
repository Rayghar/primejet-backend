// src/api/v2/analytics/analytics.routes.js
const express = require('express');
const analyticsController = require('./analytics.controller');
const authMiddleware = require('../../../middleware/auth.middleware');

const router = express.Router();

const analyticsRoles = ['admin', 'manager', 'finance_lead'];

// Existing dashboard/sales analytics
router.get('/gas-plant-dashboard', authMiddleware(analyticsRoles), analyticsController.getGasPlantDashboard);
router.get('/dashboard-kpis', authMiddleware(analyticsRoles), analyticsController.getDashboardKpis);
router.get('/sales-report', authMiddleware(analyticsRoles), analyticsController.getSalesReport);
router.get('/sales-trends', authMiddleware(analyticsRoles), analyticsController.getSalesReport);
router.get('/sales-by-payment-method', authMiddleware(analyticsRoles), analyticsController.getSalesByPaymentMethod);
router.get('/sales-by-branch', authMiddleware(analyticsRoles), analyticsController.getSalesByBranch);
router.get('/top-selling-products', authMiddleware(analyticsRoles), analyticsController.getTopSellingProducts);

// Wave 14A de-staticized analytics endpoints
router.get('/heatmap', authMiddleware(analyticsRoles), analyticsController.getHeatmap);
router.get('/business-metrics', authMiddleware(analyticsRoles), analyticsController.getBusinessMetrics);
router.get('/growth-ltv', authMiddleware(analyticsRoles), analyticsController.getBusinessMetrics);
router.get('/driver-performance', authMiddleware(analyticsRoles), analyticsController.getDriverPerformance);
router.get('/branch-performance', authMiddleware(analyticsRoles), analyticsController.getBranchPerformance);
router.get('/daily-close-performance', authMiddleware(analyticsRoles), analyticsController.getDailyClosePerformance);

module.exports = router;
