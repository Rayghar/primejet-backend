// src/api/v2/financials/financials.routes.js
const express = require('express');
const financialsController = require('./financials.controller');
const authMiddleware = require('../../../middleware/auth.middleware');

const router = express.Router();

// Endpoint to get all financial statement data with server-side calculations.
router.get('/statements', authMiddleware(['admin', 'finance_lead']), financialsController.getFinancialStatements);

// Endpoint to get revenue assurance report
router.get('/revenue-assurance', authMiddleware(['admin', 'finance_lead']), financialsController.getRevenueAssuranceReport);

// NEW: Endpoint to get tax compliance report
router.get('/tax-compliance', authMiddleware(['admin', 'finance_lead']), financialsController.getTaxComplianceReport);
router.get('/cash-movement', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getCashMovementReport);
router.get('/expense-analysis', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getExpenseAnalysisReport);
router.get('/branch-pl', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getBranchProfitLossReport);
router.get('/source-trace', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getSourceTraceReport);
router.get('/wallet-liability', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getWalletLiabilityReport);
router.get('/failed-payments', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getFailedPaymentReviewQueue);

// Wave 11A — Optional manual settlement and revenue assurance controls.
// These controls are advisory only and must not block POS, approval, GL posting or financial statements.
router.get('/settlement-dashboard', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getSettlementDashboard);
router.get('/settlements', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getSettlementConfirmations);
router.post('/settlements/confirm', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.confirmSettlement);
router.get('/settlements/export', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.exportSettlements);
router.post('/statement-uploads', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.createStatementUpload);
router.get('/statement-uploads', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.listStatementUploads);
router.get('/revenue-leakage', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.getRevenueLeakageDashboard);
router.get('/export', authMiddleware(['admin', 'manager', 'finance_lead']), financialsController.exportFinancialReport);

module.exports = router;