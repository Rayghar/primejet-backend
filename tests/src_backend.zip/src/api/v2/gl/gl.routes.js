// File: src/api/v2/gl/gl.routes.js

const express = require('express');
const authMiddleware = require('../../../middleware/auth.middleware');
const gl = require('./gl.controller');

const router = express.Router();

// Help / field guidance
router.get('/help', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getHelpCatalog);

// GL reference data
router.get('/coa', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getCOA);

// GL setup/bootstrap
router.post('/bootstrap', authMiddleware(['admin', 'finance_lead']), gl.bootstrapCOA);

// GL operational health, journal drilldown and reversal
router.get('/health', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getHealth);
router.get('/confidence', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getFinanceConfidence);
router.get('/readiness', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getReadiness);
router.post('/readiness/run-safe-setup', authMiddleware(['admin', 'finance_lead']), gl.runSafeSetup);
router.get('/journals', authMiddleware(['admin', 'manager', 'finance_lead']), gl.listJournals);
router.get('/posting-batches', authMiddleware(['admin', 'manager', 'finance_lead']), gl.listPostingBatches);
router.get('/posting-batches/:batchId/export', authMiddleware(['admin', 'manager', 'finance_lead']), gl.exportPostingBatch);
router.get('/posting-batches/:batchId', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getPostingBatchDetail);
router.get('/periods', authMiddleware(['admin', 'manager', 'finance_lead']), gl.listPeriods);
router.post('/periods/lock', authMiddleware(['admin', 'finance_lead']), gl.lockPeriod);
router.post('/periods/reopen', authMiddleware(['admin', 'finance_lead']), gl.reopenPeriod);
router.post('/periods/generate', authMiddleware(['admin', 'finance_lead']), gl.generateFiscalPeriods);
router.get('/journals/export', authMiddleware(['admin', 'manager', 'finance_lead']), gl.exportJournals);
router.get('/journals/:journalId', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getJournalDetail);
router.post('/reverse', authMiddleware(['admin', 'finance_lead']), gl.reverseJournal);
router.get('/reversal-requests', authMiddleware(['admin', 'manager', 'finance_lead']), gl.listReversalRequests);
router.post('/reversal-requests', authMiddleware(['admin', 'finance_lead']), gl.requestReversal);
router.post('/reversal-requests/:requestId/approve', authMiddleware(['admin', 'finance_lead']), gl.approveReversalRequest);
router.post('/reversal-requests/:requestId/reject', authMiddleware(['admin', 'finance_lead']), gl.rejectReversalRequest);


// Rebuild journals from operational data
// Example: POST /api/v2/gl/rebuild?startDate=2025-06-01&endDate=2025-08-31
// Optional: &branchId=... or &serviceZoneId=...&dryRun=true
router.post('/rebuild', authMiddleware(['admin', 'finance_lead']), gl.rebuild);

// Day-to-day posting flow (GL-first)
// Post all approved sources for a business date
// Example: POST /api/v2/gl/post-approved?date=2025-08-31&branchId=...
router.post('/post-approved', authMiddleware(['admin', 'finance_lead']), gl.postApprovedForDate);

// Retry failures within a range
// Example: POST /api/v2/gl/retry-failed?startDate=2025-06-01&endDate=2025-08-31
router.post('/retry-failed', authMiddleware(['admin', 'finance_lead']), gl.retryFailedPostings);

// Inspect posting exceptions (grouped by reason)
// Example: GET /api/v2/gl/posting-exceptions?startDate=2025-06-01&endDate=2025-08-31
router.get('/posting-exceptions', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getPostingExceptions);

// Trial balance
// Example: GET /api/v2/gl/trial-balance?startDate=2025-06-01&endDate=2025-08-31
router.get('/trial-balance', authMiddleware(['admin', 'manager', 'finance_lead']), gl.getTrialBalance);

module.exports = router;