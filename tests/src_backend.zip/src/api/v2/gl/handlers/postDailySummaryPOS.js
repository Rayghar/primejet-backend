// File: src/api/v2/gl/handlers/postDailySummaryPOS.js
// Posts approved DailySummary POS sales to GL as one daily aggregated journal.

const mongoose = require('mongoose');
const DailySummary = require('../../../../models/dailySummary.model');
const BranchStockConfig = require('../../../../models/branchStockConfig.model');
const { upsertJournal } = require('../services/journalUpsert.service');
const {
  getRevenueAccountPOS,
  getCashOverShortAccount,
  DEFAULT_ACCOUNTS,
} = require('../services/coaMapping.service');
const { getWacCostPerKgAsOf } = require('../services/wac.service');

const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const toISODate = (d) => {
  const x = d ? new Date(d) : null;
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const toBranchKey = (doc) => {
  const v = doc?.branchId ?? doc?.serviceZoneId ?? doc?.zoneId ?? doc?.plantId ?? doc?.branchKey ?? null;
  return v == null ? null : String(v);
};

const postDailySummaryPOS = async (dsOrId, opts = {}) => {
  const ds =
    typeof dsOrId === 'string' || mongoose.Types.ObjectId.isValid(String(dsOrId))
      ? await DailySummary.findById(dsOrId).lean()
      : dsOrId;

  if (!ds) return { status: 'SKIPPED', reasonCode: 'DAILY_NOT_FOUND', message: 'Daily summary was not found' };

  const businessDate = toISODate(ds.date);
  if (!businessDate) return { status: 'SKIPPED', reasonCode: 'DAILY_INVALID_DATE', message: 'Daily summary has no valid business date' };

  const branchKey = toBranchKey(ds);
  if (!branchKey) return { status: 'SKIPPED', reasonCode: 'DAILY_MISSING_BRANCH', message: 'Daily summary has no branch/plant key' };

  const status = String(ds.status || '').toLowerCase().trim();
  if (status !== 'approved') return { status: 'SKIPPED', reasonCode: 'DAILY_NOT_APPROVED', message: 'Daily summary is not approved' };

  const revenue = safeNum(ds?.sales?.totalRevenue, 0);
  if (revenue <= 0) return { status: 'SKIPPED', reasonCode: 'DAILY_ZERO_REVENUE', message: 'Daily summary has zero revenue' };

  const cash = safeNum(ds?.sales?.cashAmount, 0);
  const transfer = safeNum(ds?.sales?.transferAmount, 0);
  const pos = safeNum(ds?.sales?.posAmount, 0);
  const tenderTotal = cash + transfer + pos;
  const diff = revenue - tenderTotal;
  const tolerance = safeNum(opts.tenderTolerance, 1);

  if (tenderTotal > 0 && Math.abs(diff) > tolerance) {
    return {
      status: 'FAILED',
      reasonCode: 'DAILY_TENDER_MISMATCH',
      message: `DailySummary tender mismatch: revenue=${revenue}, tenderTotal=${tenderTotal}, diff=${diff}`,
    };
  }

  const lines = [];
  if (tenderTotal <= 0) {
    lines.push({ accountCode: DEFAULT_ACCOUNTS.CASH_ON_HAND, debit: revenue, credit: 0, narration: 'POS sale - assumed cash' });
  } else {
    if (cash > 0) lines.push({ accountCode: DEFAULT_ACCOUNTS.CASH_ON_HAND, debit: cash, credit: 0, narration: 'POS sale - cash' });
    if (transfer > 0) lines.push({ accountCode: DEFAULT_ACCOUNTS.BANK_TRANSFERS, debit: transfer, credit: 0, narration: 'POS sale - transfer' });
    if (pos > 0) lines.push({ accountCode: DEFAULT_ACCOUNTS.BANK_POS, debit: pos, credit: 0, narration: 'POS sale - POS settlement' });

    if (Math.abs(diff) > 0 && Math.abs(diff) <= tolerance) {
      lines.push({
        accountCode: getCashOverShortAccount(),
        debit: diff > 0 ? Math.abs(diff) : 0,
        credit: diff < 0 ? Math.abs(diff) : 0,
        narration: 'Tender rounding / cash over-short',
      });
    }
  }

  lines.push({ accountCode: getRevenueAccountPOS(), debit: 0, credit: revenue, narration: 'LPG POS sales revenue' });

  const kgSold = safeNum(ds?.sales?.totalKgSold, 0);
  const stockConfig = await BranchStockConfig.findOne({ branchId: String(branchKey), isActive: { $ne: false } }).lean().catch(() => null);
  const cogsEnabled = opts.forceCogs === true || Boolean(stockConfig?.cogsEnabled);
  let cogsMeta = { enabled: cogsEnabled, posted: false, reason: null, kgSold, wacCostPerKg: 0, cogsAmount: 0 };
  if (!cogsEnabled) {
    cogsMeta.reason = 'COGS_NOT_ACTIVATED_FOR_BRANCH';
  } else if (kgSold > 0) {
    try {
      const wac = await getWacCostPerKgAsOf(branchKey, businessDate);
      const wacCostPerKg = safeNum(wac?.wac, 0);
      const cogsAmount = kgSold * wacCostPerKg;
      cogsMeta = { enabled: true, posted: cogsAmount > 0, reason: cogsAmount > 0 ? null : 'WAC_ZERO_OR_STOCK_NOT_LOADED', kgSold, wacCostPerKg, cogsAmount };
      if (cogsAmount > 0) {
        lines.push({ accountCode: DEFAULT_ACCOUNTS.COGS_LPG, debit: cogsAmount, credit: 0, narration: 'LPG cost of goods sold' });
        lines.push({ accountCode: DEFAULT_ACCOUNTS.INVENTORY_LPG, debit: 0, credit: cogsAmount, narration: 'Reduce LPG inventory for POS sales' });
      }
    } catch (e) {
      cogsMeta = { enabled: true, posted: false, reason: e.code || e.message || 'WAC_ERROR', kgSold, wacCostPerKg: 0, cogsAmount: 0 };
    }
  } else {
    cogsMeta.reason = 'NO_KG_SOLD';
  }

  if (opts.dryRun) {
    return { status: 'POSTED', glEntryIds: [], message: 'Dry run: Daily Summary POS journal is valid' };
  }

  try {
    const sourceId = String(ds._id);
    const result = await upsertJournal({
      date: businessDate,
      branchKey,
      sourceType: 'DAILY_SUMMARY',
      sourceId,
      entryType: opts.entryType || 'PRIMARY',
      narration: `POS DailySummary ${sourceId}`,
      lines,
      meta: { dailySummaryId: ds.dailySummaryId || null, cashierName: ds.cashierName || null, postingBatchId: opts.postingBatchId || null, cogs: cogsMeta },
    });

    return { status: 'POSTED', glEntryIds: result.glEntryIds, message: 'Daily POS sales posted to GL' };
  } catch (e) {
    return { status: 'FAILED', reasonCode: e.code || 'DAILY_POSTING_FAILED', message: e.message || 'Daily POS posting failed' };
  }
};

module.exports = postDailySummaryPOS;
module.exports.post = postDailySummaryPOS;
module.exports.postDailySummaryPOS = postDailySummaryPOS;
