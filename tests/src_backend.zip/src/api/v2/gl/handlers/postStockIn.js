// src/api/v2/gl/handlers/postStockIn.js
const mongoose = require('mongoose');
const StockIn = require('../../../../models/stockIn.model');
const { upsertJournal } = require('../services/journalUpsert.service');
const { DEFAULT_ACCOUNTS } = require('../services/coaMapping.service');

const safeNum = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const parseDate = (d) => { const x = d ? new Date(d) : null; return x && !Number.isNaN(x.getTime()) ? x : null; };
const toBranchKey = (doc) => { const v = doc?.branchId ?? doc?.serviceZoneId ?? doc?.zoneId ?? doc?.plantId ?? doc?.branchKey ?? null; return v == null ? null : String(v); };
const isOpeningStock = (stock) => String(stock?.stockType || stock?.type || '').toUpperCase() === 'OPENING_STOCK';
const paymentSignals = (stock) => {
  const amountPaid = safeNum(stock?.amountPaid ?? stock?.paidAmount, 0);
  const ps = String(stock?.paymentStatus || '').toLowerCase().trim();
  const explicitlyPaid = stock?.isPaid === true || ['paid', 'settled', 'completed', 'success', 'successful'].includes(ps);
  const hasSignals = ['amountPaid', 'paidAmount', 'isPaid', 'paymentStatus'].some((k) => Object.prototype.hasOwnProperty.call(stock || {}, k));
  return { amountPaid, explicitlyPaid, hasSignals };
};
const paymentCreditAccount = (stock) => {
  const pm = String(stock?.paymentMethod || stock?.mode || stock?.paymentMode || '').toLowerCase();
  if (pm.includes('cash')) return DEFAULT_ACCOUNTS.CASH_ON_HAND;
  if (pm.includes('pos') || pm.includes('card')) return DEFAULT_ACCOUNTS.BANK_POS;
  return DEFAULT_ACCOUNTS.BANK_TRANSFERS;
};

async function postStockIn(stockOrId, opts = {}) {
  const stock = typeof stockOrId === 'string' || mongoose.Types.ObjectId.isValid(String(stockOrId)) ? await StockIn.findById(stockOrId).lean() : stockOrId;
  if (!stock) return { status: 'SKIPPED', reasonCode: 'STOCKIN_NOT_FOUND', message: 'Stock-in was not found' };
  const businessDate = parseDate(stock.purchaseDate);
  if (!businessDate) return { status: 'SKIPPED', reasonCode: 'STOCKIN_INVALID_PURCHASE_DATE', message: 'Stock-in has invalid purchase date' };
  const branchKey = toBranchKey(stock);
  if (!branchKey) return { status: 'SKIPPED', reasonCode: 'STOCKIN_MISSING_BRANCH', message: 'Stock-in has no branch key' };
  const qty = safeNum(stock.quantityKg, 0);
  const costPerKg = safeNum(stock.costPerKg, 0);
  if (qty <= 0 || costPerKg <= 0) return { status: 'SKIPPED', reasonCode: 'STOCKIN_INVALID_QTY_OR_COST', message: 'Quantity/cost is invalid' };
  const total = qty * costPerKg;
  const lines = [{ accountCode: DEFAULT_ACCOUNTS.INVENTORY_LPG, debit: total, credit: 0, narration: isOpeningStock(stock) ? 'Opening LPG stock' : 'LPG inventory receipt' }];
  if (isOpeningStock(stock)) {
    lines.push({ accountCode: DEFAULT_ACCOUNTS.OPENING_BALANCE_EQUITY || '3200', debit: 0, credit: total, narration: 'Opening balance equity' });
  } else {
    const sig = paymentSignals(stock);
    if (sig.hasSignals && sig.explicitlyPaid) lines.push({ accountCode: paymentCreditAccount(stock), debit: 0, credit: total, narration: 'Stock purchase paid' });
    else if (sig.hasSignals && sig.amountPaid > 0 && sig.amountPaid < total) {
      lines.push({ accountCode: paymentCreditAccount(stock), debit: 0, credit: sig.amountPaid, narration: 'Paid portion of stock purchase' });
      lines.push({ accountCode: DEFAULT_ACCOUNTS.ACCOUNTS_PAYABLE, debit: 0, credit: total - sig.amountPaid, narration: 'Outstanding supplier payable' });
    } else lines.push({ accountCode: DEFAULT_ACCOUNTS.ACCOUNTS_PAYABLE, debit: 0, credit: total, narration: 'Supplier payable' });
  }
  if (opts.dryRun) return { status: 'POSTED', glEntryIds: [], message: 'Dry run: stock-in journal is valid' };
  try {
    const result = await upsertJournal({ date: businessDate, branchKey, sourceType: isOpeningStock(stock) ? 'OPENING_STOCK' : 'STOCK_IN', sourceId: String(stock._id), entryType: opts.entryType || 'PRIMARY', narration: `${isOpeningStock(stock) ? 'Opening stock' : 'Stock-in'} ${String(stock._id)} - ${qty}kg @ ${costPerKg}`, lines, meta: { stockInId: stock.id || null, quantityKg: qty, costPerKg, postingBatchId: opts.postingBatchId || null } });
    return { status: 'POSTED', glEntryIds: result.glEntryIds, message: 'Stock-in posted to GL' };
  } catch (e) {
    return { status: 'FAILED', reasonCode: e.code || 'STOCKIN_POSTING_FAILED', message: e.message || 'Stock-in posting failed' };
  }
}
module.exports = postStockIn;
module.exports.post = postStockIn;
module.exports.postStockIn = postStockIn;
