// File: src/api/v2/gl/posting.service.js
// GL orchestrator: bootstrap COA, post approved operational documents, rebuild, retry, controls.

const mongoose = require('mongoose');
const ChartOfAccount = require('../../../models/chartOfAccount.model');
const GeneralLedgerEntry = require('../../../models/generalLedgerEntry.model');
const Order = require('../../../models/order.model');
const DailySummary = require('../../../models/dailySummary.model');
const ExpenseTransaction = require('../../../models/expenseTransaction.model');
const SaleTransaction = require('../../../models/saleTransaction.model');
const StockIn = require('../../../models/stockIn.model');
const AccountingPeriod = require('../../../models/accountingPeriod.model');
const PostingBatch = require('../../../models/postingBatch.model');

const postDailySummaryPOS = require('./handlers/postDailySummaryPOS');
const postExpenseTransaction = require('./handlers/postExpenseTransaction');
const postStockIn = require('./handlers/postStockIn');
const postOrderDelivery = require('./handlers/postOrderDelivery');
const postReversal = require('./handlers/postReversal');
const { ensureDefaultCOA } = require('./services/coaMapping.service');
const { recordStockInMovement, depleteStockForDailySummary, depleteStockForOrderDelivery } = require('../inventory/services/stockLedger.service');

const safeNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const hasVal = (v) => v !== undefined && v !== null && String(v).trim() !== '';
const parseBusinessDate = (d) => {
  if (!d) return null;
  if (typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)) {
    const [y, m, day] = d.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, day, 0, 0, 0, 0));
  }
  const x = new Date(d);
  return x && !Number.isNaN(x.getTime()) ? x : null;
};

const toISODate = (d) => parseBusinessDate(d);

const startOfDay = (d) => {
  const x = parseBusinessDate(d) || new Date();
  x.setUTCHours(0, 0, 0, 0);
  return x;
};

const endOfDay = (d) => {
  const x = parseBusinessDate(d) || new Date();
  x.setUTCHours(23, 59, 59, 999);
  return x;
};

const periodKeyOf = (d) => {
  const x = parseBusinessDate(d) || new Date();
  return x.toISOString().slice(0, 7);
};

const assertPeriodOpenForDate = async (d, action = 'post') => {
  const periodKey = periodKeyOf(d);
  const period = await AccountingPeriod.findOne({ periodKey }).lean();
  if (period && period.status === 'LOCKED') {
    const e = new Error('Accounting period ' + periodKey + ' is locked. Reopen the period before attempting to ' + action + '.');
    e.code = 'PERIOD_LOCKED';
    e.periodKey = periodKey;
    throw e;
  }
  return { periodKey, status: period?.status || 'OPEN' };
};

const assertPeriodOpenForRange = async (start, end, action = 'post') => {
  const startKey = periodKeyOf(start);
  const endKey = periodKeyOf(end);
  const periods = await AccountingPeriod.find({ periodKey: { $gte: startKey, $lte: endKey }, status: 'LOCKED' }).lean();
  if (periods.length) {
    const e = new Error('Locked accounting period(s): ' + periods.map((p) => p.periodKey).join(', ') + '. Reopen before attempting to ' + action + '.');
    e.code = 'PERIOD_LOCKED';
    e.periodKeys = periods.map((p) => p.periodKey);
    throw e;
  }
};

const toBranchKey = (docOrId) => {
  if (!docOrId) return null;
  if (typeof docOrId === 'string') return docOrId;
  const v = docOrId.branchId ?? docOrId.serviceZoneId ?? docOrId.zoneId ?? docOrId.plantId ?? docOrId.branchKey ?? null;
  return v == null ? null : String(v);
};

const buildBranchOrZoneMatch = (branchKey) => {
  if (!branchKey) return {};
  const s = String(branchKey);
  const ors = [{ branchId: s }, { serviceZoneId: s }, { zoneId: s }, { plantId: s }, { branchKey: s }];
  if (mongoose.Types.ObjectId.isValid(s)) {
    const oid = new mongoose.Types.ObjectId(s);
    ors.push({ branchId: oid }, { serviceZoneId: oid }, { zoneId: oid }, { plantId: oid });
  }
  return { $or: ors };
};

const keyOfReason = (r) => String(r || 'UNKNOWN').toUpperCase();

const makeStats = () => ({
  posted: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  skipped: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  failed: { STOCK_IN: 0, DAILY_SUMMARY: 0, ORDER: 0, EXPENSE: 0, REVERSAL: 0 },
  reasons: {},
  examples: {},
});

const bumpReason = (stats, code, id) => {
  const k = keyOfReason(code);
  stats.reasons[k] = (stats.reasons[k] || 0) + 1;
  if (!stats.examples[k]) stats.examples[k] = [];
  if (id && stats.examples[k].length < 10) stats.examples[k].push(String(id));
};

const normalizeHandlerResult = (raw = {}) => {
  if (raw.status) return raw;
  if (raw.posted === true) {
    const ids = [];
    if (raw.glEntryId) ids.push(String(raw.glEntryId));
    if (Array.isArray(raw.glEntryIds)) ids.push(...raw.glEntryIds.map(String));
    return { status: 'POSTED', glEntryIds: [...new Set(ids)], message: raw.message || 'Posted successfully' };
  }
  if (raw.skipped === true) {
    return { status: 'SKIPPED', reasonCode: raw.reason || raw.reasonCode || 'SKIPPED', message: raw.message || raw.reason || 'Skipped' };
  }
  return { status: 'FAILED', reasonCode: raw.reasonCode || 'FAILED', message: raw.message || 'Handler returned unsupported result' };
};

const getPostFunction = (handler) => {
  if (typeof handler === 'function') return handler;
  if (handler && typeof handler.post === 'function') return handler.post;
  if (handler && typeof handler.postStockIn === 'function') return handler.postStockIn;
  if (handler && typeof handler.postOrderDelivery === 'function') return handler.postOrderDelivery;
  if (handler && typeof handler.postDailySummaryPOS === 'function') return handler.postDailySummaryPOS;
  if (handler && typeof handler.postExpenseTransaction === 'function') return handler.postExpenseTransaction;
  return null;
};

const updateSourcePostingMeta = async ({ model, id, patch }) => {
  if (!model || !id || !patch) return;
  const $set = {};
  const $inc = {};
  if (patch.status !== undefined) $set['posting.status'] = patch.status;
  if (patch.glEntryId !== undefined) $set['posting.glEntryId'] = patch.glEntryId || null;
  if (patch.glEntryIds !== undefined) $set['posting.glEntryIds'] = patch.glEntryIds || [];
  if (patch.postedAt !== undefined) $set['posting.postedAt'] = patch.postedAt;
  if (patch.postedBy !== undefined) $set['posting.postedBy'] = patch.postedBy;
  if (patch.errorCode !== undefined) $set['posting.errorCode'] = patch.errorCode;
  if (patch.errorMessage !== undefined) $set['posting.errorMessage'] = patch.errorMessage;
  if (patch.version !== undefined) $set['posting.version'] = patch.version;
  if (typeof patch.attemptsInc === 'number') $inc['posting.attempts'] = patch.attemptsInc;
  const update = {};
  if (Object.keys($set).length) update.$set = $set;
  if (Object.keys($inc).length) update.$inc = $inc;
  if (Object.keys(update).length) await model.updateOne({ _id: id }, update);
};

const runOne = async ({ handler, model, doc, sourceType, stats, postedBy = 'system', ctx = {} }) => {
  const id = doc?._id;
  if (!ctx.dryRun) {
    try {
      await updateSourcePostingMeta({ model, id, patch: { status: 'QUEUED', postedBy, version: 1 } });
    } catch (_) {}
  }

  try {
    const postFn = getPostFunction(handler);
    if (!postFn) {
      const e = new Error('Posting handler is not callable');
      e.code = 'HANDLER_NOT_CALLABLE';
      throw e;
    }

    const result = normalizeHandlerResult(await postFn(doc, { postedBy, ...ctx }));
    const status = String(result.status || 'FAILED').toUpperCase();
    const glEntryIds = Array.isArray(result.glEntryIds) ? result.glEntryIds.map(String) : [];

    if (status === 'POSTED') {
      stats.posted[sourceType] += 1;
      if (!ctx.dryRun) {
        const postedAt = new Date();
        await updateSourcePostingMeta({
          model,
          id,
          patch: {
            status: 'POSTED',
            glEntryIds,
            glEntryId: glEntryIds[0] || null,
            errorCode: null,
            errorMessage: null,
            postedAt,
            postedBy,
            attemptsInc: 1,
            version: 1,
          },
        });

        // DailySummary is posted as the aggregated POS sales source.
        // Mark linked SaleTransaction rows as POSTED for traceability only; they are not posted again as separate GL journals.
        if (sourceType === 'DAILY_SUMMARY' && id) {
          try { await depleteStockForDailySummary(doc, { createdBy: postedBy }); } catch (_) {}
          await SaleTransaction.updateMany(
            { dailySummaryId: id },
            {
              $set: {
                'posting.status': 'POSTED',
                'posting.glEntryIds': glEntryIds,
                'posting.glEntryId': glEntryIds[0] || null,
                'posting.postedAt': postedAt,
                'posting.postedBy': postedBy,
                'posting.errorCode': null,
                'posting.errorMessage': null,
                'posting.version': 1,
              },
              $inc: { 'posting.attempts': 1 },
            }
          );
        }
      }
      if (sourceType === 'STOCK_IN' && !ctx.dryRun) { try { await recordStockInMovement(doc, postedBy); } catch (_) {} }
      if (sourceType === 'ORDER' && !ctx.dryRun) { try { await depleteStockForOrderDelivery(doc, { createdBy: postedBy }); } catch (_) {} }
      return { ok: true, status: 'POSTED', sourceType, sourceId: id ? String(id) : null, glEntryIds };
    }

    if (status === 'SKIPPED') {
      stats.skipped[sourceType] += 1;
      const reason = keyOfReason(result.reasonCode || 'SKIPPED');
      bumpReason(stats, reason, id);
      if (!ctx.dryRun) await updateSourcePostingMeta({
        model,
        id,
        patch: {
          status: 'SKIPPED',
          glEntryIds: [],
          glEntryId: null,
          errorCode: reason,
          errorMessage: result.message || 'Skipped',
          postedAt: null,
          postedBy,
          attemptsInc: 1,
          version: 1,
        },
      });
      return { ok: true, status: 'SKIPPED', sourceType, sourceId: id ? String(id) : null, reasonCode: reason };
    }

    stats.failed[sourceType] += 1;
    const reason = keyOfReason(result.reasonCode || 'FAILED');
    bumpReason(stats, reason, id);
    if (!ctx.dryRun) await updateSourcePostingMeta({
      model,
      id,
      patch: {
        status: 'FAILED',
        glEntryIds: [],
        glEntryId: null,
        errorCode: reason,
        errorMessage: result.message || 'Posting failed',
        postedAt: null,
        postedBy,
        attemptsInc: 1,
        version: 1,
      },
    });
    return { ok: false, status: 'FAILED', sourceType, sourceId: id ? String(id) : null, reasonCode: reason };
  } catch (e) {
    stats.failed[sourceType] += 1;
    const reason = keyOfReason(e.code || e.name || 'EXCEPTION');
    bumpReason(stats, reason, id);
    if (!ctx.dryRun) await updateSourcePostingMeta({
      model,
      id,
      patch: {
        status: 'FAILED',
        glEntryIds: [],
        glEntryId: null,
        errorCode: reason,
        errorMessage: e.message || String(e),
        postedAt: null,
        postedBy,
        attemptsInc: 1,
        version: 1,
      },
    });
    return { ok: false, status: 'FAILED', sourceType, sourceId: id ? String(id) : null, reasonCode: reason };
  }
};

const bootstrap = async () => {
  const seed = await ensureDefaultCOA();
  const count = await ChartOfAccount.countDocuments({ isActive: true });
  return { ok: true, seeded: seed.count, insertedOrExisting: count };
};

const buildStockMatch = ({ startIncl, endIncl, branchMatch }) => ({ ...branchMatch, purchaseDate: { $gte: startIncl, $lte: endIncl } });
const buildDailyMatch = ({ startIncl, endIncl, branchMatch, requireApproved = false }) => {
  const q = { ...branchMatch, date: { $gte: startIncl, $lte: endIncl } };
  if (requireApproved) q.status = 'approved';
  return q;
};
const buildExpenseMatch = ({ startIncl, endIncl, branchMatch, requireApproved = false }) => {
  const q = { ...branchMatch, date: { $gte: startIncl, $lte: endIncl } };
  if (requireApproved) q.status = { $in: ['approved', 'Approved', 'APPROVED'] };
  return q;
};
const buildOrderMatch = ({ startIncl, endIncl, branchMatch, requireDelivered = false }) => {
  const and = [
    { $or: [{ orderDate: { $gte: startIncl, $lte: endIncl } }, { orderDate: { $exists: false }, createdAt: { $gte: startIncl, $lte: endIncl } }] },
    { $or: [{ channel: { $exists: false } }, { channel: 'DELIVERY' }] },
  ];
  if (requireDelivered) and.push({ status: 'Delivered' });
  return { ...branchMatch, $and: and };
};

const loadDocs = async ({ startIncl, endIncl, branchKey, requireApproved }) => {
  const branchMatch = buildBranchOrZoneMatch(branchKey);
  return Promise.all([
    StockIn.find(buildStockMatch({ startIncl, endIncl, branchMatch })).lean(),
    DailySummary.find(buildDailyMatch({ startIncl, endIncl, branchMatch, requireApproved })).lean(),
    Order.find(buildOrderMatch({ startIncl, endIncl, branchMatch, requireDelivered: requireApproved })).lean(),
    ExpenseTransaction.find(buildExpenseMatch({ startIncl, endIncl, branchMatch, requireApproved })).lean(),
  ]);
};

const postDocs = async ({ stockIns, dailies, orders, expenses, stats, postedBy, ctx }) => {
  const results = [];
  const runAndPush = async (args) => {
    const r = await runOne(args);
    results.push(r);
    return r;
  };
  for (const s of stockIns || []) await runAndPush({ handler: postStockIn, model: StockIn, doc: s, sourceType: 'STOCK_IN', stats, postedBy, ctx });
  for (const d of dailies || []) await runAndPush({ handler: postDailySummaryPOS, model: DailySummary, doc: d, sourceType: 'DAILY_SUMMARY', stats, postedBy, ctx });
  for (const o of orders || []) await runAndPush({ handler: postOrderDelivery, model: Order, doc: o, sourceType: 'ORDER', stats, postedBy, ctx });
  for (const e of expenses || []) await runAndPush({ handler: postExpenseTransaction, model: ExpenseTransaction, doc: e, sourceType: 'EXPENSE', stats, postedBy, ctx });
  return results;
};

const createBatch = async ({ action, branchKey, startDate, endDate, businessDate, requestedBy }) => PostingBatch.create({ action, branchKey, startDate, endDate, businessDate, requestedBy, status: 'STARTED' });

const finalizeBatch = async (batch, { found, stats, results, errorMessage = null }) => {
  if (!batch) return null;
  const journalIds = [...new Set((results || []).flatMap((r) => Array.isArray(r.glEntryIds) ? r.glEntryIds.map(String) : []))];
  const failedTotal = Object.values(stats?.failed || {}).reduce((a, b) => a + safeNum(b, 0), 0);
  batch.status = errorMessage ? 'FAILED' : (failedTotal > 0 ? 'COMPLETED_WITH_ERRORS' : 'COMPLETED');
  batch.found = found || {};
  batch.stats = stats || {};
  batch.results = results || [];
  batch.journalIds = journalIds;
  batch.errorMessage = errorMessage || null;
  batch.completedAt = new Date();
  await batch.save();
  return batch;
};

const rebuild = async ({ startDate, endDate, branchId = null, dryRun = false, postedBy = 'system' }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) { const e = new Error('Invalid startDate/endDate'); e.code = 'BAD_DATES'; throw e; }
  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);
  const branchKey = hasVal(branchId) ? String(branchId) : null;
  if (!dryRun) await assertPeriodOpenForRange(startIncl, endIncl, 'rebuild GL');
  let batch = null;
  if (!dryRun) batch = await createBatch({ action: 'REBUILD', branchKey, startDate: startIncl, endDate: endIncl, requestedBy: postedBy });
  try {
    if (!dryRun) { const delFilter = { date: { $gte: startIncl, $lte: endIncl } }; if (branchKey) delFilter.branchKey = branchKey; await GeneralLedgerEntry.deleteMany(delFilter); }
    const [stockIns, dailies, orders, expenses] = await loadDocs({ startIncl, endIncl, branchKey, requireApproved: false });
    const stats = makeStats();
    const results = await postDocs({ stockIns, dailies, orders, expenses, stats, postedBy, ctx: { dryRun: Boolean(dryRun), branchKey, postingBatchId: batch?.batchId || null } });
    const found = { stockIns: stockIns.length, dailies: dailies.length, orders: orders.length, expenses: expenses.length };
    const savedBatch = await finalizeBatch(batch, { found, stats, results });
    return { ok: true, dryRun: Boolean(dryRun), batchId: savedBatch?.batchId || null, start: startIncl.toISOString(), end: endIncl.toISOString(), branchId: branchKey, found, ...stats };
  } catch (e) {
    await finalizeBatch(batch, { found: {}, stats: makeStats(), results: [], errorMessage: e.message });
    throw e;
  }
};

const postApproved = async ({ date, businessDate, branchId = null, postedBy = 'system' }) => {
  const d = toISODate(date || businessDate);
  if (!d) { const e = new Error('Invalid date'); e.code = 'BAD_DATE'; throw e; }
  const start = startOfDay(d);
  const end = endOfDay(d);
  await assertPeriodOpenForDate(start, 'post approved records');
  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const batch = await createBatch({ action: 'POST_APPROVED', branchKey, businessDate: start, startDate: start, endDate: end, requestedBy: postedBy });
  try {
    const [stockIns, dailies, orders, expenses] = await loadDocs({ startIncl: start, endIncl: end, branchKey, requireApproved: true });
    const stats = makeStats();
    const results = await postDocs({ stockIns, dailies, orders, expenses, stats, postedBy, ctx: { dryRun: false, branchKey, postingBatchId: batch.batchId } });
    const found = { stockIns: stockIns.length, dailies: dailies.length, orders: orders.length, expenses: expenses.length };
    const savedBatch = await finalizeBatch(batch, { found, stats, results });
    return { ok: true, batchId: savedBatch?.batchId || batch.batchId, date: start.toISOString().slice(0, 10), branchId: branchKey, found, ...stats };
  } catch (e) {
    await finalizeBatch(batch, { found: {}, stats: makeStats(), results: [], errorMessage: e.message });
    throw e;
  }
};

const retryFailed = async ({ startDate, endDate, branchId = null, postedBy = 'system' }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) { const e = new Error('Invalid startDate/endDate'); e.code = 'BAD_DATES'; throw e; }
  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);
  await assertPeriodOpenForRange(startIncl, endIncl, 'retry failed postings');
  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const batch = await createBatch({ action: 'RETRY_FAILED', branchKey, startDate: startIncl, endDate: endIncl, requestedBy: postedBy });
  try {
    const branchMatch = buildBranchOrZoneMatch(branchKey);
    const [stockIns, dailies, orders, expenses] = await Promise.all([
      StockIn.find({ ...buildStockMatch({ startIncl, endIncl, branchMatch }), 'posting.status': 'FAILED' }).lean(),
      DailySummary.find({ ...buildDailyMatch({ startIncl, endIncl, branchMatch, requireApproved: false }), 'posting.status': 'FAILED' }).lean(),
      Order.find({ ...buildOrderMatch({ startIncl, endIncl, branchMatch, requireDelivered: false }), 'posting.status': 'FAILED' }).lean(),
      ExpenseTransaction.find({ ...buildExpenseMatch({ startIncl, endIncl, branchMatch, requireApproved: false }), 'posting.status': 'FAILED' }).lean(),
    ]);
    const stats = makeStats();
    const results = await postDocs({ stockIns, dailies, orders, expenses, stats, postedBy, ctx: { dryRun: false, branchKey, postingBatchId: batch.batchId } });
    const found = { stockIns: stockIns.length, dailies: dailies.length, orders: orders.length, expenses: expenses.length };
    const savedBatch = await finalizeBatch(batch, { found, stats, results });
    return { ok: true, batchId: savedBatch?.batchId || batch.batchId, start: startIncl.toISOString(), end: endIncl.toISOString(), branchId: branchKey, found, ...stats };
  } catch (e) {
    await finalizeBatch(batch, { found: {}, stats: makeStats(), results: [], errorMessage: e.message });
    throw e;
  }
};

const trialBalance = async ({ startDate, endDate, branchId = null }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }
  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);
  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const match = { status: 'POSTED', date: { $gte: startIncl, $lte: endIncl } };
  if (branchKey) match.branchKey = branchKey;
  const rows = await GeneralLedgerEntry.aggregate([
    { $match: match },
    { $unwind: '$lines' },
    { $group: { _id: '$lines.accountCode', debit: { $sum: '$lines.debit' }, credit: { $sum: '$lines.credit' } } },
    { $sort: { _id: 1 } },
  ]);
  const coa = await ChartOfAccount.find({ isActive: true }).lean();
  const coaMap = new Map(coa.map((a) => [String(a.accountCode), a]));
  const shaped = rows.map((r) => {
    const meta = coaMap.get(String(r._id)) || null;
    const debit = safeNum(r.debit, 0);
    const credit = safeNum(r.credit, 0);
    const balance = meta?.normalBalance === 'CREDIT' ? credit - debit : debit - credit;
    return { accountCode: String(r._id), accountName: meta?.name || 'Unknown', accountType: meta?.type || 'UNKNOWN', normalBalance: meta?.normalBalance || null, debit, credit, balance };
  });
  const totals = shaped.reduce((acc, r) => ({ debit: acc.debit + r.debit, credit: acc.credit + r.credit }), { debit: 0, credit: 0 });
  const diff = Math.abs(totals.debit - totals.credit);
  return { ok: diff <= 0.5, totals, diff, rows: shaped, period: { start: startIncl, end: endIncl }, branch: { branchId: branchKey } };
};

const postingExceptions = async ({ startDate, endDate, branchId = null }) => {
  const start = toISODate(startDate);
  const end = toISODate(endDate);
  if (!start || !end) {
    const e = new Error('Invalid startDate/endDate');
    e.code = 'BAD_DATES';
    throw e;
  }
  const startIncl = startOfDay(start);
  const endIncl = endOfDay(end);
  const branchKey = hasVal(branchId) ? String(branchId) : null;
  const branchMatch = buildBranchOrZoneMatch(branchKey);
  const [stockIns, dailies, orders, expenses] = await Promise.all([
    StockIn.find({ ...branchMatch, purchaseDate: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' }).select('_id purchaseDate posting branchId').lean(),
    DailySummary.find({ ...branchMatch, date: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' }).select('_id date posting branchId').lean(),
    Order.find({ ...branchMatch, createdAt: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' }).select('_id createdAt orderDate posting branchId').lean(),
    ExpenseTransaction.find({ ...branchMatch, date: { $gte: startIncl, $lte: endIncl }, 'posting.status': 'FAILED' }).select('_id date posting branchId').lean(),
  ]);
  const reasons = {};
  const pushOne = (sourceType, doc, businessDate) => {
    const code = keyOfReason(doc?.posting?.errorCode || 'FAILED');
    if (!reasons[code]) reasons[code] = { count: 0, examples: [] };
    reasons[code].count += 1;
    if (reasons[code].examples.length < 10) reasons[code].examples.push({ sourceType, sourceId: String(doc._id), branchKey: toBranchKey(doc), businessDate: businessDate ? new Date(businessDate).toISOString().slice(0, 10) : null, message: doc?.posting?.errorMessage || null, attempts: safeNum(doc?.posting?.attempts, 0) });
  };
  (stockIns || []).forEach((x) => pushOne('STOCK_IN', x, x.purchaseDate));
  (dailies || []).forEach((x) => pushOne('DAILY_SUMMARY', x, x.date));
  (orders || []).forEach((x) => pushOne('ORDER', x, x.orderDate || x.createdAt));
  (expenses || []).forEach((x) => pushOne('EXPENSE', x, x.date));
  return { ok: true, start: startIncl.toISOString(), end: endIncl.toISOString(), branchId: branchKey, totals: { failed: stockIns.length + dailies.length + orders.length + expenses.length }, reasons };
};

const listPostingBatches = async ({ startDate, endDate, branchId = null, action = null, page = 1, limit = 50 } = {}) => {
  const query = {};
  if (startDate || endDate) query.createdAt = {};
  if (startDate) query.createdAt.$gte = startOfDay(startDate);
  if (endDate) query.createdAt.$lte = endOfDay(endDate);
  if (branchId) query.branchKey = String(branchId);
  if (action) query.action = String(action).toUpperCase();
  const safeLimit = Math.min(Math.max(Number(limit) || 50, 1), 200);
  const safePage = Math.max(Number(page) || 1, 1);
  const [items, total] = await Promise.all([
    PostingBatch.find(query).sort({ createdAt: -1 }).skip((safePage - 1) * safeLimit).limit(safeLimit).lean(),
    PostingBatch.countDocuments(query),
  ]);
  return { ok: true, page: safePage, limit: safeLimit, total, items };
};

module.exports = { bootstrap, rebuild, postApproved, retryFailed, trialBalance, postingExceptions, postReversal, listPostingBatches, assertPeriodOpenForDate, assertPeriodOpenForRange };
