// src/api/v2/inventory/inventory.routes.js
const express = require('express');
const inventoryController = require('./inventory.controller');
const authMiddleware = require('../../../middleware/auth.middleware');
const validate = require('../../../middleware/validate.middleware');
const { addAssetSchema, addLoanSchema, addCylinderSchema, addStockInSchema } = require('./inventory.validation');

const router = express.Router();

// Asset routes
router.get('/assets', authMiddleware('admin'), inventoryController.getAssets);
router.post('/assets', authMiddleware('admin'), validate(addAssetSchema), inventoryController.addAsset);

// Loan routes
router.get('/loans', authMiddleware('admin'), inventoryController.getLoans);
router.post('/loans', authMiddleware('admin'), validate(addLoanSchema), inventoryController.addLoan);
router.delete('/loans/:loanId', authMiddleware('admin'), inventoryController.deleteLoan);

// Cylinder routes
router.get('/cylinders', authMiddleware('admin'), inventoryController.getCylinders);
router.post('/cylinders', authMiddleware('admin'), validate(addCylinderSchema), inventoryController.addCylinder);
router.delete('/cylinders/:cylinderId', authMiddleware('admin'), inventoryController.deleteCylinder);

// Stock-in route
router.post('/stock-in', authMiddleware('admin'), validate(addStockInSchema), inventoryController.addStockIn);

// Inventory Summary route for Dashboard
router.get('/summary', authMiddleware(['admin', 'manager', 'cashier']), inventoryController.getInventorySummary);

// NEW: Endpoint to get LPG stock-in history with profitability
router.get('/stock-in-history', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getLpgStockInHistory);

// Wave 3 stock, COGS and profitability controls
router.post('/opening-stock', authMiddleware('admin'), inventoryController.loadOpeningStock);
router.post('/opening-cylinders', authMiddleware('admin'), inventoryController.loadOpeningCylinderStock);
router.get('/stock-movements', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getStockMovements);
router.post('/reconciliations', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.reconcileStock);
router.get('/reconciliations', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getReconciliations);
router.get('/gross-profit', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getGrossProfitReport);
router.get('/branch-profitability', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getBranchProfitabilityReport);
// Wave 9 product, pricing, branch mapping and setup controls
router.get('/products', authMiddleware(['admin', 'manager', 'finance_lead', 'cashier']), inventoryController.listProducts);
router.post('/products', authMiddleware(['admin', 'finance_lead']), inventoryController.upsertProduct);
router.get('/branch-prices', authMiddleware(['admin', 'manager', 'finance_lead', 'cashier']), inventoryController.listBranchPrices);
router.post('/branch-prices', authMiddleware(['admin', 'finance_lead']), inventoryController.upsertBranchPrice);
router.get('/price-lookup', authMiddleware(['admin', 'manager', 'finance_lead', 'cashier']), inventoryController.getEffectivePrice);
router.get('/branch-stock-config', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getBranchStockConfig);
router.post('/branch-stock-config', authMiddleware(['admin', 'finance_lead']), inventoryController.saveBranchStockConfig);
router.post('/opening-balances', authMiddleware(['admin', 'finance_lead']), inventoryController.postOpeningBalances);
router.get('/cogs-readiness', authMiddleware(['admin', 'manager', 'finance_lead']), inventoryController.getCogsReadiness);
router.post('/cogs-activation', authMiddleware(['admin', 'finance_lead']), inventoryController.activateCogs);

module.exports = router;