const express = require('express');
const router = express.Router();
const auth = require('../../../middleware/auth.middleware');
const controller = require('./historicalMigration.controller');

router.get('/template', auth(['admin', 'manager', 'finance_lead']), controller.getTemplate);
router.get('/batches', auth(['admin', 'manager', 'finance_lead']), controller.listBatches);
router.post('/batches', auth(['admin', 'manager', 'finance_lead']), controller.createBatch);
router.get('/batches/:batchId', auth(['admin', 'manager', 'finance_lead']), controller.getBatch);
router.patch('/staging/:recordId', auth(['admin', 'manager', 'finance_lead']), controller.updateStagingRecord);
router.post('/batches/:batchId/dry-run', auth(['admin', 'manager', 'finance_lead']), controller.dryRun);
router.post('/batches/:batchId/import', auth(['admin', 'manager', 'finance_lead']), controller.importBatch);

module.exports = router;
